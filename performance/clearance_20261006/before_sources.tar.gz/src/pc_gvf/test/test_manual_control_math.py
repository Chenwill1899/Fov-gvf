from __future__ import annotations
import math
import sys
from pathlib import Path
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "scripts" / "isaac"))
from manual_control_math import desired_velocity_from_direction, vector_safe_command


@pytest.mark.parametrize("axes", [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),
    (0,0,1),(0,0,-1),(1,1,1),(1,-1,-1),(0.2,0.1,0.05)])
def test_manual_input_preserves_one_3d_direction(axes):
    velocity = desired_velocity_from_direction(*axes, 2.0, 1.0)
    scale = next(v / a for a, v in zip(axes, velocity) if a)
    assert velocity == pytest.approx(tuple(scale * a for a in axes))
    assert math.sqrt(sum(v*v for v in velocity)) <= 2.0 + 1e-12
    assert abs(velocity[2]) <= 1.0 + 1e-12


def test_released_input_stops():
    assert desired_velocity_from_direction(0,0,0,2,1) == (0,0,0)


@pytest.mark.parametrize("collides", [lambda p: p[0] > 0.05, lambda p: p[2] > 1.02])
def test_guard_stops_whole_vector_instead_of_sliding(collides):
    assert vector_safe_command((0,0,1),(1,0,0.5),0.1,collides) == ((0,0,0), True)


def test_guard_preserves_clear_vector():
    assert vector_safe_command((0,0,1),(1,-0.3,0.5),0.1,lambda p: False) == ((1,-0.3,0.5), False)


def test_validation_plant_obeys_vector_acceleration_limit():
    from manual_control_math import velocity_response
    actual = velocity_response((0,0,0), (1,1,1), 0.02, 0.22, 1.2)
    assert math.sqrt(sum(v*v for v in actual)) == pytest.approx(0.024)
    assert actual[0] == actual[1] == actual[2]


def test_validation_plant_does_not_overshoot_or_stop_instantly():
    from manual_control_math import velocity_response
    assert velocity_response((0,0,0), (0.01,0,0), 1.0, 0.22, 1.2) == (0.01,0,0)
    assert 0.0 < velocity_response((1,0,0), (0,0,0), 0.02, 0.22, 1.2)[0] < 1.0


def test_zero_command_braking_matches_certified_distance_and_stops():
    from manual_control_math import velocity_response
    velocity=(1.,0.,0.); distance=0.
    for _ in range(60):
        velocity=velocity_response(velocity,(0,0,0),.02,.22,1.2)
        distance+=.02*velocity[0]
    assert velocity == (0.,0.,0.)
    assert distance <= 1./(2*1.2)
