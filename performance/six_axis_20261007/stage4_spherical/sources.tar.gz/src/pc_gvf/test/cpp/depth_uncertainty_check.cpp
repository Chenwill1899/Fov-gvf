#include "pc_gvf/depth_uncertainty.hpp"
#include <iostream>
#include <random>
#include <stdexcept>
using namespace pc_gvf::depth_angular;
int main() {
    Camera camera(32,24,90,68,10.);DepthUncertaintyConfig cfg;cfg.enabled=true;
    std::mt19937 rng(62026);std::normal_distribution<double> noise(0,1);
    int baseline_unsafe=0,robust_unsafe=0,baseline_false_free=0,robust_false_free=0,credited_false_free=0;double lost=0;
    for(int k=0;k<1000;++k) {
        const double truth=2.+6.*(k%100)/99.;
        const double sigma=cfg.sigma0+cfg.sigma_range2*truth*truth;
        const double measured=truth+sigma*noise(rng);
        DepthObservation o(camera,std::vector<double>(768,measured),Eigen::Vector3d::Zero(),fixedCameraRotation(),1.);
        auto r=conservativeObservation(o,cfg);
        baseline_unsafe+=o.depth[400]>truth;robust_unsafe+=r.depth[400]>truth;lost+=truth-r.depth[400];
        const Eigen::Vector3d physically_colliding_center(truth-.48+.005,0,0);
        baseline_false_free+=observedEnvelope(o,physically_colliding_center,.58);
        robust_false_free+=observedEnvelope(r,physically_colliding_center,.58);
        auto credited_cfg=cfg;credited_cfg.reserved_radial_bound=.03;
        credited_false_free+=observedEnvelope(conservativeObservation(o,credited_cfg),physically_colliding_center,.58);
        if(r.depth[400]>o.depth[400])throw std::runtime_error("invented depth");
    }
    DepthObservation edge(camera,std::vector<double>(768,8.),Eigen::Vector3d::Zero(),fixedCameraRotation(),1.);
    edge.depth[12*32+16]=2.;edge.depth[8*32+16]=0.;
    const auto robust=conservativeObservation(edge,cfg);
    if(robust.depth[12*32+17]>=2.||robust.depth[8*32+17]!=0.)return 2;
    // A one-native-pixel silhouette must not grow by a whole coarse pixel.
    Camera native(320,240,90,68,10.);std::vector<double> raw(320*240,8.);
    for(int y=60;y<180;++y)raw[y*320+160]=2.;
    const auto down=conservativeDepthResize(raw,320,240,32,24,10.);
    DepthObservation coarse(camera,down,Eigen::Vector3d::Zero(),fixedCameraRotation(),1.);
    const auto coarse_uncertain=conservativeObservation(coarse,cfg);
    const auto native_uncertain=conservativeDepth(raw,320,240,native.fx(),native.fy(),native.cx(),native.cy(),cfg);
    const auto resized=conservativeDepthResize(native_uncertain,320,240,32,24,10.);
    int coarse_foreground=0,native_foreground=0;
    for(std::size_t i=0;i<resized.size();++i){coarse_foreground+=coarse_uncertain.depth[i]<3.;native_foreground+=resized[i]<3.;}
    if(native_foreground>=coarse_foreground||native_foreground==0)return 4;
    std::cerr<<"foreground coarse expansion="<<coarse_foreground<<" native expansion="<<native_foreground<<'\n';
    cfg.enabled=false;if(conservativeObservation(edge,cfg).depth!=edge.depth)return 3;
    std::cout<<"samples,baseline_overestimate,uncertainty_overestimate,mean_depth_reserve_m,baseline_false_free_envelope,robust_false_free_envelope,credited_false_free_envelope\n"
             <<1000<<','<<baseline_unsafe<<','<<robust_unsafe<<','<<lost/1000<<','<<baseline_false_free<<','<<robust_false_free<<','<<credited_false_free<<'\n';
    return robust_unsafe<baseline_unsafe/10&&baseline_false_free>0&&robust_false_free==0&&credited_false_free==0?0:1;
}
