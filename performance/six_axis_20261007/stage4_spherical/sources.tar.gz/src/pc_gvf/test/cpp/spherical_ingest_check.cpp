#include "pc_gvf/paper_guidance.hpp"
#include <Eigen/Geometry>
#include <chrono>
#include <iostream>
using namespace pc_gvf::depth_angular;
int main(){
    Camera c(64,48,90,68,10.);double elapsed[2]={};SphericalMemory slow,fast;
    for(int k=0;k<80;++k) {
        const double yaw=(k%4)*std::acos(-1.)/2.;
        DepthObservation o(c,std::vector<double>(3072,4.),Eigen::Vector3d(.02*(k/4),0,0),
            Eigen::AngleAxisd(yaw,Eigen::Vector3d::UnitZ()).toRotationMatrix()*fixedCameraRotation(),k*.025,k+1,k%4);
        auto hits=std::make_shared<std::vector<Eigen::Vector3d>>();
        for(int y=0;y<240;++y)for(int x=0;x<320;++x) {
            const Eigen::Vector3d ray=c.rayFromPixel(Eigen::Vector2d(x/5.,y/5.));
            hits->push_back(ray*((k%13==0&&x>150&&x<154)?3.8:4.)/ray.z());
        }o.obstacle_points=hits;
        auto start=std::chrono::steady_clock::now();slow.ingest(o,false);
        elapsed[0]+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
        start=std::chrono::steady_clock::now();fast.ingest(o,true);
        elapsed[1]+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
        if(slow.slots().size()!=fast.slots().size())return 1;
        for(const auto& slot:slow.slots())if(!fast.slots().count(slot.first)||fast.slots().at(slot.first)->stamp!=slot.second->stamp)return 2;
    }
    std::cout<<"frames,native_points_per_frame,slow_ms,broadphase_ms,same_retained_evidence\n80,76800,"<<elapsed[0]<<','<<elapsed[1]<<",1\n";
    return 0;
}
