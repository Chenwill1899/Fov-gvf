#include "pc_gvf/depth_uncertainty.hpp"
#include <algorithm>
#include <cmath>
#include <stdexcept>
namespace pc_gvf { namespace depth_angular {
std::vector<double> conservativeDepth(const std::vector<double>& input,int w,int h,
    double fx,double fy,double cx,double cy,const DepthUncertaintyConfig& c) {
    if(!c.enabled)return input;
    if(w<1||h<1||!std::isfinite(fx)||!std::isfinite(fy)||fx<=0||fy<=0||
       !std::isfinite(cx)||!std::isfinite(cy))throw std::invalid_argument("invalid depth intrinsics");
    for(double v:{c.sigma0,c.sigma_range2,c.sigma_multiplier,c.pose_bound,c.edge_threshold,c.reserved_radial_bound})
        if(!std::isfinite(v)||v<0)throw std::invalid_argument("invalid depth uncertainty bound");
    if(c.edge_radius<0||c.edge_radius>4)throw std::invalid_argument("invalid edge radius");
    auto out=input;
    if(input.size()!=static_cast<std::size_t>(w*h))throw std::invalid_argument("invalid depth size");
    for(int y=0;y<h;++y)for(int x=0;x<w;++x) {
        const double d=input[y*w+x];
        if(!std::isfinite(d)||d<=0){out[y*w+x]=0;continue;}
        double near=d;
        // Occlusion/missing-return footprints expand; no spatial averaging
        // across the foreground/background discontinuity can create freedom.
        for(int v=std::max(0,y-c.edge_radius);v<=std::min(h-1,y+c.edge_radius);++v)
            for(int u=std::max(0,x-c.edge_radius);u<=std::min(w-1,x+c.edge_radius);++u) {
                const double z=input[v*w+u];
                if(!std::isfinite(z)||z<=0)near=0;
                else if(d-z>c.edge_threshold)near=std::min(near,z);
            }
        const double u=(std::abs(x-cx)+.5)/fx,v=(std::abs(y-cy)+.5)/fy;
        const double minimum_z=1./std::sqrt(1.+u*u+v*v);
        const double bound=std::max(0.,c.sigma_multiplier*(c.sigma0+c.sigma_range2*near*near)+c.pose_bound-
            c.reserved_radial_bound*minimum_z);
        out[y*w+x]=std::max(0.,std::min(d,near-bound));
    }
    return out;
}
DepthObservation conservativeObservation(const DepthObservation& input,const DepthUncertaintyConfig& c) {
    auto out=input;
    out.depth=conservativeDepth(input.depth,input.camera.width(),input.camera.height(),
        input.camera.fx(),input.camera.fy(),input.camera.cx(),input.camera.cy(),c);
    return out;
}
} }
