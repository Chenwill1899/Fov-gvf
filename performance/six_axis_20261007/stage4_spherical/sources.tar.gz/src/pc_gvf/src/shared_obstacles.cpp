#include "pc_gvf/shared_obstacles.hpp"
#include <cmath>
namespace pc_gvf { namespace depth_angular {
bool SharedObstacleMap::merge(const SharedObstaclePacket& p,double now,const std::string& frame) {
    if(p.source.empty()||p.source.size()>64||p.session.empty()||p.session.size()>64||p.frame!=frame||
       !std::isfinite(now)||!std::isfinite(p.stamp)||p.stamp>now+.02||now-p.stamp>.5||p.tracks.size()>4096)return false;
    auto old=sources_.find(p.source);
    if(old!=sources_.end()) {
        if(p.stamp<old->second.stamp)return false;
        if(p.session==old->second.session&&p.sequence<=old->second.sequence)return false;
        if(p.session!=old->second.session&&p.stamp<=old->second.stamp)return false;
    } else if(sources_.size()>=8)return false;
    for(const auto& t:p.tracks)if(!t.point.allFinite()||t.point.norm()>1e5||!t.velocity.allFinite()||t.velocity.norm()>5.||
        !std::isfinite(t.stamp)||t.stamp>p.stamp+.02||p.stamp-t.stamp>.5||!std::isfinite(t.radius)||t.radius<0||t.radius>2.||t.observations<1)return false;
    sources_[p.source]=p;return true;
}
bool SharedObstacleMap::segmentSafe(const Eigen::Vector3d& a,const Eigen::Vector3d& b,
    double radius,double now,double begin,double end)const {
    for(const auto& source:sources_) {
        const auto& p=source.second;
        if(now-p.stamp>.5)continue;
        if(!obstacleSegmentsSafe(p.tracks,p.overloaded,a,b,radius,now,begin,end))return false;
    }
    return true;
}
} }
