#include "pc_gvf/dynamic_obstacles.hpp"
#include "pc_gvf/paper_guidance.hpp"
#include <algorithm>
#include <cmath>
#include <map>
#include <tuple>
namespace pc_gvf { namespace depth_angular {
void DynamicObstacles::ingest(const DepthObservation& o) {
    if(!std::isfinite(o.stamp)||!o.origin.allFinite()||!o.rotation.allFinite()||o.depth.size()!=o.camera.rays().size()) {
        view_overloaded_[o.view]=true;overloaded_=true;return;
    }
    auto it=checked_.find(o.view);
    if(it!=checked_.end()&&o.stamp<it->second.first-.1){tracks_.clear();checked_.clear();view_overloaded_.clear();}
    if(checked_.count(o.view)&&checked_[o.view]==std::make_pair(o.stamp,o.version))return;
    if(checked_.count(o.view)&&o.stamp<=checked_[o.view].first)return;
    checked_[o.view]={o.stamp,o.version};
    std::map<std::tuple<int,int,int>,Eigen::Vector3d> voxels;
    auto add=[&](const Eigen::Vector3d& camera_point) {
        if(!camera_point.allFinite()||camera_point.z()<=0||camera_point.z()>=o.camera.maxDepth()-.01)return;
        const Eigen::Vector3d p=o.origin+o.rotation*camera_point;
        const auto key=std::make_tuple(int(std::floor(p.x()/.3+1e-9)),int(std::floor(p.y()/.3+1e-9)),int(std::floor(p.z()/.3+1e-9)));
        voxels[key]=.3*Eigen::Vector3d(std::get<0>(key)+.5,std::get<1>(key)+.5,std::get<2>(key)+.5);
    };
    if(o.obstacle_points)for(const auto& p:*o.obstacle_points)add(p);
    else for(std::size_t i=0;i<o.depth.size();++i)if(o.depth[i]>0&&std::isfinite(o.depth[i]))
        add(o.camera.rays()[i]*o.depth[i]/o.camera.rays()[i].z());
    // Never silently discard excess hazards. The certificate fails closed.
    view_overloaded_[o.view]=voxels.size()>1024;
    overloaded_=false;for(const auto& status:view_overloaded_)overloaded_=overloaded_||status.second;
    if(view_overloaded_[o.view])return;
    std::vector<ObstacleTrack> next;std::vector<bool> used(tracks_.size(),false);
    for(const auto& cell:voxels) {
        const auto& p=cell.second;double best=.75*.75;int match=-1;
        for(std::size_t i=0;i<tracks_.size();++i) {
            const auto& old=tracks_[i];double dt=o.stamp-old.stamp;
            if(used[i]||old.view!=o.view||dt<.025||dt>.4)continue;
            double d=(p-old.point-dt*old.velocity).squaredNorm();if(d<best){best=d;match=int(i);}
        }
        ObstacleTrack track;track.point=p;track.stamp=o.stamp;track.view=o.view;
        if(match>=0) {
            used[match]=true;const auto& old=tracks_[match];const double dt=o.stamp-old.stamp;
            track.velocity=clampNorm((p-old.point)/dt,3.);track.observations=old.observations+1;
        }
        next.push_back(track);
    }
    for(std::size_t i=0;i<tracks_.size();++i)if(!used[i]&&o.stamp-tracks_[i].stamp<=.5)next.push_back(tracks_[i]);
    if(next.size()>4096){overloaded_=true;return;}tracks_=std::move(next);
}
bool DynamicObstacles::segmentSafe(const Eigen::Vector3d& a,const Eigen::Vector3d& b,
    double radius,double now,double begin,double end) const {
    return obstacleSegmentsSafe(tracks_,overloaded_,a,b,radius,now,begin,end);
}
bool obstacleSegmentsSafe(const std::vector<ObstacleTrack>& tracks,bool overloaded,
    const Eigen::Vector3d& a,const Eigen::Vector3d& b,double radius,double now,double begin,double end) {
    if(overloaded||!std::isfinite(now)||end<begin)return false;
    for(const auto& track:tracks) {
        const double age=now-track.stamp;
        if(age<-.02)return false;
        if(age>.5)continue;
        const double t0=std::max(0.,age+begin),t1=std::max(0.,age+end);
        const Eigen::Vector3d ra=a-track.point-t0*track.velocity,rb=b-track.point-t1*track.velocity;
        const Eigen::Vector3d delta=rb-ra;
        const double u=delta.squaredNorm()>1e-16?std::max(0.,std::min(1.,-ra.dot(delta)/delta.squaredNorm())):0.;
        // Sparse surface coverage, velocity error and bounded acceleration.
        // Unassociated observations use the configured 3 m/s reachability bound.
        const double speed_error=track.observations<2?3.:.35;
        const double bound=radius+track.radius+.03+speed_error*t1+.5*.5*t1*t1;
        if((ra+u*delta).norm()<=bound)return false;
    }
    return true;
}
} }
