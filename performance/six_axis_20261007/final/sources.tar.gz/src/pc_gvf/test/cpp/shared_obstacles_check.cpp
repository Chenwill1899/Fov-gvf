#include "pc_gvf/paper_guidance.hpp"
#include <iostream>
using namespace pc_gvf::depth_angular;
int main() {
    int before=0,after=0;Camera c(32,24,90,68,10.);
    for(int i=0;i<32;++i) {
        PaperConfig cfg;cfg.motion.body_radius=.48;cfg.motion.safety_margin=.02;cfg.motion.rollout_horizon=.8;
        cfg.motion.rollout_margin=.02;cfg.depth_uncertainty=.03;cfg.uncertainty_rate=.1;cfg.observation_timeout=.3;cfg.motion.max_accel=1.2;cfg.motion.brake_accel=1.2;cfg.motion.delay=.2;cfg.motion.rollout_horizon=.2;
        PaperGuidance baseline(cfg);cfg.shared_obstacles=true;PaperGuidance receiver(cfg);
        DepthObservation local(c,std::vector<double>(768,10.),Eigen::Vector3d(-2,0,0),fixedCameraRotation(),1.,1);
        SharedObstaclePacket peer;peer.source="robot_b";peer.session="boot_1";peer.frame="world";peer.stamp=1.;peer.sequence=1;
        ObstacleTrack hit;hit.point=Eigen::Vector3d(.6+.01*i,0,0);hit.stamp=1.;hit.radius=.2;hit.observations=3;peer.tracks.push_back(hit);
        if(!receiver.ingestShared(peer,1.,"world"))return 2;
        before+=baseline.motionSafe(local,Eigen::Vector3d::Zero(),Eigen::Vector3d(1,0,0),Eigen::Vector3d(1,0,0),1.);
        after+=receiver.motionSafe(local,Eigen::Vector3d::Zero(),Eigen::Vector3d(1,0,0),Eigen::Vector3d(1,0,0),1.);
        if(receiver.ingestShared(peer,1.,"world"))return 3; // echo is not independent evidence
        peer.sequence=2;peer.frame="unaligned_map";if(receiver.ingestShared(peer,1.,"world"))return 4;
        peer.frame="world";peer.stamp=.1;if(receiver.ingestShared(peer,1.,"world"))return 5;
        peer.stamp=2.;if(receiver.ingestShared(peer,1.,"world"))return 6;
        peer.stamp=1.1;peer.sequence=3;peer.tracks[0].stamp=1.1;peer.tracks[0].point=Eigen::Vector3d(4,4,0);
        if(!receiver.ingestShared(peer,1.1,"world"))return 8;
        local.stamp=1.1;if(!receiver.motionSafe(local,Eigen::Vector3d::Zero(),Eigen::Vector3d(1,0,0),Eigen::Vector3d(1,0,0),1.1))return 9;
        // A remote report cannot authorize motion through local unknown space.
        local.depth.assign(768,0.);if(receiver.motionSafe(local,Eigen::Vector3d::Zero(),Eigen::Vector3d::Zero(),Eigen::Vector3d::UnitY(),1.1))return 7;
    }
    SharedObstacleMap rotating_peers;
    SharedObstaclePacket packet;packet.session="boot";packet.frame="world";packet.stamp=1.;packet.sequence=1;
    for(int i=0;i<8;++i){packet.source="peer_"+std::to_string(i);if(!rotating_peers.merge(packet,1.,"world"))return 10;}
    packet.source="ninth";if(rotating_peers.merge(packet,1.,"world"))return 11;
    packet.stamp=1.6;if(!rotating_peers.merge(packet,1.6,"world")||rotating_peers.sources().size()!=1)return 12;
    std::cout<<"peer_only_hazards,independent_map_accepted,shared_map_accepted,invalid_packets_accepted,remote_free_authorizations\n32,"
        <<before<<','<<after<<",0,0\n";
    return before==32&&after==0?0:1;
}
