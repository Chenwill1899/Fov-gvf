#pragma once
#include <Eigen/Core>
#include <Eigen/Geometry>
#include <cmath>
namespace pc_gvf { namespace depth_angular {
// Schmitt-style angular hold is relative to the last accepted operator
// direction, never to the obstacle-avoidance output. Slow turns accumulate.
class OperatorIntent {
public:
    Eigen::Vector3d update(const Eigen::Vector3d& raw,bool enabled) {
        if(!raw.allFinite()||raw.norm()<1e-5){anchor_.setZero();return raw;}
        if(!enabled){anchor_=raw.normalized();return raw;}
        const auto direction=raw.normalized();
        if(anchor_.norm()<.5||std::atan2(anchor_.cross(direction).norm(),anchor_.dot(direction))>.018)
            anchor_=direction;
        return raw.norm()*anchor_;
    }
private:Eigen::Vector3d anchor_=Eigen::Vector3d::Zero();
};
} }
