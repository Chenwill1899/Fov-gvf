# ISAAC-DATA 全目录项目索引

2026-10-07 17:33 — **EGO1P5六方向方案、实现及逐项消融完成；整体运行全面优胜未通过。** 主构建、核心31/31、平台15/15、64种组合重放通过；18次目标安全到达、12次手柄等效运行安全审计通过，30次均扫掠重叠/外部保护0。第二版③⑤平均70.039s慢于基线69.256s，操控jerk也略退，故六项默认均关闭，保留独立开关和条件收益。21个继承状态关闭新开关后与原P5决定一致，P3/P4源文件哈希未改。完整失败、两版冻结、代码索引与手柄指令见[六方向报告](../EGO1P5/SIX_AXIS_OPTIMIZATION.md)，[机器汇总](../EGO1P5/performance/six_axis_20261007/completion_summary.json)。动态/共享分别有解析闭环/合成ROS证据，未做动态Isaac、多机实飞、传感器标定或人类被试。下方旧条目保留历史含义。

2026-10-07 16:27 — **EGO1P5完整复制检查点已建立，EGO1P3原样保留。** 复制3978文件/4467条目，内容、元数据和无共享文件inode核验通过；P5只在复制阶段适配8项路径/实验身份，算法保持v22。独立主构建成功，复制检查点CTest22/22、平台15/15，未由复制任务启动新飞行。新目录说明包含算法模块、参数、正式收益与退化、来源最新147.5s手柄运行及633.340ms计算峰值。接续“六方向优化”已在P5另行开始，当前工作树有新算法改动与基线试验，全部保留；复制测试不代表这些后续修改已通过。见[EGO1P5状态](../EGO1P5/EGO1P5_VERSION.md)和[工作日志](../EGO1P5/WORK_LOG.md)。

2026-10-07 02:33 — **EGO1P3连续360°融合实现及24轮冻结对照完成，全面优于EGO1P2未通过。** 新版不再预选单个90°相机；扫向误差30.681→7.534°、进展21.136→28.413m、停车.717→.250s，但独立旋转误差/进展/jerk退化，固定目标两版5/5安全到达、均值69.717→70.143s。24轮整段机体扫掠重叠/外部保护0、限速契约通过，CTest22/22、ROS缺帧/未知/过期拒绝通过。联合覆盖证明5→7层、1024预算不变；P2原2922文件未改，125份冻结源及24轮元数据一致。EGO1P4独立保留，未合并；所有探索及失败保留，未提交推送。详见[EGO1P3验收](../EGO1P3/OMNI_ACCEPTANCE.md)。下方旧日期保持历史含义。

2026-10-06 新副本：按本会话用户要求，从当前EGO1P2完整复制建立 **EGO1P4**；EGO1P2原目录保留，独立EGO1P3未合并。本次仅适配新目录构建/运行/日志及实验标识，继承精确净空优化和局部历史冲突修复。新目录独立构建、核心20/20、平台15/15和21帧重放一致；未启动新导航或真实手柄动态验收。当前算法进展、已有证据和未通过事项见 [EGO1P4_VERSION.md](../EGO1P4/EGO1P4_VERSION.md)。来源成绩保持原版本标签，不宣称任意位置不卡住或导航全面领先。

2026-10-06：用户确认从EGO1P2完整复制建立EGO1P3，用于连续360°感知/控制优化；EGO1P2保留，当前对照验收进行中，尚无优胜结论。见[EGO1P3状态](../EGO1P3/EGO1P3_VERSION.md)。

2026-10-05 当前目录定位：按用户要求将 EGO1P1 完整复制到 EGO1P2，后续开发使用 EGO1P2；EGO1P1 保留为来源版本。本次仅适配新目录的构建/运行/日志/重放路径和实验标识，算法、参数、场景与历史实验不变。当前主链为深度候选 + 单三维矢量整形 + 完整运动/制动认证；全面优于旧算法仍未通过。EGO1P2 尚无新导航成绩，继承成绩仍属于 EGO1P1。当前状态与复制验收见 [EGO1P2_VERSION.md](../EGO1P2/EGO1P2_VERSION.md)，下方日期记录保留历史含义。

2026-09-28后续更新：EGO1P1连续通道/关键观测保留、短前视低速起步与失败帧重放已落地。
最终94秒两轮有输入停车6.93/19.30秒、最长1.53/3.48秒；67秒松手后再输入10秒位移7.95m。
最终5组全机体扫掠重叠及外部保护均0，CTest14/14、平台15/15、33帧重放一致。
静态场景保留近场关键深度来源，新增未知仍拒绝；仍有停顿/超时，严格50Hz及任意状态持续可控未通过。
当前结论见`EGO1P1/CONTINUOUS_ACCEPTANCE.md`，旧验收保留历史含义，未推送。


> 初次盘点日期：2026-09-10；新增条目标注各自更新日期。目录大小是 `du -sh` 快照，
> 会随构建和日志增长。

## 1. 一级目录总表

| 路径 | 当日大小 | 类型 | 项目介绍与当前状态 |
|---|---:|---|---|
| `HISTORY/` | 新建 | 统一记录中心 | 本次建立；保存项目索引、进展、规则与总日志 |
| `history/` | 4 KB | 旧占位目录 | 盘点时为空；Linux 区分大小写，今后统一使用大写 `HISTORY/` |
| `dragon-restaurant-diplomacy-html/` | 6.2 MB（2026-09-19） | HTML 课程演示 | 13 页 16:9 互动演示，围绕“龙餐馆外交”分析发展优先、全球治理与中国方案的边界；含讲者备注、可点击来源和 3 张概念视觉 |
| `Fov-gvf/` | 124 MB | 主 Git 工程 | FOV-GVF 原始开发仓库，分支 `feature/ego-swarm-cloud-navigation`，HEAD `d267feb` |
| `user/Fov-gvf/` | 93 MB | 人工控制副本 | 由当前 USER-EGO 重建；4 倍 Cloud、键盘方向 + C++ 深度避障、双层 dead-man、在线观测地图和性能统计 |
| `EGO1P4/` | 约803 MB（2026-10-06，完整复制后） | 当前会话后续开发副本 | EGO1P2完整复制；保留净空优化及静态局部历史修复，独立构建与回归通过，未做新导航；见EGO1P4_VERSION.md |
| `EGO1P5/` | 约1.3 GiB（2026-10-07，含继承/新实验及冻结包） | 当前六方向优化副本 | 基于P3 v22；六项可选实现和逐项消融完成，整体优胜未通过、默认六项关闭；31项核心/15项平台/30轨迹安全审计通过，见SIX_AXIS_OPTIMIZATION.md |
| `EGO1P3/` | 约1.1 GiB（2026-10-07，含实验及冻结包） | 保留的v22来源副本 | EGO1P5从此完整复制，原目录保留；v22完成24轮对照，扫向明显改善，旋转/目标部分退化，全面优胜未通过；22/22测试、24轮安全审计通过，见EGO1P3/OMNI_ACCEPTANCE.md |
| `EGO1P2/` | 约803 MB（2026-10-06） | 本次保留来源版本 | 已有精确净空优化与局部历史冲突修复；原样保留，EGO1P3与EGO1P4分别由此复制、彼此独立。原人工卡停全场景解决仍未验收 |
| `EGO1P1/` | 约773 MiB（2026-10-05，含Git与实验） | 保留来源版本 | 9月30日最终策略及全部未提交改动/失败记录原样保留；本次不再修改，后续使用EGO1P2；全面领先验收尚未通过 |
| `EGO1P0/` | 47 MB（2026-09-17） | 独立版本分支 | 从当前USER手柄避障基线建立；保留北通Mode 2、4倍Cloud、C++深度角域FOV-GVF、RViz和性能统计，使用独立colcon目录 |
| `user_ego/Fov-gvf/` | 93 MB | 自动导航副本 | 当前持续修改版本；固定起终点、深度直达导航、在线历史点云地图和双第三人称视图 |
| `备份/Fov-gvf/` | 90 MB | Git 备份 | 较早 `feature/ego-swarm-blender-navigation` 检查点，保留未提交场景适配修改 |
| `uav_project/` | 1.1 GB | 独立无人机项目 | Isaac ARL Robot 1、RTX Lidar、EGO-Planner、B-spline 跟随和 Lee/Thruster 闭环 |
| `ausimlab/` | 783 MB（2026-09-21） | 训练与部署验证工作区 | `ausim-rl` 只负责 Isaac 训练/策略导出，`sim2sim` 独立负责 Hiking/MuJoCo 验证，`sim2real` 暂为空 |
| `ego_swarm_blender/` | 70 MB | 场景资产工程 | 依据 EGO-Swarm 随机森林规则重建的 501 Mesh Blender/USD 场景 |
| `ego_swarm_cloud/` | 213 MB | 场景资产工程 | 依据 Perlin 3D 规则重建的 600 万栅格、719999 占据点 Cloud 场景 |
| `isaacsim/` | 31 GB | 第三方运行环境 | Isaac Sim `6.0.1-rc.7+release.42383.32955d8d.gl` 本地安装 |
| `IsaacLab/` | 239 MB | 第三方 Git 工程 | Isaac Lab `3.0.0`，当前 detached HEAD `ffff603`，链接本地 Isaac Sim |
| `InstinctLab/` | 64 MB（2026-09-18） | 第三方 Git 工程/本地适配 | Project Instinct 人形机器人强化学习环境，`main@de6b92f`；已适配并运行 G1 平地 locomotion |
| `instinct_rl/` | 1.4 MB（2026-09-18） | 第三方 Git 工程 | InstinctLab 配套 RL 库，detached `b1ee3f8`/v1.0.2，与本机 Torch 2.10 匹配 |
| `blender/` | 1.2 GB | 第三方运行环境 | Blender `5.2.1 LTS` 解压安装目录 |
| `isaac_ros_ws/` | 2.7 GB | ROS 2 工作区 | NVIDIA Isaac ROS `release-3.2` 的 AprilTag、NITROS、common 源码及构建产物 |
| `isaacsim_scripts/` | 32 KB | 示例资产/脚本 | `franka_scene.py`、`CAR.usd`、`MAGICCUBE.usd` 等独立 Isaac 示例 |
| `containerd/` | 4 KB | 系统管理目录 | 当前用户无读取权限；视为容器运行时数据，不属于项目源码 |
| `docker/` | 4 KB | 系统管理目录 | 当前用户无读取权限；视为 Docker 数据/挂载目录，不在本次整理中修改 |
| `lost+found/` | 16 KB | 文件系统目录 | 当前用户无读取权限；不是工程内容 |
| `.agents/` | 0 | 元数据占位 | 根目录代理配置占位；具体项目可能有自己的 `.agents/` |
| `.codex/` | 0 | 元数据占位 | 根目录 Codex 配置占位；具体项目可能有自己的 `.codex/` |
| `.git/` | 0 | 不完整占位 | 根目录不是有效 Git 仓库；不能用根级 `git log` 代表全部项目 |

## 2. 一级独立文件

| 文件 | 类型/版本 | 作用与状态 |
|---|---|---|
| `blender-5.2.1-linux-x64.tar.xz` | Blender Linux 安装压缩包，366 MB | `blender/` 的离线安装来源；SHA256 校验条目通过 |
| `blender-5.2.1.sha256` | 官方多平台校验列表 | 包含多个平台文件；本机只存在 Linux 包，因此整体 `sha256sum -c` 会对其他平台报缺失 |
| `clash_verge` | Debian 包，`clash-verge 2.5.2 amd64` | 网络代理应用安装包，与无人机算法无直接关系 |
| `AGENTS.md` | 本次新增根级规则 | 要求所有后续项目修改同步写入 `HISTORY/CHANGELOG.md` |

## 3. 项目关系

```text
Fov-gvf（有 Git 历史的开发主线）
├── user/Fov-gvf       基于当前 USER-EGO 重建的 4 倍场景人工键盘控制副本
├── EGO1P0             2026-09-17从USER北通手柄+避障状态冻结出的独立目录版本
├── EGO1P1             2026-10-05保留的三维控制/认证与对照实验来源版本
│   └── EGO1P2         2026-10-05完整复制建立，保留为P3/P4共同来源
│       ├── EGO1P3     2026-10-06独立复制；连续360°v22保留来源
│       │   └── EGO1P5 2026-10-07完整复制P3；接续独立开发
│       └── EGO1P4     2026-10-06独立复制；另一会话六方向研究
├── user_ego/Fov-gvf   自动起终点副本，当前主要修改对象
└── 备份/Fov-gvf       较早 Blender 场景适配备份

ego_swarm_blender ──> Fov-gvf 系列的旧大场景输入
ego_swarm_cloud   ──> USER 与 USER-EGO 当前默认场景和 occupancy/ESDF 输入

isaacsim + ROS 2 Humble ──> Fov-gvf 系列和 uav_project 的仿真基础
IsaacLab ──> uav_project 的 ARL Robot 1、Lee 控制与 Thruster 能力来源
isaacsim + IsaacLab + instinct_rl ──> InstinctLab 的 G1/H1 强化学习仿真运行栈
ausimlab/ausim-rl -- policy.yaml + ONNX --> ausimlab/sim2sim
                                      └-> ausimlab/sim2real（预留空目录）
uav_project/ros2_ws ──> EGO-Planner 和自定义 ROS 2 跟随/适配包
isaac_ros_ws ──> 独立 NVIDIA Isaac ROS/NITROS/AprilTag 工作区
```

## 4. 版本库状态

### `Fov-gvf/`

- 远程：`https://github.com/Chenwill1899/Fov-gvf.git`
- 分支：`feature/ego-swarm-cloud-navigation`
- HEAD：`d267feb73ff91a2bbb53bf7b99bc2656cc081d24`
- 提交说明：`Add 4x EGO-Swarm Cloud ESDF navigation`
- 盘点时工作树：无已报告未提交修改。

### `备份/Fov-gvf/`

- 分支：`feature/ego-swarm-blender-navigation`
- HEAD：`895078efb3cdb9aac9d2345098551edc96723fab`
- 保留未提交修改：Isaac 场景准备/运行脚本、launch、新 `scenes/ego_swarm/` 等。
- 用途是回溯，不应在未明确要求时清理或覆盖。

### `IsaacLab/`

- 远程：`https://github.com/isaac-sim/IsaacLab.git`
- 版本文件：`3.0.0`
- 状态：detached HEAD，提交 `ffff603eafc6b74264a5261cc0183d6a65390d78`。
- `_isaac_sim` 符号链接指向 `/home/starry/isaac-data/isaacsim`。
- 2026-09-18 为 InstinctLab/URDF Importer 3.0 增加一处接触 API 子连杆遍历兼容修改，
  工作树因此不再干净；详见统一变更日志。

### `InstinctLab/`

- 远程：`https://github.com/project-instinct/InstinctLab.git`
- 分支/HEAD：`main`，`de6b92f01eb155d51f30e8ed1ea7aecd2eb1f057`。
- 用途：G1/H1 locomotion、动作模仿、感知、VAE、HOI、BeyondMimic、Parkour 等任务。
- 当前状态：存在面向本机 Isaac Sim 6/Isaac Lab 3.0 的未提交兼容修改；G1 平地
  locomotion 已完成 300 步 headless 和 Kit 可见运行，其余任务需单独安装数据/依赖并验证。

### `instinct_rl/`

- 远程：`https://github.com/project-instinct/instinct_rl.git`
- 状态：detached HEAD `b1ee3f84983e10da385eafcd7da1f010e34f01ca`（v1.0.2），工作树干净。
- 用途：InstinctLab 的 PPO/Actor-Critic 训练与推理支持；以 editable 方式装入 Isaac Python。

### `ausimlab/`

- `ausim-rl/`：分支 `integrate_hiking_mujoco`，HEAD `f8d4a052557e1b6f6b771f9fa26db006aa0f00dc`；
  训练专用，正式命令仅含 train/play/evaluate/export/check，工作树干净。
- `sim2sim/`：独立 Git 仓 `main@6b22b6912cb501502342337e49af57aa5feb0adb`；拥有 Hiking
  task 算法、MuJoCo/ONNX backend、canonical scene 与验收测试，工作树干净。策略、bundle、
  runs、third-party binaries 和 vendor 为本机忽略内容。
- `sim2real/`：物理空目录，等待真机通信、安全门禁和实机验收设计。
- 2026-09-21 已在隔离旧顶层仓库后完成 8 秒真实深度楼梯验收；正式回执见统一变更日志。

### `isaac_ros_ws/src/`

- `isaac_ros_apriltag`：`release-3.2`，工作树未报告修改。
- `isaac_ros_nitros`：`release-3.2`，工作树未报告修改。
- `isaac_ros_common`：`release-3.2`，两个 Dockerfile 有本地修改，必须保留。

## 5. 非源码生成目录

以下内容通常可重新生成，不应把其每个文件逐条写入历史，但构建结果应记录：

- ROS/colcon 的 `build/`、`install/`、`log/`；
- Python 的 `__pycache__/`、`.pytest_cache/`；
- Isaac Sim 的 `kit/logs/`、shader cache 和运行缓存；
- UAV 的运行日志目录，但关键验收日志和 `.pre_*` 源码备份不可随意删除。
