# ISAAC-DATA 统一变更日志

### 2026-10-07 17:38 — [EGO1P5] 六方向最终归档与验收结论

- 状态：六项方案、实现和逐项消融完成；整体运行全面优于修改前的要求未通过，默认保留实测基线，六项为可选能力。
- 目的：完成最终验证、冻结源码和二进制，给出可复现结果及可直接使用的手柄命令。
- 项目路径：`/home/starry/isaac-data/EGO1P5`。
- 涉及文件：六模块及控制器/launch/消息/测试共38项运行源差异；SIX_AXIS_OPTIMIZATION.md、README.md、EGO1P5_VERSION.md、WORK_LOG.md；performance/six_axis_20261007下汇总/图/冻结/原始实验；统一HISTORY的README/FOV_GVF_FAMILY/PROJECT_INDEX/CHANGELOG。
- 修改内容：保持原四相机全向候选、7层/1024预算联合完整证明与.48/.58m包络；新增原生深度置信下界、动态相对扫掠、SE(3)残差增量场、有限期球面原证据、人工小角EMA与连续转向直通、带来源和时间约束的共享占据。最终六开关均关闭，参数与实测v2基线一致；动态开启时≤.1s采样/≥32容量修复已通过新回归。文档区分复制历史、各阶段真实证据和未验证事项。
- 验证：主入口最终构建成功，CTest31/31；9个机制检查全过、64/64组合重放；平台15/15（平台之后未修改）。最终21继承状态关闭新机制与原P5二进制决定完全一致；增量均值146.939→147.388ms无收益，最大约2.45s，未隐瞒。P5新16卡停帧×3配对158.452→5.289ms，48/48均接受。全量机器汇总18/18目标安全到达、12/12人工轨迹安全，30条完整扫掠重叠0、外部保护0。v2基线/③⑤各3轮69.256/70.039s、jerk1.695/1.859；手柄各2轮方向误差9.419→9.393°而jerk4.534→4.562，整体优胜未通过。ROS共享危险使独立.5/共享0，解除恢复约.493；全开两节点各92接收/92错frame拒绝，均为固定合成机位。51份Python AST、3份Shell语法、git diff --check、报告本地链接通过。P3的125份、P4的139份受保护源SHA均未改。
- 影响与边界：噪声错误机体认证8→0；动态解析闭环碰撞5→0（不是30条Isaac之一）；窄FOV已见方向0→74；人工解析抖动TV约-91.1%；同伴危险32→0均为限定场景主指标。未做传感器标定、动态Isaac、多机实飞或人类被试。新增超时前端捷径未在3次v2组合运行触发，不声称整链路CPU提速已证实。无提交推送，未启动持续人工驾驶。
- 回滚/备份：baseline、逐阶段、final第一版、frontend_followup第二版均保留；最终accepted_optional冻结151份运行源、两二进制及SHA，归档5份ROS原始日志；测试初次ABI/环境失败、模拟退化和完整原始结果均保留。所有实验命令保持唯一标签，不覆盖既有结果。
- 后续事项：当前可直接通过主入口手柄运行基线，报告给出六项开关和逐项复现命令。整体优胜仍需针对动态/噪声/盲区实际场景和更大样本验证；共享自由空间/SLAM与自动坐标配准不属于本次实现。


### 2026-10-07 — [EGO1P5] 第二版30轮总验收完成，保留可选机制，默认回到已测基线配置

- 状态：六项实现与机制消融完成；用户要求的整体运行更优未通过，不能宣称全面成功。
- 目的：根据真实闭环全量结果选择默认，避免用单项理论/离线收益替代整机收益。
- 项目路径：`/home/starry/isaac-data/EGO1P5`。
- 涉及文件：launch/isaac_cloud_navigation.launch.py、paper_guidance.cpp、dynamic_obstacles_check.cpp；报告和最终汇总目录accepted_optional。
- 修改内容：六个新机制默认均关闭，保留独立开关及已验证场景的可选能力；FOV_GVF_INCREMENTAL_FRONTEND只有③开启且超时后才可能生效。复查动态状态发现静态1s采样大于动态.5sTTL，改为动态模式≤.1s采样、至少32份容量，并补充证据不断档检查；不改变默认静态模式。
- 验证：第二版基线3/3安全到达69.256s，③⑤3/3安全到达70.039s，停车均.250，jerk1.695→1.859；第二版操作各2轮安全，角误差9.419→9.393°、进展16.449→16.454m，jerk4.534→4.562仍略退。前端捷径本批3轮未实际触发，因此仅资格/当前证明回归通过，不声称真实CPU捷径速度已验收。①③旧组70.642s明显改善①单开125.933s；作为条件收益保留。两版本与各阶段累计30条Isaac轨迹安全审计0/保护0，确切汇总待最终脚本核验。
- 影响与边界：六项各自机制目标有可复现收益，但理想静态Cloud不应一键全开；动态/窄FOV/共享试验分别为解析、几何、ROS合成证据，未做动态Isaac、真实多机飞行或人类被试。默认配置就是本任务已实测的all-off基线，无新增强制算法介入。
- 回滚/备份：baseline、各阶段、第一版final和第二版frontend_followup冻结及全部退化保留；无提交推送，P3/P4不改。
- 后续事项：验证动态采样补丁、最终源码/参数/安全汇总及文档；使用者可按已标定噪声、动态模型或短期盲区需求选择相应开关。


### 2026-10-07 — [EGO1P5] 冻结实跑发现③⑤退化，按原因修正前端恢复与连续转向

- 状态：首批最终冻结14轮已完成，全部安全；整体性能不通过，继续修正而非采纳最好一轮。
- 目的：解决增量核心之外的全向搜索导致的计算截止，以及角保持将慢转变为阶跃的问题。
- 项目路径：`/home/starry/isaac-data/EGO1P5`。
- 涉及文件：paper_guidance.hpp/.cpp、controller、operator_intent.hpp、launch、incremental_field_check/operator_intent_check、ros_shared_obstacles_probe.py；frontend_followup准备脚本/拟议补丁。
- 修改内容：仅在上一周期COMPUTE_DEADLINE且旧场目标仍满足.5s/意图资格时，先跳过重复前端候选，再做完整当前运动/制动认证；松手/失效清恢复状态，可由FOV_GVF_INCREMENTAL_FRONTEND关闭对照。人工小角噪声用球面归一化低通，三次同向变化识别连续转向直接通过，大转向/松手保持零附加帧延迟，角误差限.018rad。共享全开负探针max_depth_age从.5改.3以与.58包络一致（此前.60负例记录保留）。
- 验证：冻结目标baseline两轮71.017/69.533s，③⑤69.250/86.650s，其中第二轮停车12.517s；球面70.950/71.033s两轮。人工抖动开关各2轮均安全，但初版⑤jerk4.532→4.557、投影进展16.460→16.452、误差9.343→9.541°，慢转相位RMS .0288→.0338，判为退化。sphere恢复单对进展82.602→82.479、jerk3.829→3.961，未获整机收益。回退机制实验和所有完整轨迹保留。
- 影响与边界：新修正尚待构建/同样消融，不写通过。仅优化候选计算调度和人工微扰处理，当前完整证据证明与物理安全参数不变。临时预览脚本曾因exec共享变量导致写补丁目标路径错误，实际运行源未改，已修正预览输出。
- 回滚/备份：final/sources.tar.gz及冻结二进制记录第一版；新实验独立frontend_followup标签，不覆盖旧组。
- 后续事项：31项回归、操控/资格消融，复跑冻结目标及手柄；不满足收益则降为可选而非默认。


### 2026-10-07 — [EGO1P5] 六项机制逐项验收完成，最终组合冻结前检查

- 状态：31/31回归、⑥32例危险放行32→0、16种内部状态组合重放、三真实ROS进程共享命令对照通过；最终组合实跑待完成。
- 目的：在P5全向链上确认六项均可独立开关，冻结前补全外部预处理组合与默认候选。
- 项目路径：`/home/starry/isaac-data/EGO1P5`。
- 涉及文件：paper_guidance.cpp、incremental_field_check.cpp、six_axis_replay_check.cpp、launch；ROS共享/全向探针、最终实验目录。
- 修改内容：增量求解每次先清有效位，防止调用者传入旧valid状态在全阻塞域提前返回；扩展含深度预处理及人工输入的64组合重放。候选默认设③⑤开，①②④⑥关。ROS探针补齐.48/.58与1.2动力学参数，先前未显式指定的全开负探针半径.605仅作为消息/未知拒绝证据，不冒称原Cloud参数。
- 验证：ROS共享正向对照使用.48/.58/1.2，clear两节点平均命令.4991，peer_hazard本机独立.5/共享0，cleared共享.4931；606样本，危险解除恢复。全开负探针两机器人各92接收/92错坐标拒绝，P5 --omni缺前相机/未知/过期/松手检查通过；均非飞行。31/31在新增有效位和64组合补充前通过，补充后即将重跑。
- 影响与边界：尚无全面导航优胜结论；后续固定目标、操作抖动与球面恢复均使用冻结二进制和原场景，逐项保存不利指标。
- 回滚/备份：各阶段src快照、基线二进制、原ROS消息日志与失败全部保留，P3/P4源码哈希最终复核。
- 后续事项：最终构建、64组合、平台回归与继承重放；固定目标/人工轨迹成对比较，更新报告、HISTORY与可直接运行的手柄指令。


### 2026-10-07 — [EGO1P5] ⑤操控消融通过，⑥多机器人共享占据接入

- 状态：⑤29/29及闭环微扰消融通过；⑥实现完成待构建与ROS验证。
- 目的：允许对齐同坐标系的机器人共同维护短时占据证据，补充各机独立观测的遮挡危险。
- 项目路径：`/home/starry/isaac-data/EGO1P5`。
- 涉及文件：paper_guidance.cpp、shared_obstacles.cpp、controller、launch、SharedObstacles.msg、两包CMake、shared_obstacles_check/six_axis_replay_check、tools/ros_shared_control_probe.py、ros_shared_obstacles_probe.py。
- 修改内容：按robot/session/sequence/time融合占据和速度；错坐标、未来/陈旧、乱序、超量/异常消息拒绝，最大8源，消息保留原观察时间，不转发他人证据冒充自己。补充过期源回收，避免8个离开机器人永久占槽。共享危险作用于完整运动/制动段，本机未知仍拒绝。
- 验证：⑤指令总变化.241851→.000104623，前进11.3515→11.3518m，松手/大转向附加延迟0帧；累计慢转误差不超过.018rad，29/29通过。此为生产核心解析闭环；真实Isaac等效输入将在最终冻结版本成对执行。
- 影响与边界：提供共同占据地图，不包含多机SLAM/自动坐标配准或共享自由空间授权。时钟和world对齐、独立robot_id、传感器/控制话题隔离是使用条件；无真实多机飞行验收。
- 回滚/备份：stage5_operator/sources.tar.gz及全部先前阶段；P3/P4保持独立。
- 后续事项：⑥31项回归、32例遮挡危险开关消融、三真实ROS进程命令对照、全开组合拒绝；冻结后做目标/手柄完整轨迹及文档收尾。


### 2026-10-07 — [EGO1P5] ④盲区证据消融通过，⑤操控角滞回接入

- 状态：④28/28及两个消融通过，⑤待构建。
- 目的：保留松手/大转向即时响应的前提下，减少微小手抖反复扰动三维避障指令。
- 项目路径：`/home/starry/isaac-data/EGO1P5`。
- 涉及文件：operator_intent.hpp、controller、launch、CMake、operator_intent_check；isaac_operator_jitter_trace.json、tools/run_six_axis_manual.py、analyze_omni_comparison.py。
- 修改内容：人工输入相对于最后接受输入方向使用.018rad角滞回，速度幅值保持，松手清空，大改向即响应，慢转累计过阈值后更新；固定目标不经过该滤波。诊断输出启用状态和输入改变量。新增同二进制交替重复手柄等效消融与独立整段扫掠审计入口，原平台/场景不变。
- 验证：④74个窄FOV已见方向认证0→74，过期放行0，矛盾借用引用撤销通过；原生76800点×80帧维护预筛选与精确基线保留证据一致。①③Cloud两轮71.567/69.717s安全到达，平均70.642s，较①单开125.933s恢复，但仍比初始基线70.142s慢，完整扫掠0/保护0。
- 影响与边界：球面74例为三维证据几何测试，不是74次真实飛行。操控测试无真实人类被试，不声称主观满意度提升。
- 回滚/备份：stage4_spherical/sources.tar.gz及此前阶段冻结；全部旧失败保留。
- 后续事项：⑤指令抖动/慢转/松手回归，再完成⑥共享占据ROS控制消融及最终组合实跑。


### 2026-10-07 — [EGO1P5] ③快照耗时显著降低，④球面记忆接入

- 状态：③26/26回归及冷暖解消融通过；④实现完成待构建。
- 目的：利用短期已观测的侧后方向，解决窄FOV转头后仅因历史采样稀疏失去证据的问题。
- 项目路径：`/home/starry/isaac-data/EGO1P5`。
- 涉及文件：paper_guidance.cpp、controller、CMake、spherical_memory_check/spherical_ingest_check；tools/compare_six_axis_replays.py。
- 修改内容：24×12世界球面索引、最多48份原始观测出处、4s寿命和.05m/s年龄扩张；动态模式有效寿命.5s。保留相机原视锥和命中矛盾撤销，像素预筛选只排除确定不矛盾点。P5仅在当前统一候选缺失时查询记忆，避免覆盖有效四相机提案；未知仍不能由记忆插值授权。
- 验证：③100帧冷解17450→7119次迭代，最大势误差1.695e-9；本次P5的16卡停帧×3交替对照，平均158.452→5.289ms，最大173.803→6.585ms（含进程启动），两侧48/48核心接受，关闭增量与修改前决定完全一致。①③两轮Cloud验证正在执行，不由快照推断实际闭环结论。
- 影响与边界：球面记忆是有限期有出处证据，不是无盲区传感器或永久地图；P3/P4未改。
- 回滚/备份：stage3_incremental/sources.tar.gz与二进制，所有失败保留。
- 后续事项：④窄FOV已见方向/过期/矛盾消融、维护开销及Cloud组合检验；再接入⑤。


### 2026-10-07 — [EGO1P5] ②验收通过，③自运动补偿增量调和场接入

- 状态：②25/25与两项动态消融通过；③待构建。
- 目的：减少相邻帧重复冷解及实跑出现的长时计算截止停车。
- 项目路径：`/home/starry/isaac-data/EGO1P5`。
- 涉及文件：paper_guidance.cpp、controller、launch、CMake、incremental_field_check；intent_response_check的重放魔数I→L；tools/run_six_axis_ablation.py与SIX_AXIS_OPTIMIZATION.md。
- 修改内容：旧场按采集位姿旋转/平移投影，解Aδ=b-Aφ；残差异常退回冷解。无新提案时短时复用旧场世界目标，但当前完整运动证明必须通过，累计意图改向会失效。保留P5的7层完整包含证明。③初始默认关闭，等待验收。
- 验证：②初次因copy2旧mtime导致测试与库ABI不同而失败，强制更新时间重编译后仅旧魔数断言失败；修正格式预期后25/25，行为断言不改。动态穿越40危险放行→0；解析闭环5碰撞→0，空场和离开障碍负控制通过。①Cloud两轮均安全到达、扫掠0，但平均125.933s较原70.142s明显退化，平均停车54.458s，不能默认开启。失败和退化日志全保留。
- 影响与边界：动态闭环为生产核心+解析深度渲染+同动力学，非Isaac动态场景或真机。增量场仅提案，不复用旧几何授权。
- 回滚/备份：stage2_dynamic/sources.tar.gz，baseline及stage1冻结保留；P3/P4未改。
- 后续事项：③26项回归、冷/暖解及本次P5原生16帧卡停快照消融，再接入④。


### 2026-10-07 16:27 — [EGO1P5] 完整复制检查点验收完成，保留并行后续优化

- 状态：用户要求的完整复制、原版本保留、算法/进展/状态说明完成；构建与既有回归通过，后续六方向优化属于另一项进行中的工作。
- 目的：在EGO1P5建立可追溯的新副本并准确描述来源状态，不覆盖EGO1P3或混淆后续测试范围。
- 项目路径：`/home/starry/isaac-data/EGO1P5`。
- 涉及文件：全部3978文件/4467条目复制；scripts/build_isaac_ros_workspace.sh、scripts/run_isaac_fov_gvf_navigation.sh、src/pc_gvf/launch/navigation_benchmark.launch.py、tools/run_navigation_benchmark.py、analyze_navigation_benchmark.py、run_omni_comparison.py、verify_navigation_replays.py、ros_vector_guidance_probe.py；新EGO1P5_VERSION.md、EGO1P3_README.md及README/AGENTS/WORK_LOG；performance/copy_from_ego1p3_20261007证据；HISTORY/README、PROJECT_INDEX、FOV_GVF_FAMILY、CHANGELOG。
- 修改内容：复制包括隐藏文件、Git、全部未提交内容、场景、成功/失败实验和最新手柄日志。仅8项运行文件适配P5根目录、独立构建/安装/日志/重放和实验身份，保留P3作为显式对照项；复制检查点117份其他运行源与v22一致，算法/参数/场景/桥/手柄映射不改。来源README另存原文，旧验收及冻结包不改标签。
- 本次实际验证：主Shell构建3包成功（16:15:34日志结束）；CTest22/22（16:17:31结束）、平台15/15；45份Python AST、3份Shell语法通过。配置构造检查解析到/tmp/fov_gvf_ego1p5_isaac_install/pc_gvf及其控制器，360°开启；未启动节点或仿真。复制前后内容/元数据SHA一致，无共享普通文件inode，最终16:24核验EGO1P3原3978文件/4467条目无变化或新增缺失。
- 并行边界：检查发现另一个“六方向优化”工作已在新P5冻结baseline并运行试验，随后约16:20起修改CMake、控制节点、默认launch并新增不确定性模块。其.git/index、公共性能日志、新源码与试验全部保留，未回滚/覆盖。另一个任务的NumPy2首轮失败及后续修正记录属于该任务；本复制任务在PYTHONNOUSERSITE=1环境下的22/22与15/15结果独立归档。
- 证据：copy_verification.json与source_manifest.json证明适配前完整复制；final_copy_integrity.json证明原P3未变并列出观察到的后续运行源变化。copy_checkpoint_runtime.tar.gz从保留P3加本次8项确定性适配重建125份源，117份未适配源与后续任务所存基线交叉核对一致；不是当前正在变化的工作树快照。build.log、ctest.log、platform_tests.log、syntax_checks.json、configuration_check.json及复制摘要均位于本次独立证据目录。
- 来源状态说明：v22连续扫向明显优于P2但全面优胜未通过，独立旋转和目标部分退化，正式24轮和旧失败全部保留。新读取到来源20261007_160119手柄模式147.5s仿真USER_EXIT、外部保护0、avoid峰值633.340ms，未重演/新审计；不能把长指令不变间隔直接认作卡停，也不能把它改标为P5新成绩。
- 影响与边界：EGO1P3原样保留，EGO1P2/EGO1P4未修改；P5继续共用ROS域42和单实例锁。版本说明将复制检查点与随后六方向工作明确分开，当前源码是否通过以其后续WORK_LOG为准。
- 回滚/备份：原EGO1P3完整保留；新目录复制清单、纯路径适配运行源包及后续任务baseline均保留。Git分支名仍继承ego1p1；本复制任务未提交或推送，未启动新导航/手柄动态验收。
- 后续事项：本次复制请求无剩余事项；后续算法优化及其验收由正在进行的独立任务记录，不将其未完成状态写成本复制失败或测试通过。


### 2026-10-07 — [EGO1P5] ②动态障碍接入，统一可重放扩展状态

- 状态：第一项23/23回归通过；第二项接入完成，待构建消融。
- 目的：把障碍运动纳入预测制动约束，避免仅凭当前静态图放行穿越轨迹。
- 项目路径：`/home/starry/isaac-data/EGO1P5`。
- 涉及文件：paper_guidance.hpp/.cpp、dynamic_obstacles.hpp/.cpp、paper_replay.cpp及重放工具、controller、CMake、dynamic_obstacles_check/dynamic_closed_loop_check；spherical_memory/shared_obstacles状态模块预接入序列化，尚未接入控制流程。
- 修改内容：复用P4世界坐标稀疏跟踪与相对运动段检验，速度/加速度误差界，数据超量拒绝；动态开关关闭长期静态自由体积，历史限制.5s且扩张不确定性。P5的四相机候选及7层完整包含保留。扩展重放至兼容P4的L格式，为后续增量/球面/共享状态留出相同编码。
- 验证：第一项1000样本深度高估488→0、虚假机体放行8→0；原生扩张前景28格对粗图42格，23/23通过。原Cloud不确定性两轮正在运行，尚未判定导航收益。
- 影响与边界：动态模型不保证不可观测/超速度界对象；最近邻关联有误差，动态闭环待执行。其他四项目前无控制行为改变。
- 回滚/备份：stage1_uncertainty/sources.tar.gz及二进制，原始baseline保留。
- 后续事项：动态解析闭环、运动补偿误报检查，再逐项启用③④⑤⑥。


### 2026-10-07 — [EGO1P5] ①原生分辨率深度不确定性实现

- 状态：实现完成，阶段构建/消融进行中。
- 目的：将深度量测距离误差、位姿界和遮挡/无效像素纳入自由空间下界，减轻旧P4粗分辨率形态扩张的额外保守性。
- 项目路径：`/home/starry/isaac-data/EGO1P5`。
- 涉及文件：src/pc_gvf/include/pc_gvf/depth_uncertainty.hpp、src/depth_uncertainty.cpp、depth_angular_controller_node.cpp、launch/isaac_cloud_navigation.launch.py、CMakeLists.txt、test/cpp/depth_uncertainty_check.cpp。
- 修改内容：移植P4误差模型并改为原生深度先处理再保守降采样；sigma=.005+.001*z²，3sigma+.01m，抵扣原包络已计入的.03m径向界；边缘只扩原生1像素，未知不填补。原始命中保持用于矛盾撤销；默认关闭，须按传感器标定参数。
- 验证：基线CTest首轮20/22，用户NumPy2污染导致2项Python ABI失败；加PYTHONNOUSERSITE=1后22/22。第一轮基线目标69.267s到达，第二轮进行中，完整几何审计待执行。
- 影响与边界：模型为参数化下界，尚未实传感器标定，不宣称3sigma绝对保证或未知变自由。
- 回滚/备份：baseline冻结完整源及二进制，功能可由FOV_GVF_DEPTH_UNCERTAINTY关闭。
- 后续事项：构建与固定种子噪声/轮廓消融、真实Cloud开关比较；未通过收益不得默认开启。


### 2026-10-07 — [EGO1P5] 六方向优化启动，冻结当前v22副本为独立基线

- 状态：读取源码与历史完成，实现和新实验进行中。
- 目的：按用户六项要求逐项实现、消融，保留所有退化，以本目录当前状态比较。
- 项目路径：`/home/starry/isaac-data/EGO1P5`。
- 涉及文件：`performance/six_axis_20261007/baseline/`；后续各阶段追加精确范围。
- 修改内容：冻结当前src/scripts/tools及根文档、控制器/重放二进制、launch；保存P3/P4源码哈希。P5已完成独立路径适配，本任务不再重复改名或重标历史成绩。
- 验证：读取复制构建日志成功；本任务核心回归和动态基线待运行，尚无P5优化收益结论。
- 影响与边界：保留四相机融合、7层/1024预算联合证明、.48机体/.58认证及真实1.2加减速度。不假定六项全开就全面优胜。
- 回滚/备份：本目录`performance/six_axis_20261007/baseline/sources.tar.gz`和SHA清单；不修改P3/P4。
- 后续事项：深度下界与遮挡建模、动态扫掠约束、场增量更新、球面历史证据、操控滞回、共享占据，逐阶段构建与开关消融，再做组合闭环与完整扫掠审计。


### 2026-10-07 16:15 — [EGO1P5] 完整复制EGO1P3并隔离路径，构建验证进行中

- 状态：完整复制及来源一致性核验完成，独立构建/回归进行中。
- 目的：按用户要求保留EGO1P3全部内容，并在新EGO1P5说明代码、算法、进展与已知边界。
- 项目路径：`/home/starry/isaac-data/EGO1P5`。
- 涉及文件：全部复制3978文件/4467条目；适配scripts两个主入口、navigation_benchmark.launch.py及5个tools脚本；新增EGO1P5_VERSION.md、EGO1P3_README.md，更新README.md、AGENTS.md、WORK_LOG.md；HISTORY/CHANGELOG.md。
- 修改内容：只将默认工程根、构建/安装/日志/重放前缀改为EGO1P5/ego1p5，实验工具增加P5身份并保留P3比较项；算法C++、默认导航参数、场景、桥与手柄映射不改。旧报告和冻结包不改标签；Git和全部未提交内容继承，不创建提交/推送。
- 验证：cp -a --reflink=auto复制前后逐文件SHA256和mode/uid/gid/mtime一致，源目录未变，无共享普通文件inode；来源125份运行源与v22冻结清单一致。独立构建/回归待执行，未运行新导航/手柄动态验收。
- 来源状态：v22连续扫向明显改善但全面优胜未通过，24轮安全审计0、目标5/5到达；另保留20261007_160119来源手柄运行，147.5s仿真USER_EXIT、外部保护0、avoid峰值633.340ms，未独立重演/审计，不能当P5新成绩。
- 影响与边界：保留EGO1P3原目录，EGO1P2/EGO1P4未修改。新旧仍共享ROS域42及单实例锁；临时构建产物不在原目录，P5使用新独立产物。
- 回滚/备份：完整来源EGO1P3及新目录performance/copy_from_ego1p3_20261007下来源清单、复制核验保留。
- 后续事项：完成独立主构建、现有测试、算法/历史证据未改和源目录完整性核验，更新版本说明及HISTORY总入口/索引。


### 2026-10-07 02:33 — [EGO1P3] v22完整24轮冻结验收完成，扫向改善、全面优胜未通过

- 状态：实现、构建、测试和完整对照完成；用户要求的主要工况全面优于EGO1P2尚未通过，明确保留五项失败判据。
- 目的：完成连续360°控制/感知实现后的成对重复验收，区分方向融合收益、安全和全面性能结论。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：src/pc_gvf下omni_depth.hpp/.cpp、depth_angular_controller_node.cpp、paper_guidance.cpp、两项新增C++测试及CMake/launch；scripts构建/运行入口与tools对照/审计/ROS脚本（精确19项运行差异见v22_runtime_changes.json与v22_diff_vs_EGO1P2.patch）；README.md、EGO1P3_VERSION.md、OMNI_ACCEPTANCE.md、WORK_LOG.md；HISTORY/README.md、PROJECT_INDEX.md、FOV_GVF_FAMILY.md、CHANGELOG.md；performance/omni_20261006下最终分析/冻结/图表/验证清单与汇总脚本。
- 最终实现：四路光轴深度按采集位姿与偏移反投影至world；180×37周期球面方向域额外接纳精确输入与历史世界方向，人工不再按最近90°相机切换。固定目标连续维护各子视图候选，真实通道已认证的精确目标方向提前返回。最终单矢量整形及完整运动/制动证明保留。联合观测包含证明递归5→7、1024内部细分预算不变，真实薄缺口/未知仍拒绝。
- 冻结协议：final_v22扫向/旋转各3对、恢复1对、目标5对，总24轮，交替顺序、共享锁串行、相同地图/输入/起终点。所有进程正常退出。无探索轮混入，没有丢弃失败或更改原严格判据。最终人工结果final_v22_analysis.json、目标omni_final_v22_analysis.json、完整表final_v22_results.md。
- 正向结果：扫向平均误差30.681→7.534°（-75.4%），向量RMS .550→.181m/s，投影进展21.136→28.413m（+34.4%），停车.717→.250s，jerk4.894→2.302，避障均时1.418→.363ms。新版三个工况旧相机规划切换均0；旧版分别5/14/6次。恢复进展81.917→82.529m、停车1.250→1.233s，仅单对。
- 退化与失败：旋转误差11.321→12.343°、向量RMS .570→.608、进展92.044→89.796m（-2.4%）、jerk3.161→3.735，计算均时.611→1.359ms；停车.500→.494s。目标两版5/5安全到达，均值69.717±.923→70.143±1.267仿真秒、墙钟70.318→73.279，停车.240→.250s；jerk2.108→2.011有所下降。未通过spin角误差/RMS/进展、goal耗时/停车五项严格门槛，不能写成全面领先；.010s停车差接近采样周期但仍照原判据记失败。
- 计算边界：P3旋转及目标各有累计1/60s计算截止状态，目标计算峰值101.910ms；不能声称严格50Hz。各工况p95/峰值与基线所有退化列在完整数据表。渲染图表已目检，首对轨迹只作示意，统计使用所有重复；目标底图是低空XY投影，不替代三维安全审计。
- 安全/回归：24轮完整.48m扫掠球对原占据体素/地面重叠0、外部保护0，速度≤2m/s、垂向≤1m/s、实测加速度≤1.2m/s²契约通过。主build成功，CTest22/22；平台15/15及原P2 CTest20/20为本任务早期通过、相关源码随后未改。45份Python AST、3份Shell语法、git diff --check通过。最终v22 ROS --omni在域83共享锁下运行通过缺前相机/未知/过期深度/过期输入/松手检查，日志归档；合成零输出拒绝不是飞行到达证据。
- 重放/完整性：21个旧状态4个原决定保持、17个原拒绝变为完整认证非零；v22与已测v21重放二进制相同，不称21/21决定一致。P2原2922文件/3257条目完全未改；125份冻结运行源、控制器/重放、24轮元数据及同协议SHA核验通过。安全核心变更有独立SHA清单，其余8项保护文件逐SHA未改。最终汇总final_v22_validation.json，不覆盖旧v5 validation_notes.json或v17失败结果。
- 影响与边界：实际手柄、GUI/RViz负载、其他地图/起终点、动态障碍、真机均未验收；四相机的近场/接缝/上下盲区保持未知。仅确认本批连续扫向更好；旋转候选稳定性、目标计算开销和全面优胜仍待解决。未修改EGO1P4、物理场景/桥/手柄映射/安全包络或实际动力学。
- 回滚/备份：EGO1P2原目录、v1至v22探索/失败及v22_frozen均保留；FOV_GVF_OMNI_DEPTH=0只关闭P3新前端，不等同完整P2（P3联合证明仍7层）。运行完整P2使用其原生目录/二进制；完整恢复P3可用冻结源主入口重建。无提交推送。
- 后续事项：全面性能要求未达标，不能标记全面优胜；后续应基于完整前端时序定位旋转退化及减少目标重复证据处理，再使用新冻结标签验证，不覆盖本批结果。


### 2026-10-07 — [EGO1P3] v22构建/目标探索通过，冻结完整24轮对照

- 状态：实现及核心回归完成，正式性能验收进行中，尚无全面优胜结论。
- 目的：以同一冻结版本比较连续扫向、独立转头、恢复和固定目标，避免用探索最佳轮代替正式结果。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：EGO1P3_VERSION.md、OMNI_ACCEPTANCE.md、WORK_LOG.md、HISTORY/CHANGELOG.md；performance/omni_20261006/v22_frozen及final_v22数据。
- 修改内容：当前文档明确固定目标连续维护局部候选池及已认证精确方向提前返回；修正“安全核心文件未改”的过期描述，联合覆盖上限5→7、预算1024及证据包含条件均明确记录。冻结125份运行源码、控制器和重放二进制；v22重放程序与v21字节一致。
- 验证：主入口build_v22.log成功，ctest_v22.log为22/22。目标探索三轮69.567/69.283/69.283s，3/3安全到达，均值69.378±.164s、停车.25s、jerk均值1.723，平均避障1.442/1.382/1.378ms；最大80.438/60.064/35.212ms。探索与正式统计隔离。
- 影响与边界：final_v22正式组为sweep/spin各3对、recovery1对、固定目标5对；交错顺序、同场景与输入、每轮原生二进制和launch哈希。测试期间不修改运行源码或重建。物理/动力学及另外8项受保护文件不变，paper_guidance.cpp差异有明确SHA清单。真实手柄、GUI/RViz负载、跨地图与真机未验收。
- 回滚/备份：v22_frozen与全部历史失败/探索数据保留；EGO1P2原目录继续保留。无提交推送。
- 后续事项：完成全部24轮、最终v22 ROS接口检查、独立安全/完整性审计并据全部结果更新验收结论。


### 2026-10-07 — [EGO1P3] v21证明修复通过，v22消除已认证固定目标方向的重复搜索

- 状态：v21核心/探索/ROS已通过，正式全面优胜仍未验收；v22待构建/目标探索。
- 目的：减少固定目标已有精确可认证方向时的额外侧视角候选计算。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：depth_angular_controller_node.cpp、版本/验收/工作日志、HISTORY/CHANGELOG.md；performance/omni_20261006下v21冻结、旧状态重放分类、ROS探针和探索数据。
- 修改内容：仅固定目标中，局部候选方向与世界目标方向点积>1-1e-12且已通过局部可达选择及全部真实证据走廊认证时直接返回该方向；其他观测仍完整接入认证，绕障时仍汇总各有效视角候选。人工模式逻辑保持v21，最终完整运动/制动证明不变。
- v21验证：新增解析union_refinement_check在原5层下明确失败，提升为7层、保持1024预算后主build/22项全通过。旋转单轮角误差9.895°、RMS .521m/s、进展91.348m、停车.5s、jerk4.326、安全审计0；计算截止实际累计1/60s，不能把日志1行说成1秒，最大avoid74.174ms。扫向7.355°/.178m/s/28.445m/.25s、安全审计0。
- v21目标：三轮69.050/69.750/70.883s，3/3安全到达、平均69.894±.925s、停车均.25s；探索均值不替代正式成对比较。日志显示直达尾段仍local_candidates=3，首轮平均避障2.293ms，为v22提前返回提供代码和运行依据。
- v21重放与接口：21个旧状态中4个原决定保持、17个原拒绝变为完整认证非零命令（原真实卡停5帧中的1帧+v17目标失败16帧）；这属于有意决策改善，不得写成21/21原决定相同。快照不含完整原始命中/前端时序，不宣称原现场已解决。ROS --omni缺前相机/未知机体/过期深度/过期输入/松手检查通过，日志归档。重放分类脚本首次误读摘要为frames，KeyError后按已记录目录读取并校验5帧数，错误记录保留。
- 影响与边界：包络证明包含关系、1024预算与所有物理/安全参数不变；paper_guidance.cpp仅5→7递归深度及注释变化已逐字反向校验，显式SHA差异在v21_frozen/intentional_core_changes.json。其余8项受保护文件继续按原SHA核验。
- 回滚/备份：v21_frozen完整125份源码、控制器/重放二进制；删除固定目标精确方向提前返回可回到v21。无提交推送。
- 后续事项：v22主build/22项核心、三轮目标探索；然后冻结完整sweep/spin各3对、recovery1对、目标各5轮。


### 2026-10-07 — [EGO1P3] 定位联合证明浅层拒绝，v21增加细分深度但保留工作预算

- 状态：离线反例已证实；解析回归及v21主构建/全套回归进行中，尚未动态验收。
- 目的：解决360°融合后多个真实观测联合覆盖机体却被有限层次包围球近似拒绝的可复现机制。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：src/pc_gvf/src/paper_guidance.cpp、src/pc_gvf/test/cpp/union_refinement_check.cpp、src/pc_gvf/CMakeLists.txt；版本/验收/工作日志及HISTORY/CHANGELOG.md；performance/omni_20261006下影子诊断脚本、结果、失败快照审计与v18目标五轮证据。
- v18正式结果：新旧均5/5安全到达、扫掠重叠/外部保护0；P2/P3均耗时69.283±.042/71.390±1.799s、墙钟69.303/74.567s、停车.237/.250s、jerk1.950/2.094，性能未胜出。因已有明确拒绝反例，v18人工正式组尚未开始，不能写成24轮完整比较。10轮元数据与124份冻结源一致性保留于v18_goal_integrity.json。
- 离线定位：仅复制冻结v17的核心源到/tmp/ego1p3_union_cert_diagnostic，建立从未安装/连接ROS的影子重放程序；编译和回放在共享锁下执行，不改变正在运行的正式组源码/二进制。原失败快照：5层/1024预算和5层/8192均拒绝，6层/1024仍拒绝；7层/1024证明.58m及+.01m余量，输出完整认证非零命令；8层额外开销更高。五次含进程启动/加载的重放墙钟中位5层约3.86ms、7层6.93ms、8层15.80ms，不能当在线控制计算时延。
- 解析反例：六个轴向已知球联合，完整覆盖半径R所需球半径可解析计算为max(d,sqrt(R²+d²-2Rd/sqrt(3)))；+8mm余量在5层拒绝、7层通过，-2mm真实薄缺口在5/7/8层始终拒绝。新增C++测试覆盖平移不变性、完整机体覆盖、薄缺口、缺失扇区、全未知及未知运动拒绝；先在旧核心证明测试失败，再改深度。
- 修改内容：仅把envelopeKnownImpl递归深度上限5→7，原1024次内部细分预算保持不变；所有被接受的盒子仍须由包围球完全包含于原真实证据，不使用表面采样授权。原先浅层已能证明的查询不增加递归。候选恢复v18，机体/认证半径、速度/动力学、保守深度/原始命中检查、未知拒绝、重放格式V18保持。
- 安全边界：本轮开始有意改变paper_guidance.cpp的证明精细度，不能继续说“安全核心文件未改”；认证包含关系和包络没有放宽。旧9文件完整性中此文件须列为明确修改，其余8项继续逐SHA核对。离线快照没有完整原始命中点与前端时序，证明改进不替代新实跑。
- 诊断失败：合成诊断首次把audit当stdout读取（实际写stderr），汇总IndexError；首次日志保留，合并stdout/stderr后重新汇总通过。不是核心验收通过的替代品。
- 回滚/备份：v17_frozen、v18_frozen、影子源/程序和解析诊断全部保留；恢复depth上限5并主入口重建可撤回此修正，无提交推送。
- 后续事项：完成先失败后通过的22项回归、重新分类旧快照变化、候选实跑及最终冻结成对比较。


### 2026-10-07 — [EGO1P3] v20插值退化撤回，恢复v18并开始目标五轮对照

- 状态：v20探索未通过；恢复v18准备冻结和固定目标五轮交错对照。
- 目的：保留实际有效的连续360°人工规划及固定目标候选连续性修正，不保留只在形式上更平滑却实跑更差的成本修改。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：src/pc_gvf/src/omni_depth.cpp、版本/验收/工作日志、HISTORY/CHANGELOG.md；performance/omni_20261006/v20_candidate、v18_frozen及后续omni_final_v18数据。
- 修改内容：球面源码完整恢复v17（俯仰附加1、最近格角域净空），控制节点保留v18固定目标连续局部候选池；校验节点与v18_candidate字节一致。新冻结标签v18，不把v19/v20探索混入。
- 验证：v20主build/21/21通过；旋转均角14.264°、RMS .696m/s、投影85.266m、停车.5s、jerk4.921、计算截止日志4行，明确退化；扫向7.458°/.179m/s/28.429m/.25s。两项扫掠重叠和外部保护均0，全部成果保留。
- 影响与边界：未放宽安全认证/物理，当前人工策略恢复至已有三轮正式证据的v17；固定目标v18目前仅3/3探索安全到达，尚不能宣称五轮正式通过。
- 回滚/备份：v19_candidate、v20_candidate保留源码与二进制；v17_frozen为上次完整冻结失败组，v18_candidate为已测候选。无提交推送。
- 后续事项：主入口恢复构建与核心回归，冻结124份运行源码/二进制；先固定目标各5轮，再据结果推进最终人工组，所有结果如实保留。


### 2026-10-07 — [EGO1P3] 撤回v19俯仰权重，v20检查方向评分连续性

- 状态：v19探索失败并撤回；v20待构建与探索。
- 目的：减少球面亚像素候选跨网格半格边界时的人工评分跳变，而非继续抬高升降代价。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：src/pc_gvf/src/omni_depth.cpp、WORK_LOG.md、HISTORY/CHANGELOG.md；performance/omni_20261006/v19_candidate及候选分析。
- 修改内容：相对俯仰附加权重2恢复1；方向评分的角域净空由最近格查询改为周期方位/俯仰双线性插值，精确输入、保留方向和细化方向的成本连续。碰撞锥几何、已知观测掩码与完整认证仍用原逻辑，插值不参与安全证明。固定目标保持v18策略。
- 验证：v19主build/21/21通过，但旋转均角14.293°、RMS .709m/s、投影84.157m、停车.933s、jerk6.521、截止状态日志9行，明确退化；扫向7.731°/.187m/s/28.368m/.25s，两项扫掠重叠和保护0。不能用扫向通过保留旋转退化版本。
- 影响与边界：v20是针对代码中离散评分不连续的独立假设，实际性能仍待实跑；未改场景、物理参数、安全证明或历史格式。
- 回滚/备份：v19_candidate保存当时球面源码、二进制/SHA及全部输出；恢复angular_room原最近格查询即回到v18。
- 后续事项：构建、21项核心回归、旋转与扫向探索，然后确定下一冻结版本；无提交推送。


### 2026-10-07 — [EGO1P3] v18目标三轮通过，v19检查多余俯仰代价

- 状态：v18探索三轮安全到达；v19已写入待构建/探索，未宣称正式优胜。
- 目的：修复目标策略连续性后，针对v17旋转25–29秒的额外升降/减速检查候选代价。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：src/pc_gvf/src/omni_depth.cpp、WORK_LOG.md、HISTORY/CHANGELOG.md；performance/omni_20261006下v18差异/三轮分析与v17旋转分段诊断。
- 修改内容：球面成本的相对俯仰tan²附加权重1→2；总角偏差/连续性/净空奖励和安全层不变。惩罚相对操作者3D意图的多余俯仰，不禁止显式升降；固定目标保持v18全视角局部池连续优先。此为待验证假设，不将相关性写成已证明原因。
- 验证：v18主build成功、21/21；三轮目标69.800/72.450/71.467s，3/3独立扫掠重叠/外部保护0，停车均.25s，均耗时71.239±1.340s，未取得新的成对正式结论。v17失败轮16/16状态逐值重放一致，完整audit保留。v17旋转分段均值25–29s：P2/P3投影速度1.417/1.313m/s、实测速率1.801/1.581、绝对垂速.169/.270，其余多数时段差异小。
- 影响与边界：仅候选评分，未改输入、模拟器、场景和安全参数；与P2比较必须保留新探索失败及旧正式失败，不以单轮替代重复统计。
- 回滚/备份：v17_frozen、v18_candidate源码/二进制及v18_diff_vs_v17.patch；恢复俯仰权重1即可回到v18。无提交推送。
- 后续事项：主入口构建；先旋转与扫向探索，若退步撤回，随后新的冻结验收。


### 2026-10-07 00:59 — [EGO1P4] 六项优化补充验收：增量场目标与共享控制闭环

- 状态：部分完成；六项代码、机制消融和补充配对完成，实际全面优胜及真机/多机未验收。
- 目的：完成00:32记录的截止停车修复与共享地图控制级验证。
- 项目路径：/home/starry/isaac-data/EGO1P4。
- 涉及文件：src/pc_gvf/include/pc_gvf/paper_guidance.hpp、src/pc_gvf/src/paper_guidance.cpp、src/pc_gvf/src/paper_replay.cpp、src/pc_gvf/tools/paper_replay.cpp、src/pc_gvf/test/cpp/incremental_field_check.cpp、src/pc_gvf/test/cpp/intent_response_check.cpp、tools/ros_shared_control_probe.py、SIX_AXIS_OPTIMIZATION.md、README.md、EGO1P4_VERSION.md、WORK_LOG.md、performance/six_axis_20261006/deadline_followup/及补充navigation_benchmark轨迹；HISTORY/README.md、FOV_GVF_FAMILY.md、CHANGELOG.md。
- 修改内容：③的短时场目标只作候选，保留构场机器人位置及原始意图锚点，当前证据完整运动重新认证；V21保存位姿；共享控制测试加入局部盲障碍/无障碍/清除后恢复三阶段，显式0.48机体/0.58认证/1.2加速度，保存606条诊断及三个节点日志。
- 验证：主入口构建3包成功、核心29/29、旧回放21/21、16组合回放通过；平台15/15为此前同任务结果，补充阶段未改平台。最终真实卡停快照交错213.382→3.274ms。默认③⑤2/2到达、均值69.283s；①③⑤2/2到达、均值82.550s；新增四轨迹扫掠重叠0、外部保护0；按默认→不确定性→不确定性→默认交错，用同一冻结二进制，完整未提前停止。ROS共享组在同伴独有障碍期0命令，对照约.5；清除后共享恢复约.493m/s。图表已目视检查，Python AST及git diff --check通过。
- 失败与边界：pending缓存候选无截止收益已撤回；合成字段位姿原点exit4已修复；ROS夹具首轮未配置支持证据TTL，两版全停，保留失败；第二轮加速度参数名未实际覆盖，最终改command_accel_limit并重验。共享资源等待1156秒，没有终止外部流程。初始view_image工具受既有bubblewrap错误阻塞，获准读取本地图像后完成目视核验。先前240s超时等全部保留，不跨算法版本混合统计。依然仅③⑤默认；动态Isaac、多机飞行、真实相机标定、真人体验未运行。
- 回滚/备份：关闭六开关；父目录final_sources.tar.gz保留00:16阶段，最新源码及SHA在deadline_followup/final_sources.tar.gz。未提交推送，旧项目未修改。
- 后续事项：更大样本与多地图、动态/多机Isaac、真实传感器标定和真人操控；不能把当前局部收益写成这些项目已验收。


### 2026-10-07 — [EGO1P3] v17完整24轮未通过，v18保持固定目标候选连续性

- 状态：v17严格验收失败；v18修正已写入，待构建与动态比较。
- 目的：用户要求比EGO1P2更优；不能把人工扫向显著改善替代固定目标失败。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：depth_angular_controller_node.cpp、README.md、OMNI_ACCEPTANCE.md、EGO1P3_VERSION.md、WORK_LOG.md；performance/omni_20261006下的报告/一致性脚本与全部final_v17证据；HISTORY/CHANGELOG.md。
- 修改内容：固定目标每周期优先四视角world局部候选池，保持各视图掩码更新/选择连续性；候选池无解才使用球面恢复。人工模式保留v17球面优先策略。真实证据、完整运动/制动证明、机体与限速不变。
- v17验证：主build/核心21/21，冻结源码124份/二进制一致性、EGO1P2完整2922文件未改、九个安全/平台/场景文件未改均通过；真实ROS --omni缺前相机/未知拒绝/过期/松手通过。24轮运行均退出0、全部扫掠重叠/外部保护0、速度/实际加速度契约通过，但固定目标只有4/5安全到达，不能写成全部任务成功。
- v17人工比较：扫向P2→P3均角误差31.705→7.580°，RMS .567→.182m/s，进展20.684→28.407m，停车1.011→.250s；旋转均角10.729→9.992°，进展92.309→91.869m退步，jerk3.029→3.833退步，两版停车.5s。恢复单轮停车2.15→1.25s、安全审计0。
- v17目标比较：P2 5/5、70.953±.934s；P3 4/5，成功均值71.092±1.939s、含失败104.873s、平均停车35.68s。第三轮在(50.087,12.233,1.857)机体包络未知而停到240s；回放audit证实.58包络拒绝，表面稀疏采样全覆盖不能替代完整证明。并未证明候选切换是唯一原因；v18是针对可见策略差异的修正，须重测。
- 其他记录：新增完整判据/逐轮表格/源文件核验脚本；图表第一次以未隔离Python运行因用户NumPy2与系统matplotlib ABI冲突失败，改用项目规定PYTHONNOUSERSITE=1 /usr/bin/python3后生成成功，无依赖安装或降级。报告区分成功轮到达均值与超时惩罚，所有失败保留。
- 回滚/备份：v17_frozen含源码包和二进制；final_v17_results.md/acceptance.json/integrity.json完整保留，未混入探索轮；旧validation_notes.json仅代表v5，不改成当前成绩。无提交推送。
- 后续事项：主入口构建v18，先固定目标探索，失败不得删去；随后决定冻结比较范围。真实手柄、GUI/RViz性能、跨场景和真机未验收。


### 2026-10-07 00:32 — [EGO1P4] 六项优化后续：消除重复构场导致的截止停车（验证中）

- 状态：部分完成；核心回归已通过，新增Isaac交错配对等待独立EGO1P3当前批次结束。
- 目的：修复不确定性v2产生可行场目标却因完整构场超过80ms而反复零输出的问题。
- 项目路径：/home/starry/isaac-data/EGO1P4。
- 涉及文件：src/pc_gvf/include/pc_gvf/paper_guidance.hpp、src/pc_gvf/src/paper_guidance.cpp、src/pc_gvf/src/paper_replay.cpp、src/pc_gvf/tools/paper_replay.cpp、src/pc_gvf/test/cpp/incremental_field_check.cpp、src/pc_gvf/test/cpp/intent_response_check.cpp；performance/six_axis_20261006/deadline_followup/。
- 修改内容：③增量功能在主候选为空时，最多0.5s复用上一场目标；按构场时机器人世界位置补偿自运动，当前深度/位姿和完整运动制动重新认证，旧场不增加自由空间。保留原始意图锚点使累计转向可失效。V21 EGOPAPRL保存构场位置并兼容旧格式，CLI增加--incremental-field用于同快照开关消融。80ms截止、0.48/0.58m半径、1.2m/s²未改变。
- 验证：先尝试构场内pending正证书缓存，12次回放决策一致但仍约278ms（与CTest并发，不能作严谨时间对比），无截止收益已撤回归档；该候选29/29。目标复用的4快照×3轮交错开关消融264.681→4.624ms（含进程启动），全部给出经当前证据认证非零指令。新增合成回归最初exit4，揭示相机光心不能代替构场机器人位置；修正锚点并升级回放后主入口构建3包成功、核心29/29（13.06s）。新增实跑此时尚未运行，不将快照收益代替导航。
- 影响与边界：只在③开启且主候选为空时改变后备链；其他项目和场景未修改，无效/过期当前证据仍拒绝。动态与多机实飞仍未验收。
- 回滚/备份：前一阶段完整源码在performance/six_axis_20261006/final_sources.tar.gz；后续前态源码/回放二进制、失败缓存候选和全部诊断存deadline_followup；关闭③可回到此前无增量后备行为。
- 后续事项：旧21帧复核、默认/不确定性各2次交错Isaac与完整机体审计，保留全部结果。


### 2026-10-07 — [EGO1P3] v16扫向失败，v17区分连续意图与固定目标优先级

- 状态：v16正式验收失败；v17已冻结重测，未提前宣称通过。
- 目的：修复原局部候选覆盖连续球面目标而引入的缓慢改向长停顿。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：depth_angular_controller_node.cpp、版本/验收/工作日志；performance/omni_20261006/v17_frozen、候选与正式轨迹；HISTORY/CHANGELOG。
- 修改内容：人工控制优先连续球面候选，仅球面无认证方向时补充局部候选；固定目标沿用v16统一局部候选池优先策略。两种模式始终融合四路当前证据和历史，并使用原完整运动/制动证明。
- 验证：v16扫向三对全部完成，P3停车4.333/4.150/4.433s，最长1.500/2.633/2.900s，明显失败；安全审计仍0。本任务父批次在完整扫向结束后终止，退出143；spin/recovery/固定目标正式组均未开始，不能算通过。v17主build和核心21/21通过；探索sweep角误差7.441°、RMS .179m/s、进展28.432m、停车.25s、jerk2.293，扫掠重叠和保护均0。
- 正式验证：v17_frozen保存124份源码、源码包与二进制/SHA；final_v17扫向/旋转各3对、恢复1对，omni_final_v17目标各5轮正在运行，全部交错。
- 影响与边界：模式区分使用原已有fixed_goal语义，不根据测试标签选择算法；手柄轴映射、物理和场景不改。全部失败完整保留，不拼接最佳单轮。
- 回滚/备份：v16_frozen、v17_frozen、停止批次PID记录与全部原始数据。无提交推送。
- 后续事项：完整冻结比较、最终真实ROS入口复查、归档和最终说明。


### 2026-10-07 00:16 — [EGO1P4] 六方向实现、逐项消融、退化修复与默认范围收束

- 状态：部分完成整体目标；六项实现及机制验证完成，实际导航全面优胜未通过。当前无仍在运行的本任务仿真。
- 目的：按用户六方向逐步研发，分别验证不确定性、动态响应、增量调和、球面记忆、操作体验和共享地图。
- 项目路径：`/home/starry/isaac-data/EGO1P4`。
- 涉及文件：本轮30项源码/配置/测试/脚本变化（相对路径）为`src/pc_gvf/CMakeLists.txt`、`src/pc_gvf/include/pc_gvf/depth_uncertainty.hpp`、`src/pc_gvf/include/pc_gvf/dynamic_obstacles.hpp`、`src/pc_gvf/include/pc_gvf/operator_intent.hpp`、`src/pc_gvf/include/pc_gvf/paper_guidance.hpp`、`src/pc_gvf/include/pc_gvf/shared_obstacles.hpp`、`src/pc_gvf/include/pc_gvf/spherical_memory.hpp`、`src/pc_gvf/launch/isaac_cloud_navigation.launch.py`、`src/pc_gvf/src/depth_angular_controller_node.cpp`、`src/pc_gvf/src/depth_uncertainty.cpp`、`src/pc_gvf/src/dynamic_obstacles.cpp`、`src/pc_gvf/src/paper_guidance.cpp`、`src/pc_gvf/src/paper_replay.cpp`、`src/pc_gvf/src/shared_obstacles.cpp`、`src/pc_gvf/src/spherical_memory.cpp`、`src/pc_gvf/test/cpp/depth_uncertainty_check.cpp`、`src/pc_gvf/test/cpp/dynamic_closed_loop_check.cpp`、`src/pc_gvf/test/cpp/dynamic_obstacles_check.cpp`、`src/pc_gvf/test/cpp/incremental_field_check.cpp`、`src/pc_gvf/test/cpp/intent_response_check.cpp`、`src/pc_gvf/test/cpp/operator_intent_check.cpp`、`src/pc_gvf/test/cpp/shared_obstacles_check.cpp`、`src/pc_gvf/test/cpp/six_axis_replay_check.cpp`、`src/pc_gvf/test/cpp/spherical_ingest_check.cpp`、`src/pc_gvf/test/cpp/spherical_memory_check.cpp`、`src/pc_gvf_msgs/CMakeLists.txt`、`src/pc_gvf_msgs/msg/SharedObstacles.msg`、`scripts/run_isaac_fov_gvf_navigation.sh`、`tools/ros_shared_obstacles_probe.py`、`tools/run_six_axis_ablation.py`；另更新`SIX_AXIS_OPTIMIZATION.md`、`README.md`、`EGO1P4_VERSION.md`、`WORK_LOG.md`、独立`six_axis_*`实验及`HISTORY/README.md`、`FOV_GVF_FAMILY.md`、`CHANGELOG.md`。`source_changes.json`以任务初始工作区为基准，不以旧Git HEAD计数；消息PositionCommand/package.xml未改。
- 修改内容：距离平方误差深度下界与边缘保守扩展；原包络已含径向深度误差按像素四角最小cos抵扣，避免重复计入。世界坐标障碍轨迹、0.5s时效与全制动相对运动检查；动态模式禁用静态永久证据。位姿重投影+残差修正调和求解，当前掩膜重新验证，残差失败冷启动。24×12方向、48幅上限、4sTTL的球面证据及0.05m/s老化，来源标记保护原静态历史；原生点冲突预筛选与原精确检查等价。0.018rad操作角滞回保留松杆/大转向响应。共同坐标系下按机器人/会话/序列/时间维护共享占据，异frame/过期/重复/无效消息拒绝，远端不授权未知自由空间。V19/V20保存新状态和证据来源；主脚本新增可选等待单实例锁，不删除锁或中止EGO1P3。
- 默认：`FOV_GVF_INCREMENTAL_FIELD=1`、`FOV_GVF_OPERATOR_ASSISTANCE=1`；不确定性、动态、球面、共享开关默认0。机体0.48m/认证0.58m、2m/s及实际1.2m/s²不降低。
- 验证：主build入口最终3包成功；`ctest`29/29（12.75s），ROS环境平台pytest15/15；45 Python AST、3 Shell语法和diff格式通过。`run_six_axis_ablation.py`全部9个可执行检查通过；噪声错误包络8→0/1000，真实0.48m五组解析动态闭环碰撞5→0（进度3.422→2.000m，空场5→5m），调和迭代17450→7119/误差1.70e-9，球面74方向0→74认证/过期拒绝，球面80帧×76800点约2.8–2.9倍且证据一致，角微扰指令总变差.241851→.000104623，32同伴障碍危险放行32→0。双ROS实际消息与全六项开启负对照通过；不是双机飞行。最终旧快照21/21、16组合重放一致。
- 实际运行：本轮10次固定目标Isaac有效运行+4次72秒手柄等效运行，另2次因其他任务持锁未启动。固定路线baseline2/2均值69.2917s；不确定性初稿1/2（71.05及240超时），抵扣余量v2仍1/2（73.2833及240超时）；球面初稿0/2均超时，来源修复v2 2/2均值69.925s、jerk2.1159对baseline1.9851，未全面领先。手柄baseline停车1.25s/最长.25s/路程90.177m；球面v2为9.533/3.60/75.861，预筛选v3恢复1.25/.25/88.404但仍有581ms指导峰值。最终默认1.25/.25/90.133、最小保守扫掠净距.1885m；四组扫掠重叠与外部保护均0。全部轨迹、原始失败、独立审计、有效参数与总结保存，不挑最快一轮作结论。
- 失败与修复：基线CTest18/20为用户NumPy2/系统SciPy不兼容，隔离用户包后20/20；平台先缺项目路径再缺ROS环境，补正确环境后15/15；操作模块首次缺Eigen/Geometry链接失败后修复；一次文件写入自动审批超时重试成功。球面初稿老化误作用原静态历史造成卡停，来源化修复及回归保留；原生点冲突维护过慢再加等价预筛选。部分早期辅助测试继承通用大余量，最终显式校准0.48/0.58及1.2模型并29/29重验，早期结果保留。不得把模块通过当作导航全优。
- 影响与边界：只有EGO1P4和规定的统一记录修改，旧版本未写；未做动态Isaac、多机Isaac、真机、真实传感器标定或真人体验。共享的是占据证据，不是自由空间证书、地图对齐或分布式SLAM；新功能也不能让从未观测的盲区变成已知。
- 回滚/备份：`performance/six_axis_20261006/baseline/sources.tar.gz`、原controller/replay、单独消息CMake原文、初稿球面源包和二进制、最终源包及SHA；全部六开关置0可回到行为基线。旧21帧兼容证明不代表新功能全域安全。不要用旧Git HEAD覆盖继承未提交内容。无提交推送。
- 后续事项：不确定性实跑长停和球面模式计算峰值仍需继续解决；全面导航优胜、真实动态、多机飞行及真人操控未验收。本轮保留可验证的局部收益，不把未达标项写成完成。

### 2026-10-07 00:00 — [EGO1P3] 冻结v16全向候选池，正式对照开始

- 状态：实现与核心回归完成，正式验收运行中，未声明全面胜出。
- 目的：保留原成熟局部选路效率，并实现不依赖四向相机切换的360°规划。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：全向模块、控制节点、回归、ROS探针、版本/验收/WORK_LOG；performance/omni_20261006/v16_frozen及逐轮数据；HISTORY/CHANGELOG。
- 修改内容：v14透视tan偏差成本与已认证保留方向快速返回；v15/v16引入各有效视锥独立局部提案，在world统一比较并使用同一完整证据认证。视锥四角判定、.3s过期像素缓存清除，局部重设阈值.5°；固定目标保留原保持语义。速度/包络/实际制动模型、安全核心和场景未改。
- 验证：v16主build成功、核心21/21；v13真实ROS --omni入口/缺前相机/未知与过期拒绝通过，日志归档；当前局部候选池后的探针待收束复查。v14目标73.200s对同环境P2 69.300s失败；v16探索目标69.183s安全到达、停车.25s/jerk1.676，旋转误差10.011°/RMS .530/进展92.018m/停车.5s/jerk2.737，全扫掠重叠和保护均0。不能用探索单轮宣称正式胜出。
- 正式验证：冻结124份源码、源码包及二进制/SHA；final_v16扫向/旋转各3对、恢复1对，omni_final_v16固定目标各5轮；全部原始轮次保留并共享锁串行，运行中。
- 影响与边界：周期方向图和多视角候选合并不是无盲区球面传感器；大角度跳变仍受实际加速度/制动约束。EGO1P2保留，源码SHA不改，无提交推送。
- 回滚/备份：v14_sources、v15_sources、v16_frozen与全部历史失败组。
- 后续事项：完成正式对照、严格判据检查、最终记录与交付。


### 2026-10-06 — [EGO1P3] v11/v12探索与v13方向保留

- 状态：局部机制完成，最终优胜验收仍进行中。
- 目的：减少绕障方向帧间跳动和多余运动，保持全向输入连续。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：omni_depth.hpp/.cpp、控制节点、omni_depth_check.cpp、tools/ros_vector_guidance_probe.py、版本/验收/WORK_LOG；performance；HISTORY/CHANGELOG。
- 修改内容：v11沿用候选2.5、连续性.4；v12尝试去额外像素膨胀后固定目标变差，已撤回。v13补齐原.35秒方向保留窗口，仍每次重认证，输入累计变化>.05rad取消保留；直达自由时精确跟随不受窗口限制。
- 验证：v11旋转停车.5s/进展92.062m，v12旋转.5s/91.851m；二者安全审计均0。v12固定目标73.683s安全到达，停车1.233s/jerk3.477，未胜出。v13主build与核心21/21通过；新增保留/失效测试；ROS探针和动态测试排队中，不先写为通过。
- 影响与边界：原安全核心/执行物理/地图9项SHA仍一致；EGO1P2不改，全部失败保留。共享锁防止与其他任务仿真并发。
- 回滚/备份：v11_sources、v12_sources；无提交推送。
- 后续事项：完成当前验证后冻结重复比较。


### 2026-10-06 — [EGO1P3] 保留v9/v10失败并继续参数对齐

- 状态：性能验收尚未通过。
- 目的：减少统一球面候选的多余绕行；按完整重复结果筛选。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：全向候选/控制节点/主launch，OMNI_ACCEPTANCE/WORK_LOG；performance/omni_20261006与固定目标实验；HISTORY/CHANGELOG。
- 修改内容：v10启用可选直达通道但退化，已撤回false；v11候选制动前视1.2→原P2的2.5、连续性.12→原参数.4、俯仰附加权重4→1。最终运动认证仍1.2、.58包络；无安全核心或物理修改。
- 验证：v9完整3对旋转均安全且停车.5s，但P3角误差11.551对10.607°、进展89.420对92.385m，失败。v10旋转停车.917s/进展84.196m，固定目标75.233s安全到达，亦未胜出；v11主build成功、核心21/21，探索运行中。v9冻结源码124文件校验无漂移；EGO1P2全部2922文件无变化。
- 影响与边界：真实四相机/原场景/同输入，所有失败保留；图像查看工具因既有bubblewrap故障失败，改从已生成的本地图像base64查看，未改图像内容。
- 回滚/备份：v9_frozen、v10_sources及逐轮SHA；未提交推送。
- 后续事项：稳定候选后重新冻结全套比较。


### 2026-10-06 — [EGO1P3] v9直达分支配置更正

- 状态：仅配置核对；纠正上条默认行为描述。
- 目的：避免将保留的可选分支当成实际启用算法。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：OMNI_ACCEPTANCE、WORK_LOG、HISTORY/CHANGELOG。
- 修改内容：核对两版主launch均设置paper_intent_corridor=false；v9补齐分支但默认未启用，实际启用差异仅俯仰权重1→4。
- 验证：rg逐项核对源码及launch。v9源码/二进制未改，冻结对照继续。
- 影响与边界：不能把v9实跑收益归因于默认未启用的直达分支；旧记录保留并明确纠正。
- 回滚/备份：不涉及算法修改；v9_frozen保留。
- 后续事项：完成重复比较。


### 2026-10-06 — [EGO1P3] v9冻结与交错验收开始

- 状态：验收中。
- 目的：修复全向分支遗漏的原认证直达回归，减少无必要升降。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：omni_depth.cpp、depth_angular_controller_node.cpp、OMNI_ACCEPTANCE及本日志；performance/omni_20261006/v9_frozen。
- 修改内容：恢复原paper_intent_corridor完整通道认证后的精确输入方向优先；俯仰偏差附加权重1→4；完整运动安全核心未改。
- 验证：主build成功，核心21/21；v8三轮全部安全但一次停车1.167s，未胜出，原始结果保留。v9三对旋转测试刚开始，不提前宣称通过。
- 影响与边界：仅候选前端，源目录/地图/物理不变；共享锁串行测试。
- 回滚/备份：v8_sources、v9_frozen源码包/二进制/SHA；无提交推送。
- 后续事项：完成冻结性能与固定目标回归。


### 2026-10-06 — [EGO1P3] 360°融合候选实现、失败对照与恢复修正（验收中）

- 状态：算法实现与核心回归完成，重复性能验收仍在进行。
- 目的：消除四相机选一路的候选瓶颈，按用户要求验证比EGO1P2更优。
- 项目路径：`/home/starry/isaac-data/EGO1P3`。
- 涉及文件：`src/pc_gvf/{include/pc_gvf/omni_depth.hpp,src/omni_depth.cpp,src/depth_angular_controller_node.cpp,CMakeLists.txt,test/cpp/omni_depth_check.cpp,launch/isaac_cloud_navigation.launch.py}`；两主Shell、tools中的对照/分析脚本、测试轨迹；README/版本/OMNI_ACCEPTANCE/WORK_LOG；performance/omni_20261006；HISTORY索引与CHANGELOG。
- 修改内容：四相机采集位姿统一到world的180×37周期球面方向图；精确输入与世界方向连续保留；深度光轴反投影、机体及像素膨胀；真实原始深度认证候选，保留原矢量整形/完整运动与制动证明。v8新增近邻精查和可认证短走廊恢复。候选前视使用1.2制动，相比P2候选2.5更保守；实际运动认证两者均1.2，.48机体/.58包络/速度不变。批量运行可选等待现有共享Isaac锁。
- 验证：经主build构建；v8核心21/21，前期平台15/15、历史重放5帧一致；回归包含721方向、解析射线独立oracle、±180和相机接缝、缺失/过期/未来/撤销/未知、真实通道与运动证明。新增4°窄通道在v7先失败，v8修复后通过，失败日志保留。
- 性能失败：v2/v3旋转工况停车20.9/5.8秒；v6退化已撤回。v5冻结sweep三对平均角误差30.385→8.064°、停车.811→.250s、投影进展21.201→28.293m，均安全；但spin第三轮P3停车3.017s/最长2.517s，故正式稳定性验收失败。v7三轮spin平均进展85.504m/停车1.083s，亦未胜出；v8三轮待完成。每轮数据与二进制SHA保留。
- 批次取消更正：本任务v5父批次在recovery后显式STOP/TERM/CONT终止，退出143。固定目标P2首轮子进程实际已启动并独立到达72.1167s，缺少父进程收尾元数据，孤立轮保留；其余九轮未执行。不得误写成全组未开始或五轮通过。
- 影响与边界：360°是水平方位统一规划，四相机上下及近场仍有真实盲区。未改EGO1P2、安全核心、场景、手柄轴映射或执行物理；旧收益标签保留。原source_manifest再次逐文件验证P2无变化。
- 回滚/备份：EGO1P2原目录、source_manifest；v2至v7源码备份和v5冻结二进制保留。未提交/推送。
- 后续事项：完成稳定候选、冻结同条件重复对照、固定目标回归和最终记录；当前不能宣称整体优胜。


### 2026-10-06 — [EGO1P4] 六方向优化启动（实验进行中）

- 状态：进行中，尚无六项全面优胜结论。
- 目的：逐项实现深度不确定性、动态障碍、增量调和场、球面记忆、操作体验和多机共享证据，并做开关对照。
- 项目路径：`/home/starry/isaac-data/EGO1P4`。
- 涉及文件：`src/pc_gvf/`、`tools/`、`performance/six_axis_20261006/`，后续完成条目列明。
- 修改内容：新增保守深度下界与遮挡边缘收缩，初始默认关闭；其余逐步进行。
- 验证：基线CTest第一次18/20，用户NumPy2与系统SciPy不兼容；加PYTHONNOUSERSITE=1后20/20。两轮修改前Cloud导航运行中。
- 影响与边界：安全包络和物理加减速不变；合成机制实验不能代替真机或多机实测。
- 回滚/备份：`performance/six_axis_20261006/baseline/sources.tar.gz`、SHA256和原控制/重放可执行文件；保留既有未提交修改。
- 后续事项：逐项实现、消融、组合回归及如实记录失败。

### 2026-10-06 22:37 — [EGO1P4] 完整复制 EGO1P2 并整理当前算法状态

- 状态：完成复制、运行路径适配、独立构建与回归；未运行新的Isaac导航或真实手柄动态验收。
- 目的：按用户明确命名EGO1P4，保留本会话当前EGO1P2，并在新副本说明代码、算法进展和状态。
- 项目路径：新目录`/home/starry/isaac-data/EGO1P4`；来源`/home/starry/isaac-data/EGO1P2`保持不变。
- 涉及文件：完整新目录及其全部继承文件；有意适配`AGENTS.md`、`README.md`、`WORK_LOG.md`、`scripts/build_isaac_ros_workspace.sh`、`scripts/run_isaac_fov_gvf_navigation.sh`、`src/pc_gvf/launch/navigation_benchmark.launch.py`、`tools/run_navigation_benchmark.py`、`tools/analyze_navigation_benchmark.py`、`tools/verify_navigation_replays.py`、`tools/ros_vector_guidance_probe.py`；新增`EGO1P4_VERSION.md`、`performance/branch_copy_20261006/`复制清单、构建/测试/审计证据和校验脚本；同步`HISTORY/README.md`、`PROJECT_INDEX.md`、`FOV_GVF_FAMILY.md`、`CHANGELOG.md`。
- 修改内容：`cp -a --reflink=auto`全量复制2,922文件、335子目录、831,872,016字节文件内容，含隐藏文件、Git、未提交改动、场景及全部实验失败；初始SHA/类型/权限/属主一致、无源目标共享硬链接。仅新副本改为`/tmp/fov_gvf_ego1p4_isaac_{build,install,log}`、独立ROS日志/重放路径，增加ego1p4实验标识而保留ego1p2/ego1p1/ego1p0/user_ego。共用ROS域42和单实例锁，防止重复控制。核心算法源码、默认launch参数、场景和继承成绩不改。
- 状态说明：新EGO1P4_VERSION明确当前是深度候选→单三维矢量整形→完整运动/制动认证的工程混合实现；继承精确净空线性化与静态历史局部冲突修复。当前.48m实际/.58m认证、2m/s速度、1.2m/s²物理加减速度保持。EGO1P2局部计算54.1倍不等于导航提速；手柄等效轨迹最长低速停车.25s也不证明原现场已全部解决。原人工轨迹、任意位置持续可控、全面领先、主动观察/回退、逐周期实时及实物仍未完整验收。独立EGO1P3未复制或合并，进展不归入本副本。
- 验证：在新目录经主build脚本3包成功，28.0s；新构建CTest20/20（10.83s）、平台pytest15/15；43个Python AST、3个Shell语法、git diff --check通过。3个ROS包前缀全部指向ego1p4安装目录；生成benchmark launch描述确认新二进制与默认历史修复开启，未启动ROS控制或Isaac。新重放程序读取原用户5帧及历史82–85轮16帧，共21/21决定一致，只验证保存状态，不算新导航成绩。构建测试和全过程校验在performance/branch_copy_20261006。
- 校验问题与处理：普通沙箱仍报mountinfo路径错误，命令经批准升级执行。初次保留复核发现副本.git/index字节改变，严格校验退出1；证据preservation_pre_record.json保留。进一步比较`git ls-files --stage -z`，所有暂存路径/blob/模式一致，源索引及整个源目录均未改；将副本索引差异作为元数据单独记录，不重置工作区、不恢复覆盖代码，见index_metadata_check.json。构建和功能测试无失败。
- 影响与边界：EGO1P4可独立构建并指向自己的安装/日志，算法行为未有意修改；EGO1P2/EGO1P1/EGO1P0/user_ego及独立EGO1P3本次未修改。ROS/Isaac等目录外依赖共享，旧/tmp产物不复制而新建构建。继承日志/历史脚本旧绝对路径保留出处，新运行使用EGO1P4_VERSION；不能把继承EGO1P2或EGO1P1飞行数据改名为EGO1P4新成绩。无新仿真、真实手柄动态或真机操作。
- 回滚/备份：EGO1P2完整保留；source_manifest.json与copy_verification.json证明来源和初始副本，后续适配有独立范围校验。需要来源时进入EGO1P2使用其原入口；不要用旧Git HEAD替代未提交工作区。复制的Git分支仍ego1p1、HEAD 50f7c5500af86e31d0d9af03de8ec9a29ffb10e1，未新建分支、提交或推送。
- 后续事项：本次目录任务完成；后续在EGO1P4开发时按新状态文档及AGENTS执行，新实验用独立标签，原手柄复现与剩余算法目标需另行实测。

### 2026-10-06 — [EGO1P3] 建立副本并启动连续360°感知与控制优化（进行中）

- 状态：复制完成，算法与对照验收进行中。
- 目的：用户确认将EGO1P2完整复制为EGO1P3，消除按最近四相机选一路生成候选的方向限制，完成后与EGO1P2同条件验收。
- 项目路径：`/home/starry/isaac-data/EGO1P3`；来源EGO1P2保留。
- 涉及文件：完整新增EGO1P3；两个主Shell、benchmark launch、四份tools、AGENTS/README/WORK_LOG/版本说明；HISTORY索引和状态。
- 修改内容：2922文件、3257条目完整复制，含隐藏文件和Git；建立ego1p3独立/tmp构建、安装、日志与重放路径。旧版本历史报告保留。
- 验证：复制前后SHA256/模式/符号链接逐项一致，无共享文件inode；证据在performance/omni_20261006/source_manifest.json及copy_verification.json。新构建、测试、仿真尚未运行。
- 影响与边界：当前仅目录建立；尚未证明360°优化优于EGO1P2。原.48m机体/.58m认证与完整运动制动证明继续保留。
- 回滚/备份：EGO1P2完整来源及逐文件清单；未提交推送。
- 后续事项：实现统一世界方向候选、跨接缝回归、原场景交错重复对照并记录全部失败。

### 2026-10-06 21:37 — [EGO1P2] 静态历史局部冲突修复与防卡停回归

- 状态：完成一处可复现卡停机制的修复、默认启用和回归；原人工轨迹未完整复现，任意状态不卡停未验收。
- 目的：响应用户“修复”“尽可能避免卡住”，避免远处小范围深度冲突抹掉整幅历史观测，丢失近场起步通道。
- 项目路径：`/home/starry/isaac-data/EGO1P2`。
- 涉及文件：`src/pc_gvf/src/paper_guidance.cpp`、`include/pc_gvf/paper_guidance.hpp`（位于src/pc_gvf下）、`src/pc_gvf/src/paper_replay.cpp`、`src/pc_gvf/src/depth_angular_controller_node.cpp`、`src/pc_gvf/launch/isaac_cloud_navigation.launch.py`、`src/pc_gvf/CMakeLists.txt`、`src/pc_gvf/test/cpp/history_repair_check.cpp`、`src/pc_gvf/test/cpp/intent_response_check.cpp`、`src/pc_gvf/test/fixtures/paper/isaac_stall_repair_trace.json`、`scripts/isaac/run_fov_gvf_navigation.py`；`README.md`、`EGO1P2_VERSION.md`、`WORK_LOG.md`、`performance/stall_fix_20261006/`；`HISTORY/README.md`、`HISTORY/FOV_GVF_FAMILY.md`、`HISTORY/CHANGELOG.md`。
- 定位：原frame_1历史仅9/16幅，关键前向旧观测缺失；原frame_4前进0.1m的机体上下边界存在无证据采样点。代码遇任一原始深度冲突会撤销整幅旧图，合成同条件回归证明会导致旁侧自由起步通道丢失。原快照不含被撤销图和完整原始输入，因此不能声称已还原每次历史撤销事件或人工操作轨迹；采样仅定位，不参与安全认证。
- 修改内容：新增`paper_local_history_repair`，纯核心默认false，主launch以`FOV_GVF_LOCAL_HISTORY_REPAIR=1`默认启用；且必须满足静态历史（retain_verified_travel且history_uncertainty_rate=0）。对每个冲突原始命中投影完整不确定性球，含保守边界像素，只缩短对应深度；撤销借用旧图并发布不可变缩小副本，其余历史自由列保留。动态历史/开关关闭仍整图撤销；球、管、待执行证明原有撤销保留。最后强化为所有命中均相对原图判断，避免前一个命中仅裁掉后一命中中心却漏掉其不确定性邻域。
- 配套：重放格式V17→V18（EGOPAPRI）保存新开关，旧格式继续读取且关闭新开关；离线audit增加未覆盖表面样本。trace测试可选独立yaw_rate，旧trace保持原自动朝向，真实手柄读取/轴映射不改；新72秒轨迹是近似场景测试，不是原摇杆录制。
- 验证：均经主build脚本构建。最终`PYTHONNOUSERSITE=1 ctest --test-dir /tmp/fov_gvf_ego1p2_isaac_build/pc_gvf --output-on-failure`20/20，`/usr/bin/python3 -m pytest -q src/pc_gvf_platforms/test`15/15。新增回归覆盖旧模式同场景无法起步、修复后松手再输入输出非零完整认证命令、障碍与不确定性邻域拒绝、所有像素只减不增、旧引用撤销、采样间新冲突和动态整图撤销。最终原用户5帧+历史82–85轮16帧，21/21逐值重放一致；这证明旧状态兼容，不能补回已丢失历史。修改Python AST和git diff --check通过。
- 实跑：串行通过主运行脚本。初稿72秒手柄等效开关对照停车均1.250s/最长0.250s，路程88.896/89.046m；初稿仍有COMPUTE_DEADLINE峰值571.186/455.934ms。最终代码94秒恢复开关对照停车1.183/1.200s、最长均0.250s、路程73.320/73.271m；最终72秒独立航向再测停车1.250s、最长0.250s、路程90.151m。三组最终运行全部5段平移输入有位移，完整.48m机体扫掠重叠及外部保护均0，最小保守间隙分别.196/.177/.143m；最终独立航向避障max7.272ms，但控制周期间隔max93.334ms，不声称逐周期实时。五组均按手动模式时间上限正常结束MANUAL_TIMEOUT、退出0，不是固定目标到达验收。
- 失败与限制：格式升级后的第一次CTest19/20，因intent_response_check仍硬编码V17；更新测试预期后20/20，失败日志ctest_ab.log保留。两条旧模式轨迹本来就无>1s长卡停，不能据其宣称真实卡停频率下降；人工原轨迹/真实手柄动态/实物/跨地图未验收，原五帧仍输出其原决定；新仿真没有可保存失败快照，不写成新实跑V18快照通过。沙箱mountinfo启动失败，所有后续命令经升级审批执行。
- 影响与边界：只修复静态历史冲突处理与测试诊断；机体.48m、认证.58m、速度/动力学、完整运动制动证明和未知拒绝不变；不新增在线全地图许可、不执行未经认证脱困。旧EGO1P1/EGO1P0/user_ego与场景未修改。新逻辑不能恢复旧进程已经删除的历史，应重启仿真以重新积累观测。
- 回滚/备份：`performance/stall_fix_20261006/before_sources.tar.gz`、before_sha256.json及旧paper_replay；精确差异implementation.patch、最终changed_sources_sha256.json、测试/CSV/审计/所有失败与completion_summary.json已保存。临时对照或关闭修复用`FOV_GVF_LOCAL_HISTORY_REPAIR=0`加原运行命令；彻底回退仅恢复本轮相应文件后主入口构建，不用旧Git HEAD覆盖继承未提交改动。无提交推送。
- 后续事项：原人工场景需用户实际操作复验；继续出现停滞时利用新快照定位剩余证据缺口。真实未知边界仍应停车，本次不承诺所有环境永不卡住。

### 2026-10-06 21:01 — [EGO1P2] 实际手柄空地停滞诊断

- 状态：仅检查并归档，原因定位到自由空间认证边界；未修复算法。
- 目的：解释用户20:57截图中空地无法前进的问题。
- 项目路径：`/home/starry/isaac-data/EGO1P2`。
- 涉及文件：新增`performance/stall_20261006_205620/`（5组原始快照、日志、审计、重放结果与SHA）；`EGO1P2_VERSION.md`、`WORK_LOG.md`、`HISTORY/CHANGELOG.md`、`HISTORY/FOV_GVF_FAMILY.md`。
- 检查结果：用户运行20261006_205620已退出，不能实时读取；日志反复NO_REGULAR_FIELD/NO_CERTIFIED_DIRECTION，夹杂CERTIFIED_TRACKING和COMPUTE_DEADLINE。frame_4的40.333s位置约(-43.6852,-10.0982,2.33919)，实际速度0，手柄意图(1.92717,.534791,0)，候选0。当前.58m包络认证通过、增加.005m失败；后备构场需要.01m前缀，近意图方向仅认证.00146484m；frame_3接受约.02m/s小指令，解释微动/停车反复。采样前半球最大.02173m，后方约.3728m；这些是保守认证长度，不是实际障碍距离。
- 验证：现有paper_replay --audit读取frame_3/4；verify_navigation_replays.py共5/5决策一致。按既有occupancy体素AABB约定做独立离线诊断，当前.48m机体表面近似净距1.281m，沿输入方向前进.5m整段保守扫掠净距仍约1.115m；地图仅离线审计，不喂给在线规划器。运行外部保护介入0，计算峰值111.790ms。截图与快照并非严格同步；只诊断同一运行已复现的停滞，未执行新仿真/构建/测试。
- 修改内容：只保存证据、追加状态与日志，未改源码/参数/运行方式。
- 影响与边界：主要是已观测自由空间/历史认证衔接导致可通行空地无法生成可认证前进通道；细分到具体盲区或证据遗漏仍需进一步定位。手柄仍有输入，不能归咎手柄未解锁。motion_scale诊断使用previous_command=0，三个比例均通过不代表前进可行。前一轮净空计算优化未解决此问题。
- 回滚/备份：原/tmp日志和快照完整保留，项目内副本另有SHA；无需代码回滚。无提交推送。
- 后续事项：围绕这5帧定位近场/上下盲区与历史体积衔接，再验证受完整安全认证约束的恢复动作；不得以缩小机体或放行未知空间掩盖停滞。

### 2026-10-06 20:51 — [EGO1P2] 精确净空距离线性化与首轮实测

- 状态：完成本轮计算优化与验证；导航提速及全面领先未通过。
- 目的：阅读代码和历史进展后，降低默认深度候选重复净空查询的计算成本，保持原安全契约。
- 项目路径：`/home/starry/isaac-data/EGO1P2`。
- 涉及文件：`src/pc_gvf/src/depth_angular_core.cpp`、`include/pc_gvf/depth_angular_core.hpp`、`src/pc_gvf/CMakeLists.txt`、`src/pc_gvf/test/cpp/clearance_check.cpp`（include路径完整为src/pc_gvf/include/pc_gvf/depth_angular_core.hpp）；`EGO1P2_VERSION.md`、`README.md`、`WORK_LOG.md`；`performance/clearance_20261006/`；`performance/navigation_benchmark_20260929/edt_before_20261006_*`、`edt_after_20261006_*`及其PERFORMANCE.md追加；`HISTORY/README.md`、`FOV_GVF_FAMILY.md`、`CHANGELOG.md`。
- 修改内容：穷举障碍最近距离改为两遍精确欧氏变换，O(N×B)→O(N)；提供可测试净空接口、全自由/全阻塞快速分支、边界验证；不改候选代价/排序、0.48m机体/0.58m认证、2m/s速度、实际1.2m/s²和所有运动/制动证明。
- 验证：两次主入口构建均成功（初始优化21.6s，测试修正另见build_test_fix.log）；修改前核心18/18；`PYTHONNOUSERSITE=1 ctest --test-dir /tmp/fov_gvf_ego1p2_isaac_build/pc_gvf --output-on-failure` 最终19/19；加载Humble与新local_setup后`/usr/bin/python3 -m pytest -q src/pc_gvf_platforms/test` 15/15；clearance_check穷举65536种4×4掩码、192矩形样例逐值一致，候选排序及超长一维/非法尺寸通过。`clearance_check --benchmark`七轮交替顺序取中位数，64×48/50%障碍754.388→13.933us，54.1倍。历史82–85轮16帧`verify_navigation_replays.py`全部一致；本轮新运行无可验证快照，不声称新快照通过。源码检查确认3个既有源码/构建文件变化、1新测试；其余归档110文件当时未变，后续仅追加文档；git diff --check通过。
- 实跑：`tools/run_navigation_benchmark.py edt_before_20261006 ego1p2 --repeats 2`与`edt_after_20261006`同命令，通过主运行Shell串行；`tools/analyze_navigation_benchmark.py`分别审计。前69.300/69.317、后71.433/69.283仿真秒，前后各2/2安全到达、全部扫掠重叠/保护0；均值69.308→70.358s，墙钟68.827→70.573s，停车0.250→0.242s，jerk1.710→2.243。避障p95 1.500/1.705→0.970/0.994ms，但后组首轮max319.867ms、COMPUTE_DEADLINE/TARGET_HOLD；不隐去退化，不把两轮写成五轮或跨地图验收。
- 失败与限制：初次新增测试误用输入源像素所属连通域，未考虑既有历史偏向重捕获，导致18/19；修正测试为实际选择源连通域后19/19，算法未为测试放宽，失败保留ctest_after.log。沙箱启动因mountinfo路径失败，使用获准升级命令；会话中断令前后组隔时，非交错对照，不能用两轮归因普遍导航性能。真实手柄/实物/跨地图未运行。
- 影响与边界：净空函数和局部计算性能改善；平均导航时间、波动与jerk并未改善。默认保留精确计算优化，不宣称全面优于旧版。EGO1P1/EGO1P0/user_ego、地图、launch、安全认证与共同执行代码未修改；HISTORY规则未改。
- 回滚/备份：`performance/clearance_20261006/before_sources.tar.gz`及113文件SHA、before_git_status；旧控制器/重放/静态库保留，`implementation.patch`是本轮实际源码差异。可仅恢复3个原文件并移除新增测试后经主入口重构建；不要用旧Git HEAD覆盖继承未提交改动。未提交、未推送。
- 后续事项：以真实计算截止/观测边界事件为目标，继续联合分析候选可执行性与后备构场峰值；再冻结交错多轮验证。当前不宣称导航提速或全工况连续可控。

### 2026-10-06 12:23 — [ausim_biped] 31000替换35000为手柄默认，启动与关键回归通过

- 状态：完成同步、默认切换、构建和启动检查；人工操控待用户验收。
- 目的：使用联合筛选15/15的31000，兼顾停车静止与背面高台。
- 项目路径：`/home/starry/isaac-data/ausimlab/sim2sim/vendor/ausim2-main/ausim_biped`。
- 涉及文件：policies/parkour_model_31000、policies/provenance.json、run.sh、run_gamepad.sh、build.sh、CMakeLists.txt、README/CURRENT_IMPLEMENTATION/WORK_LOG、validation/20261006_model_31000_gamepad及筛选/任务状态后续记录。
- 修改内容：默认运动策略35000→31000，原stand保持；构建参数显式重设缓存，编译默认/脚本/预检统一。17份完整包和checkpoint与筛选模型哈希匹配；39旧策略文件与22生产src不变。
- 验证：build.sh成功，3脚本语法通过，CTest8/8，北通实际/dev/input/js0 --check通过。正式默认前梯8.005sroot=(3.3039,-.1613,1.2382)m且有限/直立；部署目录早停0持续落脚、RMS.000944、漂移.002046m；背面近距离起步与停后重启通过。实际手柄入口/proc加载31000，无诊断preload，joy打开且桥收到零速度；退出130、全部所属子进程回收。
- 影响与边界：本轮重跑4项相关闭环工况，非重跑90项筛选；无C++源码修改，未运行格式化。人工扶直/RB/LB/摇杆完整操作未代验收，未连接真机；manifest保持原状态。
- 回滚/备份：`/home/starry/isaac-data/备份/ausim_biped_before_model_31000_20261006_122032`，93文件及SHA；含切换前模块/旧策略/二进制/缓存。35000和30000原位保留；恢复旧入口/构建配置后build.sh可回退。
- 后续事项：用户启动run_gamepad.sh，验证松杆停车及背面高台持续接近/停后重启。

### 2026-10-05 19:43 — [EGO1P2] 完整复制 EGO1P1 并建立后续版本状态说明

- 状态：完成复制、路径适配、状态整理和构建/回归；未进行新导航性能验收。
- 目的：按用户要求保留目前 EGO1P1，完整复制为 EGO1P2，并说明代码算法进度和未达标内容。
- 项目路径：`/home/starry/isaac-data/EGO1P2`；保留来源 `/home/starry/isaac-data/EGO1P1`。
- 涉及文件：新建完整 EGO1P2 目录；其内有意适配 `AGENTS.md`、`README.md`、`WORK_LOG.md`、`scripts/build_isaac_ros_workspace.sh`、`scripts/run_isaac_fov_gvf_navigation.sh`、`src/pc_gvf/launch/navigation_benchmark.launch.py`、`tools/run_navigation_benchmark.py`、`tools/analyze_navigation_benchmark.py`、`tools/verify_navigation_replays.py`、`tools/ros_vector_guidance_probe.py`；新增 `EGO1P2_VERSION.md`、`performance/branch_copy_20261005/` 清单/校验脚本/测试证据。同步更新 `HISTORY/README.md`、`PROJECT_INDEX.md`、`FOV_GVF_FAMILY.md` 和 `CHANGELOG.md`。
- 修改内容：用 `cp -a --reflink=auto` 全量复制 2,789 文件、321 子目录（含隐藏文件、Git、未提交改动、全部失败实验），复制前后 SHA256/类型/模式一致，无源目标文件硬链接。新目录默认使用 `/tmp/fov_gvf_ego1p2_isaac_{build,install,log}`、独立 ROS 日志/重放路径；实验新增 ego1p2，保留三个旧版标识。共用 ROS 域和单实例锁继续防止重复控制。原算法、主 launch 参数、场景与历史实验不改。
- 状态说明：明确默认是深度候选→单三维矢量整形→完整运动/制动认证的工程混合实现；静态证据、0.48m机体/0.58m认证、实际1.2m/s²模型不改。继承 final_v4 的 EGO1P1 69.893s 对 user_ego 68.980s，仍未全面领先；主动信息增益/系统回退、跨地图/当前手柄动态验收等缺项写入版本说明。不得把继承成绩改名成 EGO1P2 新成绩。
- 验证：执行 EGO1P2 主 build 脚本，3 包构建成功（23.2s）；`PYTHONNOUSERSITE=1 ctest --test-dir /tmp/fov_gvf_ego1p2_isaac_build/pc_gvf --output-on-failure` 18/18；加载 Humble 与 EGO1P2 local_setup 后 `/usr/bin/python3 -m pytest -q EGO1P2/src/pc_gvf_platforms/test` 15/15；43 Python AST、3 Shell `bash -n`、`git diff --check` 通过。只生成 benchmark launch 描述，ego1p2 二进制/3包前缀均指向新安装目录；没有启动仿真节点。完整清单再审计证明 EGO1P1 未变、无继承文件删除、复制的 Git/场景/历史实验一致。Isaac GUI、手柄动态、导航和新性能对照本次未运行。
- 校验问题与处理：首次保留审计因 Python 3.10 不支持 `hashlib.file_digest` 失败，改分块 SHA256；再次检测副本 `.git/index` 字节刷新，核对 `git ls-files --stage -z` 暂存内容相同且来源 index 未改后恢复副本 index，完整审计通过。过程见 `audit_notes.json`；未省略失败，未改来源。
- 影响与边界：EGO1P1 完整保留，EGO1P2 可独立构建；本轮是目录版本建立，不是算法提速或论文复现完成。旧报告/日志的 EGO1P1 名称与旧命令保留历史含义，新运行使用 README/EGO1P2_VERSION。复制的 Git 仍为 ego1p1、HEAD 50f7c5500af86e31d0d9af03de8ec9a29ffb10e1；工作区未提交改动完整继承，本次没有建 Git 分支、提交、推送。
- 回滚/备份：原 EGO1P1 与复制前逐文件清单保留，可随时从来源重新建立另一副本；不得以早期 Git HEAD 单独代替当前来源工作区恢复。
- 后续事项：后续工作在 EGO1P2 进行，算法全面领先、主动探测/回退与真实手柄等仍需单独实现和验收；本次目录任务已完成。


### 2026-10-05 19:42 — [ausim_biped] 筛选四个中间检查点，选出31000候选

- 状态：筛选完成；31000唯一15/15通过，未切换默认模型。
- 目的：寻找同时解决停车踏步并保留背面0.4m高台能力的既有checkpoint，避免直接重训。
- 项目路径：`/home/starry/isaac-data/ausimlab/sim2sim/vendor/ausim2-main/ausim_biped`；远端`/home/ubuntu5090/cwl/ausim_rl`。
- 涉及文件：validation/20261005_checkpoint_screen（四个完整导出包、31000.pt、screen.py、隔离restart探针/构建、protocol、90次JSON/CSV、selection与README）；模块README/WORK_LOG、此前回归后续状态；远端runs/remote_jobs/20261005_checkpoint_screen与工作日志。
- 修改内容：仅独立导出和诊断筛选；15项预设标准同时要求静止7项、正面楼梯1项、背面近远5项、停车后重启2项；重启探针仅时间段内清零指令，无生产控制修改。
- 验证：四checkpoint各364张量有限，60manifest文件哈希通过、contract与现用35000完全一致、12组ONNX对拍最大4.768372e-7。格式化15/诊断编译/Python语法通过。90仿真实际完成：30000=10/15，31000=15/15，32000=13/15，33000=14/15，34000=12/15，35000=13/15。31000停车持续落脚全部0，最大漂移.00802m，高台5/5和重启2/2。所有失败保留，未放宽门槛。正式g1/scene/脚本及39部署文件哈希不变；未重建正式g1或重复CTest。
- 影响与边界：仅确定31000通过本组固定历史，不是随机成功率或完整人工验收。默认仍35000，未重新训练、修改奖励或连接真机。
- 回滚/备份：新产物独立目录；原模型不覆盖。31000原权重下载哈希1841d6fb1fefb6435610e6910ffceab0706ef36b82bf236a9d7351cec4e836b5；四包归档哈希3425c99aadb37801dc9484494d277f63f4d683e2aa16441a9c84cfd939b13ebf。
- 后续事项：建议对31000做人工手柄验收，再决定默认切换。

### 2026-10-05 19:26 — [ausim_biped] 复现静止微调后的背面高台能力回退

- 状态：完成配置与模型审计及12次有界仿真诊断；未修复模型，人工远处失败轨迹未完整复现。
- 目的：解释35000解决停车踏步后为何较难跨默认平台0.4m背面。
- 项目路径：`/home/starry/isaac-data/ausimlab/sim2sim/vendor/ausim2-main/ausim_biped`。
- 涉及文件：validation/20261005_high_step_regression/compare_back_step.py、6份隔离反向场景、protocol/audit/config_diff/results与逐例JSON/CSV、README.md、模块README/WORK_LOG。
- 修改内容：仅新增诊断副本与记录；默认35000、正式scene.xml和控制代码不改。恢复配置核对只有站立比例.05→.20、采样8–12→4–8s、静止权重-.3→-.6、速度项0→.1；整个actor_critic被训练更新，单项因果未证明。
- 验证：39策略文件哈希匹配、22生产src与切换前一致、旧新contract字节相同。相同生产g1、stand2s热身、.5m/s持续指令、10s、真实深度的6距离×2模型：0.4m旧跨上/新未跨上，.25m均失败，.6/.8/1.2/1.6m均跨上。失败新模型root最高.853m、踝最高.223/.195m，最终侧移。所有例终态finite/upright，但不等同跨台成功。未重新构建或运行CTest。
- 影响与边界：确认至少一个高台起步工况发生权重行为回退；标准远处正对接近成功不否定用户人工远处失败。此前8/8仅测试正面.1m梯级，遗漏背面.4m高台，现补充限定验收范围；不能归因于PD降额或单一奖励系数。
- 回滚/备份：生产模型/脚本保持；新诊断独立目录，旧模型和此前备份保留，无需恢复生产文件。
- 后续事项：联合停车、正面/背面近远与停起场景比较31000–34000中间checkpoint，按结果决定进一步训练；本轮未发起。

### 2026-09-30 03:35 — [EGO1P1] 收束验证完成，全面优胜目标仍未达标

- 状态：部分完成，非性能验收通过；不标记用户要求的全面优胜已完成。
- 目的：确认退化配置已撤回、当前源码与实际运行对应，并完整保留比较证据。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：保留的控制/配置与测试、README/NAVIGATION_BENCHMARK/PAPER_IMPLEMENTATION、performance/navigation_benchmark_20260929、HISTORY README/FOV_GVF_FAMILY/CHANGELOG及WORK_LOG。
- 修改：主launch SHA与frozen_v4完全相同。相对v4仅四个源码/测试文件包含默认关闭的局部路径完整包络证明；retained_sources归档114文件、源码包、控制器及重放二进制。未修改旧算法、公共协议/运行端或地图。所有79–85退化试验原始数据、归档及参数保留，未覆盖冻结均值。
- 验证：最终3包构建成功，核心CTest18/18，平台整目录15/15（先math子集7/7，后完整目录）；22份Python AST、3份Shell bash -n和git diff --check通过。82/83/84/85共11+2+1+2=16个已保存候选的核心快照用当前二进制重放全部一致，不重建ROS候选或墙钟截止。user_ego44、EGO1P0 46源码SHA未变，原USD/occupancy及共同运行源码SHA未变；初次完整性脚本误把共同文件相对路径按cwd读取报FileNotFoundError，修正基目录后审计通过，未改被检文件。
- 恢复后实测：retained_check完整协议单轮安全到达69.266667仿真秒/69.906228墙钟秒；停车0.250秒、jerk1.685936、路径133.264308m、最小保守机体净距0.157082m，外部保护和扫掠重叠均0。源码冻结后未改、实际二进制和launch与归档一致；单轮不计入v4五轮均值，也不声称新五轮验收。
- 性能结论：最近完整五轮仍为v4，新版69.893仿真秒/70.981实际秒，user_ego68.980/69.106；新版停车/平均jerk/净距更好，完成时间与波动更差。EGO1P0旧五轮均240秒超时并有保守扫掠重叠；v3新版曾4/5，失败不隐去。全面优于两个旧算法尚未成立。
- 影响与边界：静态场景、固定起终点和统一实际物理；旧内部规划制动2.5、新完整认证1.2这一不对称已披露。手柄/实物/跨地图未验收，当前工程混合方法不是论文全部公式原样实现。未来需要联合优化候选选择与动态可执行性，不能承诺相同调参必然领先。
- 回滚/备份：任务开始19:29全备份、frozen_v1/v2二进制与哈希、frozen_v3/v4源码包和当前retained归档；全部失败保留，未提交或推送。
- 后续事项：用户要求的速度与稳定性全面优胜仍未完成；禁止将本条误读为该目标验收通过。


### 2026-09-30 03:27 — [EGO1P1] 撤回退化候选并收束当前阶段验收

- 状态：部分完成；同地图实测与多轮优化已执行，“全面胜过两旧版”未完成。
- 目的：保留已验证主策略，明确未达标项，不用最快单轮或删失败制造优势。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：主launch、paper_guidance.hpp/cpp、控制节点、motion_consistency_check、验收/方法/入口文档、性能归档及HISTORY。
- 修改：85旧48×36角域到达72.3833秒，恢复64×48。当前默认执行策略恢复final_v4：保守深度目标候选、2.4指令斜坡/jerk6、真实1.2物理与.58认证、固定目标前向+历史、手动四路、10Hz完整接纳/60Hz控制；局部网格、前馈、取样候选、调和建议均关闭。83新增完整路径机体几何检查及回归保留，仅影响关闭的局部路径选项，不作为默认提速成果。
- 当前正式证据：final_v4新旧user各5/5安全到达，新69.893±1.336仿真秒/70.981墙钟，旧68.980±.403/69.106；新停车.25对旧.497，jerk1.903对2.001，但速度慢、完成时间波动大，所以未全面领先。原final_v1 EGO1P0五次240秒超时且保守机体扫掠审计不通过，原样保留。v3一次超时与所有退化配置均保留。
- 验证：新完整路径回归包含于83的18/18；平台15/15为既往冻结结果。当前收束重构建/全量回归/旧源码与地图SHA/语法差异核对待执行，以后续记录为准，不预先写通过。当前源文件含关闭分支的几何修正，不能声称与v4二进制逐字节一致。
- 影响与边界：论文原调和场/流盒为后备，主链为工程混合；真实手柄、实物、多地图未验收。没有放松未知空间/物理边界，也没有改旧算法或共同平台来制造优胜。单条路线优化不能保证任意地图领先。
- 回滚/备份：19:29全备份、各冻结源包/二进制、全部参数/轨迹；本轮当前源将另外归档retained_sources。
- 后续事项：动态可执行性与候选排序仍需联合优化，宽角度分支选择和极端计算延迟尚未根治；不能承诺单纯继续调参必然胜出。未提交推送。


### 2026-09-30 03:24 — [EGO1P1] 前馈未提速，核对旧版候选角域尺度

- 状态：全面领先尚未通过。
- 目的：区分角域离散选路变化与实际安全约束。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：主launch、性能及双日志。
- 结果：84前馈到达71.0833秒，未提速，已关闭并恢复jerk6；完整指标见iteration84_analysis。
- 修改：85仅将保守角域64×48改为旧user_ego默认48×36，净空奖励已有48列归一化；前向固定目标/手动四路、10Hz完整接纳、60Hz控制、原始点矛盾检查、.58m认证及全部物理参数不变。局部路径保持关闭；新增完整路径几何检查与测试保留为可选模式的正确性修正。
- 验证：待构建和实际运行；分辨率改变不等于降低安全标准，粗化仍由保守深度下采样执行，不能以成功单次替代冻结重复。
- 回滚/备份：恢复64×48回到v4默认执行策略；全部冻结/探索/失败保留。
- 后续事项：核对耗时和安全后形成当前阶段结论，未提交推送。


### 2026-09-30 03:21 — [EGO1P1] 保留路径几何修正，撤回默认局部路径

- 状态：全面领先未通过。
- 目的：保留正确的候选空间证明，避免性能退化；重新核对低延迟链路下的响应补偿。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：主launch、完整路径证明/回归、实测与双日志。
- 结果：83到达74.9333仿真秒，多个TARGET_HOLD和计算截止事件；核心18/18通过，但实际导航性能退化，局部路径恢复关闭。新增proposalPath及中心/边缘/中段未知测试作为可选路径的正确性修正保留，不把它写成已提速。
- 修改：84仅在现有前向消费、60Hz控制/10Hz接纳且局部路径关闭的基础上，启用已有独立速度参考前馈、jerk3。此前前馈在四相机和局部路径开启时实测不够平滑，本轮检验低延迟链路下的效果。前馈模式仍使用真实1.2m/s²限制，proposal_command_accel参数不在该模式生效；完整实际状态制动证明和2m/s上限不变。
- 验证：83实际结果/完整几何审计保留，84待构建及实跑；不将既往前馈失败删除或声称理想同步单元测试等于真实平滑。
- 影响与边界：旧源码/共同平台不变，未减少实际安全包络。
- 回滚/备份：关闭feedforward、jerk恢复6即回到v4执行策略（可选局部路径新增更严格几何检查）；所有冻结与失败保留。
- 后续事项：真实导航/重复验证，未提交推送。


### 2026-09-30 03:16 — [EGO1P1] 对局部候选路径补齐完整机体几何证明

- 状态：新方案验证中，全面领先仍未通过。
- 目的：修正局部候选只证明中心点可见、机体边缘可能伸入未知的问题，减少被吸引到认证边界。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：paper_guidance.hpp/cpp、控制节点、主launch、motion_consistency_check及双日志/实测记录。
- 修改：82取样候选最终安全到达130.30秒/126.995墙钟，停车56.483秒、jerk9.8003；性能失败，撤回取样。83局部路径每次重规划后必须调用proposalPath，以原.58m包络逐段证明整条路径在真实深度+认证历史中，不能只查中心或顶点；只有通过后才允许替代较长深度目标分支，原15°任意夹角限制由完整路径几何证明取代。当前状态到新方向的动态过渡和全程制动仍逐周期独立认证。路径几何查询不记录新自由证据、不授权执行。
- 验证：新增回归覆盖弯折路径已知、中心已知但机体外缘未知、两端已知而中段未知、陈旧观测和查询不产生证据；正在构建执行，不提前写通过。82全部扫掠重叠0，不能将长停低速写成性能优化。apply_patch因已有沙箱mountinfo故障无法执行，改用已授权Shell精确编辑。
- 影响与边界：不放松未知/尺寸/物理/旧基线；只加强候选路线筛选，不能保证未来动态可行或持续通行。非论文新增完整复现声明。
- 回滚/备份：frozen_v4源码包；关闭局部路径即可恢复v4执行策略，全部探索数据保留。
- 后续事项：回归及真实场景后决定是否冻结，未提交推送。


### 2026-09-30 03:11 — [EGO1P1] 撤回调和建议，区分候选取样与安全证据

- 状态：全面领先仍未通过。
- 目的：检验保守深度缩图是否在方向候选阶段放大通道封闭。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：控制节点、主launch、性能与双日志。
- 修改：81调和场建议耗时71.2333秒，未优于v4，节点与launch恢复冻结v4原文件；试验节点另存rejected_harmonic_proposal_node.cpp。82启用已有paper_sampled_proposal，只给候选规划传近邻采样深度，实际空间认证/走廊认证仍用原保守缩图，每个接纳帧全部原始障碍点仍参与矛盾撤销，.58m执行包络不变。与此前稀疏原始点锥方案不同，此处仅生成固定64×48方向候选。
- 验证：81构建、核心18/18通过并实际到达；独立审计另存iteration81_analysis，统计不与v4混合。82待构建和实跑，不能预先写改善。
- 影响与边界：候选不是运动授权，未知区域不能由取样变为可通行；旧源码、场景、物理和共同基准不改。
- 回滚/备份：去除paper_sampled_proposal即还原v4，原冻结源包和全部失败保留。
- 后续事项：实测审计与最终重复，未提交推送。


### 2026-09-30 03:08 — [EGO1P1] 调和场建议方向对照

- 状态：优化中，全面领先未通过。
- 目的：检验直接追安全目标方向与沿角域调和场转向的差异。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：控制节点、主launch、实验及双日志。
- 修改：80提高接纳至30Hz安全到达71.75秒/74.4347墙钟、jerk2.3784、停车.25秒，未胜出，恢复10Hz。81显式paper_harmonic_proposal=true，computeGuidance保留direction_proposal_only但计算调和场并使用其command_world作建议；最终3D整形与完整制动认证不变。选定安全目标与场给出的中间建议方向分别保存，避免拿中间切线覆盖下一帧目标记忆；局部路径仍关闭，若启用则记忆被替换的真实目标。
- 验证：80独立扫掠重叠0、构建通过。81使用已有核心调和场/方向候选接口，正在构建回归，未提前写实测结果。
- 影响与边界：此为工程混合控制路径，不能称论文逐式完全复现；物理、速度、包络、未知规则、旧算法与地图不变。
- 回滚/备份：关闭paper_harmonic_proposal可恢复目标方向模式，frozen_v4源包与二进制保留；所有探索失败保留。
- 后续事项：单轮筛选后冻结重复；未提交推送。


### 2026-09-30 03:04 — [EGO1P1] 撤回候选缩小，检验前向观测时效

- 状态：未达全面领先，继续探索。
- 目的：减少慢速障碍释放和过时目标带来的绕路。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：控制节点、主launch、实测记录及双日志。
- 修改：79候选半径.50结果75.9167秒，较v4明显退化，撤回为.58；80仅将固定目标前向消费下的完整帧接纳10→30Hz，控制60Hz、真实相机发布60Hz、完整安全证明不变。三帧障碍释放原本随10Hz接纳变慢，该试验检验提高时效是否改善选路，尚不预判结果。
- 验证：79构建成功；第一次CTest漏设PYTHONNOUSERSITE造成NumPy2与系统扩展冲突，两Python项失败（C++全通过），修正环境后完整18/18通过。79实测到达，独立几何审计正在执行，不提前写安全通过。80待构建实测。
- 影响与边界：没有减小执行包络或改变旧算法/公共物理；保留79失败的性能结果。未做真实手柄/实物试飞，未提交推送。
- 回滚/备份：frozen_v4源码包；将depth_processing_rate恢复10即回到v4。
- 后续事项：单次探索之后还须冻结重复，不混合不同配置平均。


### 2026-09-30 03:01 — [EGO1P1] 第四组完整结果及候选膨胀对照

- 状态：部分完成，全面领先仍未通过。
- 目的：核对全部重复结果并降低候选筛选的额外保守性。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：depth_angular_controller_node.cpp、performance/navigation_benchmark_20260929、WORK_LOG/HISTORY。
- 验证：final_v4新旧各5/5安全到达、扫掠重叠0；新版69.893±1.336仿真秒、70.981墙钟秒、jerk1.903、停车.250秒；user_ego68.980±.403、69.106、2.001、.497。新版一轮72.283秒且有.1秒计算超时，不能删除该轮或用最佳结果替代。114源码哈希未变、10轮无提前中止、公共SHA与v1相同，二进制/launch各算法唯一；核心18/18及平台15/15冻结前通过。已目视检查路线图。v4没有保存到拒绝重放帧，未声称该组重放通过。第一次完整性脚本读错exploration_stall_s层级报KeyError，修正为结果顶层后完整性通过。
- 修改：下一探索79只把深度方向候选的锥膨胀由.58改为实际body+safety=.50m。候选必须经过原.58m走廊认证，最终指令仍经原.58m完整过渡/制动认证；未改任何自由空间证据、未知规则、真实机体或物理参数。考察是否减少更短支路被过早丢弃，不能先验宣称有效。
- 回滚/备份：frozen_v4_sources.tar.gz及114文件SHA、二进制/launch；恢复候选body_radius=paper_->envelopeRadius()、safety_margin=0可撤回79。
- 后续事项：构建/回归/实测79，全部失败保留，未提交推送。


### 2026-09-30 02:39 — [EGO1P1] 冻结第四组，前向目标模式与旧版交错复测

- 状态：正式验收中，尚未达成全面领先。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：performance/navigation_benchmark_20260929及本地/全局记录、HISTORY入口状态。
- 冻结候选：以78为准，指令斜坡2.4/jerk6，真实1.2m/s²不变；固定目标只消费前相机+认证历史，手柄保留四相机；相机仍60Hz发布，算法接纳10Hz完整帧、控制60Hz；局部网格覆盖关闭，净空奖励按旧48列尺度归一化，有效目标记忆一致；.58m认证不变。
- 78实测：安全到达69.30仿真秒/69.1771墙钟，jerk1.7185、停车.25秒、路径133.3622m、净距.1906m、扫掠重叠0。77对应69.1833/71.2141/1.6355，墙钟存在波动，因此必须重复，不能从单次得出普遍胜出。
- 验证：78加速指令回归通过；冻结前完整核心18/18、平台15/15正在执行或已由日志给出结果，通过后串行启动final_v4。实际最终测试结论以ctest_frozen_v4/platform_frozen_v4日志和该组结果为准。此前真实模式4/1路切换通过。正式5轮与user_ego交错，不提前中止、不并行构建/测试，保持公共原协议及旧源码。
- 归档：frozen_v4_sources.tar.gz/114文件SHA、主launch、控制器/重放二进制、逐轮参数/公共SHA；先前所有失败和v1/v2/v3数据保留。
- 影响与边界：消费策略是新算法自动目标模式的变化，必须披露；未改旧算法或公共物理来制造优势。HISTORY README/FOV_GVF_FAMILY已同步截至v3失败及后续试验，规则本身未修改。
- 后续事项：完整重复和独立安全审计结束后形成结论，未提交推送。


### 2026-09-30 02:35 — [EGO1P1] 归一化后路线试验完成，继续核对指令响应上限

- 状态：尚未全面达标。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：主launch、motion_consistency_check、性能记录。
- 77结果：安全到达69.1833仿真秒，详细墙钟/jerk/几何见iteration77_analysis.json；较74单次69.4833有所改善，仍不能替代重复均值。77完整18/18通过。
- 78修改：指令斜坡1.8→2.4m/s²，jerk仍6；真实物理与安全预测的加速度上限仍1.2m/s²。回归夹具同步验证更高指令上限，实际执行上限、完整制动、发布覆盖、松手与回放约束不变；不改变公共车辆动力学。
- 验证：正在构建与测试，若jerk/认证失败不得启动实际试验；不预先写通过。
- 影响与边界：保持前向固定目标感知、手动四相机、原场景及旧源码不变。未知拒绝和.58m认证包络不变。
- 回滚/备份：将paper_proposal_command_accel恢复1.8即回到77配置，所有原始数据保留。
- 后续事项：冻结重复确认收益，未提交推送。


### 2026-09-30 02:31 — [EGO1P1] 按旧版48列基准归一化像素净空奖励

- 状态：继续实测，全面领先未通过。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：控制节点/主launch、性能记录。
- 76结果：安全到达70.2833仿真秒/73.0215墙钟，jerk2.3889、停车.25秒，未胜出。已再次关闭局部路径修正；保留有效选定目标的记忆修复。
- 原因与修改：旧user_ego源码默认48×36且clearance_reward=.018；目标/连续性成本按图像宽高归一化，但净空使用原始像素距离。新版64×48以64为奖励锚点，对相同角域空隙有额外约33%偏好。77改为48/当前宽度归一化，即当前64列的有效奖励.0135，保留旧版对应角域的偏好；并非降低真实机体、安全半径或制动要求。
- 验证：真实旧源码只读核对，未修改；77正在构建/回归与试跑。整体到达、碰撞与时间仍待实测，不能仅凭奖励归一化宣称性能提升。
- 影响与边界：paper_goal_front_only继续仅用于固定目标；手动4路订阅保持。公共地图、协议、.48物理/.58认证不变。
- 回滚/备份：将归一化锚点48恢复64即还原旧偏好，全部冻结与探索数据保留。
- 后续事项：冻结前必须重复验证，未提交推送。


### 2026-09-30 02:26 — [EGO1P1] 修正局部候选与下一帧目标记忆不一致

- 状态：性能未达标，继续验证。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：depth_angular_controller_node.cpp及性能记录。
- 75结果：到达69.85仿真秒；完整数值见iteration75_analysis.json，尚未胜出，不作为最终成绩。
- 原因与修改：局部路径覆盖proposal后，旧逻辑仍把被覆盖的primary目标写回previous_goal_direction_world_，下一周期的滞回目标与实际选定候选不同；goal_valid=false时也把默认像素写成“已有目标”。76改为只有有效候选才保存其真实世界方向，无效候选清空目标有效标志；可视化目标像素同步所选方向。保留15°候选修正限制与完整运动认证，不引入新速度合成。
- 验证：正在构建/实际运行；不能凭代码原因直接断言已经解决平均时间或稳定性。原始75和全部失败数据保留。
- 影响与边界：候选连续性状态变化，实际机体/物理/未知约束、公共协议与旧版源码不变。
- 回滚/备份：frozen_v3源码及本轮逐次参数/二进制SHA；原旧赋值可由冻结控制节点恢复。
- 后续事项：复测并冻结重复，未提交推送。


### 2026-09-30 02:23 — [EGO1P1] 前向固定目标实测提速，局部路径改为受限修正

- 状态：优化中，全面领先尚未通过。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：控制节点/主launch、性能证据与记录。
- 74实测：安全到达69.4833仿真秒/70.4196墙钟、jerk1.8159、停车.25秒，扫掠重叠0。相比73同系列四路消费墙钟73.2331秒有改善，但单次仍未全面优于旧版。控制回调到发布约1.296ms，实际命令59.32Hz；不以名义60Hz写成所有周期满足。
- 模式验证：真实ROS独立域87启动同一节点，use_fixed_goal=false时实际创建4路订阅，true时1路；两项通过，日志见goal_perception_policy_probe.json。无Isaac导航并行干扰该测量。
- 75修改：局部路径仅在深度主建议偏离期望超过2°时求取，且只能替换成与主建议夹角≤15°的局部修正；主建议无效时不能由局部网格单独接管。保留成熟深度目标选路的绕障支路，尝试利用局部路径缩短绕行；所有建议仍独立完整认证。此为工程候选筛选，非论文原始公式；没有放宽安全条件。
- 验证：75正在构建/实际运行，未提前写通过；物理上限、协议、四相机发布和旧源码不变。
- 回滚/备份：paper_local_path_proposal=false可恢复74候选链，逐轮参数与源码冻结备份齐全。
- 后续事项：实测与冻结重复，未提交推送。


### 2026-09-30 02:19 — [EGO1P1] 验证固定终点前向感知策略，保留手动四相机

- 状态：实验中，目标尚未通过。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：控制节点/主launch、性能证据及记录。
- 73结果：安全到达69.4333仿真秒/73.2331墙钟，jerk1.6972、停车.25秒；接纳20→10Hz使证据维护约3.5→1.9ms/周期、墙钟减少约.88秒，不能声称完整运行更快。所有完整机体扫掠重叠0。
- 74修改：新增显式paper_goal_front_only，仅在paper_enabled且use_fixed_goal同时成立时只订阅前向深度；手动模式仍按horizontal_360配置四相机。适用于平台机头随固定目标方向转动的自动导航；当前共同平台已有该规则。仍使用同一完整机体、历史自由体积、完整过渡和制动认证，不能把未观测侧后区域当自由；机头不对准时可能停车。相机发布配置及公共物理不变；与原user_ego仅消费前相机类似，算法消费策略必须公开披露，不能伪称四路当前证据仍在使用。
- 验证：73实际完成且离线审计通过；74正在构建/试跑，未写通过。旧源码未修改，公共起终点/场景/判据不变；不是改变旧算法来制造比较优势。
- 回滚/备份：参数设false恢复全部四路订阅；保留全部冻结及逐轮记录。
- 后续事项：检查完整认证和到达/计算耗时，再决定是否采用；未提交推送。


### 2026-09-30 02:15 — [EGO1P1] 指令斜坡回归通过，降低重复静态观测计算继续验证

- 状态：继续优化，尚未全面优于旧版。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：主launch、intent_response_check版本断言、性能记录。
- 72实测：安全到达69.35仿真秒/74.1092墙钟，jerk1.5671、停车.25秒、路径133.4174m、净距.1962m、扫掠重叠0。物理加速度仍1.2m/s²；平滑性改善，速度未通过。
- 验证：第一次核心17/18，intent_response仍断言旧G格式失败；更新至H格式后18/18通过，其余累计意图/重放等断言保留。72未启动在失败测试之后；实际运行使用通过回归的二进制。
- 修改：73仅将静态深度完整帧接纳20→10Hz，控制60Hz及原60Hz相机发布不变；完整新像素矛盾检查不抽样，未接纳图像不刷新有效时龄；max_depth_age=.3及全机体认证不变。旨在减少约3.5ms/控制周期的证据维护开销，实际收益待运行，不假定必然改善。
- 回滚/备份：全部逐轮参数和冻结源包；恢复paper_depth_processing_rate=20可还原72配置。
- 影响与边界：旧源码、公共场景/物理/协议不变；当前关闭局部路径覆盖，前馈关闭。只适用于已声明的静态场景证据前提，不能外推动态障碍性能。
- 后续事项：验证实际耗时与稳健性后再冻结重测，未提交推送。


### 2026-09-30 02:10 — [EGO1P1] 撤回局部宽度试验，区分指令斜坡和真实动力学

- 状态：全面领先未通过，持续优化。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：paper_guidance.hpp/cpp、paper_replay.cpp、控制节点/主launch、motion_consistency_check、局部路径三个文件、性能证据及记录。
- 71结果：安全到达72.8667秒/77.6487墙钟，jerk3.8069、路径133.8227m、停车.55秒、COMPUTE_DEADLINE累计.4333秒，退化。局部宽度试验已按v3源码包精确恢复三个文件，拒绝实现另存rejected_visible_width_local_path.cpp。当前关闭局部网格路径覆盖，回到已有冻结5/5的深度目标建议主链；当前核心/帧率已有变化，不能直接继承v1成绩，必须重新实测。
- 72修改：速度指令斜坡与真实加速度分开配置。指令斜坡上限1.8m/s²、jerk6，真实plant和完整运动/制动模型仍1.2m/s²；意在减少“指令先慢变、机体再慢响应”的额外延迟。模型反演/前馈继续关闭，输入松开仍立即输出零。V17(EGOPAPRH)保存新参数且兼容3–16；新增真实加速度不变、完整认证、指令jerk/限速、重放和松手回归。
- 验证：71完整18/18后实际性能退化，不能只用合成分支选择通过认定有效。72正在构建，未写成通过。固定公共协议、旧源码与地图不变。
- 回滚/备份：frozen_v3源码包、旧冻结二进制、全部探索参数与拒绝版本；paper_proposal_command_accel=0恢复原指令斜坡。
- 后续事项：先验证72，再决定冻结配置；不以单次替代重复，不提交推送。


### 2026-09-30 02:04 — [EGO1P1] final_v3失败如实保留；候选增加观测空间宽度代价

- 状态：未达到全面领先，继续修正。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：local_depth_path.hpp/cpp、local_depth_path_check、性能目录、方法与验收文档。
- 正式结果：final_v3新版4/5安全到达，成功均值69.1417±.9295仿真秒/73.6159墙钟秒，1轮240秒超时；含失败惩罚均值103.3133秒。旧user_ego5/5，69.0767±.6221仿真秒/69.5436墙钟。不能用失败轮静止稀释后的jerk1.8534声称更稳定；本组不通过且不得删除失败。
- 一致性：10轮完整协议，无探索中止，114源码SHA未变，公共SHA与final_v1相同，两版各只有一组二进制/launch。源码包、二进制与全部原始数据冻结保存；后续修改不追溯计入v3。
- 失败审计：停在(28.0807,3.0941,1.4822)，.58m当前机体可认证，但加.005m余量不可认证；沿意图只有约.0015m认证前缀，后向也仅约.058m。上一命令为零，因此motion_scale0/.5/1均为刹停检查，不能当作能继续飞的证明。证据支持困在认证边界，不能说是碰撞；该轮保守净距仍.2096m。
- 修改：71候选的已观测中心/障碍网格增加距未知或阻塞单元的Manhattan距离代价，权重.03，优先较宽的可见绕行支路；直达中心线畅通时不额外偏离。它只是候选排序，不是假冒欧氏净距或完整体积认证，不改变未知拒绝、真实机体/制动模型。新增窄观测边缘与宽支路对照，待构建实测。
- 验证：v3核心18/18、平台15/15；独立扫掠审计所有新版轮重叠0。71尚未运行；V16、帧处理20Hz/控制60Hz等均保持。正式计时中未构建/测试。
- 71补充验证：首次局部路线回归失败，等代价分支在世界旋转后被微小浮点误差翻转；增加1e-10等价容差后，完整18/18通过。宽观测支路夹具中，长度优先方向约(.862,-.359,-.359)，宽度偏好为(.862,-.359,+.359)。实际导航正在运行，不能用该合成结果替代实测。final_v3另完成17帧同冻结二进制重放一致；最初失败帧因环形缓存覆写不在末尾16帧中，未声称已重现最初瞬间。
- 回滚/备份：完整frozen_v3_sources.tar.gz及所有旧冻结数据；局部visibility_weight设0恢复原候选代价。
- 后续事项：验证候选宽度修正，不以一次成功宣称全面胜出；未提交推送。


### 2026-09-30 01:48 — [EGO1P1] 冻结60Hz控制/20Hz观测候选，完整重复验收

- 状态：验收进行中，全面优于旧算法尚未达成。
- 目的：不以单次最佳值代替重复稳定性，保留失败证据。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：主launch、paper_guidance.cpp、性能证据及记录；EXPLORATION补录55–68。
- 实测：69关闭补偿、jerk6、内部两线程、60Hz控制/20Hz完整帧处理，安全到达69.40仿真秒/74.4248墙钟秒，jerk1.6671、停车.25秒、路径133.0732m、净距.1925m、重叠0，平滑性改善但仍未更快。70仅改30Hz帧处理，在34.2667秒因持续停滞中止；失败惩罚240秒，不算快速到达。已恢复69参数；不能声称高观测频率必然改善。
- 验证：69构建、核心CTest18/18通过；70运行失败及独立轨迹分析保留。冻结v3将重新构建、核心和平台回归后进行5次完整240秒上限测试，且与user_ego交错重测，不使用探索早停。
- 影响与边界：原地图、旧源码、共同物理及相机发布频率不变，安全认证未减弱。仅固定路线验收，不推断任意地图优越性。
- 回滚/备份：任务起始tar、frozen_v1/v2和所有探索日志；69参数可直接由保存的parameters恢复。
- 后续事项：如重复失败必须报告，不能剔除失败轮或写全面通过；未提交推送。


### 2026-09-30 01:39 — [EGO1P1] 撤回高jerk前馈，分离观测处理与控制频率继续验证

- 状态：性能目标未完成，继续实验。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：控制节点、paper_guidance.hpp/cpp、paper_replay.cpp、motion_consistency_check、主launch及性能数据。
- 实测：62路线保持在62.25秒停滞中止，已撤回；63独立执行器70.0333秒/77.5827墙钟/jerk2.6352，已撤回；64软路线方向69.05/74.8497/2.1893；65原生候选采样73.1/80.0726/3.5575，已撤回采样；66直接模型补偿68.65/75.8556/4.1972；67独立参考前馈68.4333/75.4545/4.5897。66/67均速度略快但平滑性退化，不能算通过。68前馈下60Hz控制、30Hz深度处理到达68.5167/73.7928/3.4688，仍不通过平滑性；上述成功轮机体扫掠重叠均0。
- 修改：67独立积分速度参考、加速度/jerk约束和响应前馈及发布覆盖复位，V16保存参考状态、兼容旧重放；理想同步单元测试通过不等于真实异步系统平滑。68新增可配置控制频率和按图像时间戳限流；未接纳帧不认证空间也不刷新证据时龄。原相机发布仍60Hz、所有接纳帧原始像素仍完整安全检查。69关闭前馈恢复jerk6，保持60Hz控制，将接纳频率30→20Hz、内部OpenMP4→2，减少与仿真CPU竞争，待实测。
- 验证：67完整CTest18/18；68构建、相关2项通过且实际完成导航。69尚未运行，不提前写通过。真实67高jerk否定了仅凭理想plant单元测试的性能判断。
- 影响与边界：旧算法、公共物理/相机发布/地图/起终点不改，完整.58m体积与制动认证不放松。新限流属于算法计算策略，必须在比较中披露；不声称处理了全部60Hz帧。未提交推送。
- 回滚/备份：任务起始备份、冻结v1/v2、逐轮参数与二进制SHA；拒绝执行器/采样/保持代码单独归档。
- 后续事项：实测69，再冻结重复；全面领先尚未通过。


### 2026-09-30 01:06 — [EGO1P1] 验证惯性前视与历史几何加速；仍未通过全面领先

- 状态：持续优化，未完成全面领先验收。
- 目的：减少绕行和重复几何检查，保留所有退化实验。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：local_depth_path.hpp/cpp、paper_guidance.hpp/cpp、控制节点/主launch、局部路径/观测测试、PAPER_IMPLEMENTATION、实验目录及记录。
- 结果：56去局部回轴惩罚安全到达68.9833秒/74.5678墙钟/jerk2.0446；57仅缩候选余量至.10在33.8167秒停滞中止。58候选障碍沿实测速度反方向延长两个响应时间，保留.10候选余量，安全到达68.70/75.0447/jerk2.1705、路径132.0478m、最小净距.2195m、重叠0；单次略快于旧均值，但墙钟和平滑性未通过。59将历史16→4后46.7667秒停滞中止，已恢复16。60原始光学坐标点组+jerk4到达70.0833/76.8484/jerk3.0747、重叠0，已恢复jerk6。61增加近等代价路线保持，到达70.0/77.0268/jerk2.9171，未胜出。
- 修改：点组先在输入光学坐标中包围，再一次变换到旧相机，避免两次轴对齐放大；只剔除确定不冲突组。62新增小投影矩形的完整深度上界检查，最多128像素逐个检查，任何未决组仍逐个原始点检查；不使用地址缓存，不抽样。局部路线代价采用剩余弧长，意图变化或完整运动失败取消保持；手柄改向阈值以被保留路线的原始意图为基准，避免累计变化漏重设。
- 验证：60第一次编译Eigen条件表达式存储类型不一致失败，改为显式赋值后构建、18/18通过；再加实测迎障速度提前转向及无效时间测试通过。62构建、完整18/18通过，含投影区域中单个深像素不得被批量排除、60组独立穷举比较。61已运行二进制尚是逐次更新路线意图基准的版本；累计基准修正属于62，不能追溯算给61。62实际导航正在运行。
- 计时证据：历史维护总耗时约7ms/周期，记录到达几何约.02ms；细分每相机球处理约.4、胶囊约.3、历史检查约1.1ms。不能把记录到达几何说成主要瓶颈。减历史导致的失败不作为更快成绩。
- 影响与边界：公共物理、场景、起终点、.48机体/.58认证及旧源码不变。惯性候选与路线保持是工程扩展，最终完整实际过渡和制动检查仍授权唯一三维命令。未提交推送。
- 回滚/备份：任务起始备份、冻结v1/v2二进制/源码SHA和逐轮参数/轨迹完整保留。
- 后续事项：验证几何加速与路线连续性，再冻结重复统计；全面领先尚未达成。


### 2026-09-30 00:45 — [EGO1P1] 认证记忆回归通过；历史采样改为独立时钟，继续比较

- 状态：部分完成，全面领先未通过。
- 目的：保持已认证自由体积并消除历史淘汰引起的重复处理；分别检查行程和计算开销。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：paper_guidance.hpp/cpp、控制节点、主launch、local_depth_path.cpp、continuous_recovery/observed_space测试、实验目录/记录。
- 结果：53完整CTest18/18，安全到达69.05仿真秒/76.4696墙钟秒/jerk2.7092，原4.7秒停车消失；21.17秒执行端一次零命令脉冲仍增加jerk。54历史32→8时安全到达70.7167/76.6231/jerk2.6946，历史淘汰超过2000次，未胜出。55采样时钟独立于淘汰/撤销并恢复16幅历史，安全到达69.1333/74.8157/jerk2.0764，扫掠重叠均0，仍未超过user_ego均值。
- 修改：历史采样时钟不再随覆盖淘汰或矛盾撤销重置；所有新帧仍逐点检查冲突。查询时先检查同一几何联合中的最近已认证球，未放松包含判据。第56轮撤销局部路线中间点到意图轴的额外距离惩罚，仅保留长度、转向和终点距离代价，以减少局部回轴再绕开的弯路；增加入口证据/记录耗时统计定位计算热点。
- 验证与失败：55首次18项中observed_space旧夹具假设撤销即重置1000秒采样间隔失败；改为0.5秒独立采样夹具，并增加撤销后0.2秒不得重采、反复淘汰不突破时钟测试，18/18通过。56构建及局部路线/观测/连续恢复3项通过，完整运行进行中。54统计首次环境变量拼写错误导致NumPy ABI绘图失败，正确PYTHONNOUSERSITE=1重跑成功；原数值及失败未掩盖。
- 影响与边界：旧代码、地图、共同物理/起终点不变，完整安全认证、未知拒绝和0.58m包络不变；新几何记忆限静态世界。尚未冻结新一组平均值，无提交推送。
- 回滚/备份：任务初始备份、final_v1/v2冻结数据及所有探索参数保留。
- 后续事项：继续比较并冻结重测；阶段结果不能写为最终达标。


### 2026-09-30 00:33 — [EGO1P1] 定位认证空间交接丢失并增加静态已证体积保留（验证中）

- 状态：实施/验证中；全面优于旧算法仍未通过。
- 目的：解决第52轮起步后约1.08秒的NO_REGULAR_FIELD/COMPUTE_DEADLINE，避免仅靠继续调参数。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：paper_guidance.hpp/cpp、paper_replay.cpp、控制节点/主launch、continuous_recovery/intent_response测试、local_depth_path.cpp、实验目录和记录。
- 前轮结果：51可见短前缀74.8833秒停滞中止，转向权重.4也未通过局部路径单元测试，已恢复固定8m/权重.04；52历史观测+10Hz世界路径跟随安全到达69.95秒/墙钟75.5927秒/路径131.9006m/jerk2.4578，扫掠重叠0，仍不全面领先。52全量CTest18/18通过。
- 因果证据：52的4.7秒失败快照含13幅历史、4幅当前及83个已接受运动的认证球。原证据连完整刹车都拒绝；只将未撤销的83个认证球加入几何查询后，完整刹车可认证。审计本来已包含历史，不能误称历史没加载。此时上一已发布命令为零，所以scale0/.5/1测试都是停车，不证明原速继续可行。
- 修改内容：新增显式paper_retain_certified_volume，仅在已有静态场景/已验证运动记忆/零历史增长前提下复用上一条已接受完整运动检查产生的几何球；并非把预测的机体位置当观测。球必须原先有完整体积包含证明，所有新原始点仍撤销冲突球，不扩张未知。V15(EGOPAPRF)保存开关并兼容旧版本；局部路径加入非有限/远端范围检查。
- 验证：新增未来认证体积保持、未知不扩张、多次继承不生造空间、新障碍撤销、旧模式及重放测试；正在构建，未提前写通过。审计第一次构建因unique_ptr类不可复制失败，改为临时追加/恢复向量后构建成功；直接执行无执行位Shell失败，使用bash主入口成功。
- 影响与边界：旧源码、地图、公共起终点和物理协议不变，完整运动/制动检查不削弱；实验路线候选属工程扩展，非论文逐式原样复现。没有提交或推送。
- 回滚/备份：主launch将paper_retain_certified_volume改false恢复旧语义；任务初始完整备份和冻结版证据保留。
- 后续事项：先回归与单次探索，再冻结重复比较，不能以单次速度证明全面领先。


### 2026-09-30 00:12 — [EGO1P1] 引入深度局部短路径候选；领先目标尚未通过

- 状态：继续研究优化，未完成用户要求的全面领先验收。
- 涉及文件：新增local_depth_path.hpp/cpp及local_depth_path_check；CMake、控制节点、主launch、实验目录和记录。
- 撤回项：46同侧目标收近69.2667秒但jerk3.4537，关闭投影；47图像并发71.5333/jerk3.4373且出现349ms峰值，恢复两线程/原传感组。48真实夹角/4秒前视/静态.55m组合81.0333/jerk5.5668，恢复3秒、原代价、.58m完整包络。当前没有使用这些退化参数。
- 新方法：只用当前真实深度，在随q旋转的局部三维网格中比较前方最多8m的路径长度和转向代价；只作为未经完整认证的方向建议。最终仍先做已知体积走廊检查，再执行原完整实际过渡/制动认证，输出一条三维速度；在线不读全图路线。这个路径选择是工程扩展，不是论文原公式的逐项复现。
- 验证：49首次编译缺Eigen/Geometry链接失败，补齐后构建及3项相关回归通过；空旷直行、未知拒绝、有限障碍绕行、世界坐标旋转/平移通过。49实际候选约9成被采用，安全到达69.0833秒、墙钟75.2529秒、路径132.745m、净距.1853m、jerk2.1272、扫掠重叠0，尚未快于旧均值。50把候选额外网格膨胀.18降至.05并设jerk6后52.2秒因停滞中止，保留失败且惩罚均值240，不计到达；已恢复.18。
- 当前51：转向代价加大，并允许遮挡时使用最深可见短前缀，短前缀本身不授权执行；完整制动走廊不足时仍不能走。相关测试/实测进行中，尚未写成通过。原始数据和所有被拒配置保存。
- 边界：旧源码、地图、起终点和公共物理/到达协议不变；原先final_v1三版各5次仍是有效冻结对照，其未全面领先的结论不被探索单次结果覆盖。未提交推送。


### 2026-09-29 23:49 — [EGO1P1] 完成额外对照并撤回无收益加速，继续验证连续方向

- 状态：性能优化继续；此前final_v1/final_v2冻结组仍未满足全面领先，不以单次最优替代均值。
- 涉及文件：深度核心/控制节点、paper_guidance/paper_replay与头文件、主launch、观测/连续恢复/方向回归、实验目录及记录。
- 结果：37批量深度排除69.65秒/jerk2.2221，38奖励.014为69.3667/2.2313，40奖励封顶6为71.0167/2.9549，41分层点组为69.3833/3.1299，42缩短保持为72.6833/3.1290，43历史16幅为69.4/2.1072；均安全到达但未获总体收益。39主动中止：复核发现原始地址缓存可能在观测释放后复用，修正为持有观测所有权才重跑40。复杂深度缓存、分层分组和临时计时最终均撤回，拒绝实验代码另存rejected_history_tree.cpp。
- 修改：历史容量改为显式参数，默认/当前32，试验16的近场关键观测保留通过；V14(EGOPAPRE)记录容量并兼容V3–V13。候选亚像素二次细化只在同一自由3x3邻域内进行，旧目标保持时不再重新取整；相机/机体原点统一保留。44细化但保持仍取整为70.6167/jerk2.6017；45补齐连续保持并试验静态时龄增长0为69.3833/jerk1.9448，时间仍未胜出。现恢复.58m全包络并开始46：在同一绕障侧将候选向q收近，额外2像素空余且须完整观测走廊重认证，最多4次查询，最终运动/制动仍独立认证。
- 验证：40/41/43完整CTest17/17；42相关4项通过。44初始解析测试缺少真实视场阻塞边界，目标落在图像边缘导致细化不启用，补齐边界后3项通过；45相关4项通过。46尚在构建/试验，不能写通过。所有运行的逐段.48m机体扫掠审计均为0重叠；这仅指以上新版成功轮，不包括旧EGO1P0。
- 边界：旧源码/场景、输入、物理速度和到达协议不变。最终统计仍需冻结复测；当前保留所有失败和中止数据，未提交推送。


### 2026-09-29 23:24 — [EGO1P1] 复测拒绝退化参数；统一候选坐标并验证等价历史加速

- 状态：仍在优化，尚未达到同时更快、更稳的验收目标。
- 涉及文件：深度核心头文件/实现、控制节点/主launch、paper_guidance、guidance_composition/observed_space测试；基准目录及项目/统一日志。
- 结果：34净空奖励封顶试验95.72秒停滞中止；35历史间隔4秒到达70.333秒/jerk2.2737。final_v2仅历史间隔2秒的五次完整复测全安全到达，均值69.3667秒、标准差.7827、墙钟74.4647秒、jerk2.1210，稳定性不如final_v1，已恢复1秒间隔。这些失败/退化不删除，不混入冻结版均值。
- 修改：候选碰撞锥把观测点从拍摄相机原点平移到当前机体中心，保持光学轴不变，补偿安装偏移和取帧后的平移；最终物理视锥与完整制动认证不变。36安全到达69.35秒、墙钟75.7795秒、jerk1.9727，单次不能证明总体胜出。另加历史128点组的保守投影矩形深度上界排除，只跳过逐点检查必然全不构成冲突的组；其余仍逐点检查。
- 验证：36首次测试编译缺Eigen/Geometry失败，补齐后构建和3项相关回归通过；旋转/平移/取帧后移动及原始点两条路径的平面净距与解析解一致。37全量17/17通过，新增60组独立逐点真值对照和原有5个分组边界单点入侵覆盖；37实际导航正在运行，未写成通过。
- 边界：旧源码和地图不改、未知拒绝、机体.48/认证.58m、速度2m/s及公共到达判据不变。没有提交推送。final_v1/final_v2参数、源码SHA、二进制及所有原始轨迹已保留。
- 后续：验证加速的实测收益，定位额外绕行，冻结后再重复验收；不能以单次最优取代平均结果。


### 2026-09-29 22:55 — [EGO1P1] 完成15轮冻结对照；全面领先未通过，继续针对性优化

- 状态：部分完成；对照实验完成，性能目标未全部通过。
- 目的：报告真实平均时间与稳定性，继续处理测量明确的计算和绕行开销。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：NAVIGATION_BENCHMARK.md、实验目录；主launch、depth_angular_core.hpp/cpp、controller_node与guidance_composition测试；WORK_LOG/HISTORY。
- 验证：final_v1三版各5次交错、完整240秒超时，源文件/公共端SHA及每版二进制/launch完全一致。user_ego5/5到达，69.003±.474仿真秒、69.646墙钟秒；EGO1P15/5，69.297±.071、75.643秒。EGO1P0全超时且0.48m包围球离线相交，不能把保护计数0写成安全。新版最小净距.1534m，旧user_ego.0294m；新版停车均值.2167 vs .4267秒、jerk2.0504 vs2.0123。新版导航慢.43%、墙钟慢8.61%、jerk略高1.89%，未通过全面领先。冻结版三包构建、CTest17/17、平台15/15、语法和diff检查通过。
- 后续修改：第33轮历史保留采样1→2秒，仍每帧检查所有新原始点，安全到达69.25仿真秒/74.218墙钟秒/jerk2.0707；计算开销稍降。第34轮进一步将无上限的额外净空奖励封顶于2个基准像素，保留靠近障碍处的奖励斜率、.58m认证及真实夹角，避免越宽越值得偏离q；已构建且相关3项回归通过，正在运行，尚未得出成功结论。
- 影响与边界：固定组及失败原始数据不覆盖，后续版本另编号。没有扩大已知空间、减少新障碍检查或修改旧算法源文件/场景；当前工程混合主链不是论文完整原样复现。图像预览工具因环境沙箱故障失败，改用只读方式检查已生成图像，不影响运行证据。
- 回滚/备份：19:29整包备份；final_v1完整参数与frozen_sources.json、frozen_v1_launch.py及控制器/回放二进制保存，可还原该冻结组。
- 后续事项：验证有界净空偏好及历史去重；只有新版本重复数据才可支持新性能结论，未达标必须继续明确标注。


### 2026-09-29 22:15 — [EGO1P1] 冻结重复对照版本；所有探索保留

- 状态：部分完成，进入五轮实际对照；尚未证明快于user_ego。
- 目的：停止混用不同版本单次成绩，测量可复现的均值与稳定性。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：控制节点/主launch、深度核心/认证核心及回放、测试、README/PAPER_IMPLEMENTATION、实验目录和工作区记录。
- 修改内容：冻结64×48保守深度候选、旧版像素代价、净空奖励.018、左偏.012、保持.35秒/权重.4、前视3秒、参考响应.22秒、矢量jerk8；候选走廊与完整运动/制动证明、有限终点、发布覆盖同步、精确投影和历史分组几何加速保留。原始稀疏点、真实夹角、短走廊意图抢占和模型反演默认关闭，均曾测试但未优于稳定配置。诊断目标改为实际候选矢量，避免相机截断导致显示错误。
- 验证：29原始稀疏点69.47秒停滞中止；30高分辨率69.433秒/jerk2.2462，31去左偏69.55秒/jerk2.2915；32完整短走廊意图优先在95.48秒停滞中止，淘汰。29构建后17/17完整回归通过；冻结版全量回归正在执行，不能提前写通过。原始user_ego44个、EGO1P0 46个文件SHA复核全部未变。
- 公平性边界：保留两版旧算法硬编码的2.5m/s²规划制动假设（无法通过公开ROS参数覆盖），共同物理执行仍1.2m/s²；这是现有算法同平台适应性对照，不能写成内部安全假设完全相同。`speed_brake_accel`是旧命令整形参数，不能误称为规划模型覆盖。此项未暗中修改或调低旧算法成绩。
- 影响与边界：仍.48m机体/.58m认证、未知拒绝、相同地图起终点与2m/s。新版并非完整论文原样主链；旧源码和地图未修改，未提交推送。
- 回滚/备份：19:29备份；冻结源码SHA见frozen_sources.json，各探索完整原始轨迹和参数保留。
- 后续事项：三版各五次交错运行，240秒完整超时，不启用探索早停；如未同时更快更稳定，必须报告验收未通过。


### 2026-09-29 22:01 — [EGO1P1] 三维方向度量与原始候选优化（阶段）

- 状态：实施中；最终均值和优于旧版的验收尚未完成。
- 目的：减少绕障中段的折返，保持完整观测/制动认证并降低历史检查开销。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：depth_angular_core.hpp/cpp、paper_guidance.hpp/cpp、paper_replay.cpp、controller_node、主launch；guidance_composition/observed_space/motion_consistency/paper_guidance测试；README、PAPER_IMPLEMENTATION及实验记录。
- 修改内容：V13独立记录参考响应时间；三维候选用真实射线夹角衡量接近意图，默认旧像素代价接口保持兼容。历史点按128点连续组建立保守AABB，只剔除整个组位于旧视锥外的情况，余下每个原始点仍检查。正在试验原始点每8个抽取一个仅生成方向候选，完整保守深度和所有原始点仍用于执行授权及矛盾撤销，不将稀疏候选当自由证据。
- 验证：25（响应.10/前视2.5）69.383秒、jerk2.3365；26（净空奖励.004）111.767秒/停车14.083秒/jerk9.3257，撤销该配置；27真实夹角/前视3为69.60秒、jerk2.3308；28前视4为69.40秒、jerk2.149。均到达且新版离线扫掠重叠0。29当前恢复响应.22、前视3、净空奖励.018并加入原始候选，运行尚未结束。新17/17完整回归通过，包括5个跨原始点分组边界的小障碍撤销位置和长宽比不等视场的真实转角排序。
- 失败与更正：27首次编译因局部替换误落入nearestFreePixel失败，其后执行的旧测试无新代码验收意义；修复后重构建和相关2项通过。29首次编译因ROS整数参数返回类型不匹配失败，显式转换后构建及17/17通过。早期“完成轮重叠0”只适用于新版，旧EGO1P0 pilot离线扫掠存在负净距（约-.054m），不能推广到三版；最终须按统一独立审计判安全到达。
- 影响与边界：.48m机体、.58m认证、安全未知拒绝、2m/s上限、1.2m/s²及物理.22秒保持；当前混合候选工程路径与原论文差异已显式写入说明。旧源码未修改，无提交推送。
- 回滚/备份：沿用19:29备份，每轮参数和二进制SHA/原始日志完整保留。
- 后续事项：确定稳定有效版本后冻结做五轮交错复测，均值、成功率、平滑度及墙钟开销全部报告。


### 2026-09-29 21:49 — [ausim_biped] 同步model_35000并切换本地手柄默认运动策略

- 状态：完成模型同步、默认切换和启动验证；人工操控待用户验收。
- 目的：让用户通过LB手柄控制自动早停落脚47→0的续训模型。
- 项目路径：`/home/starry/isaac-data/ausimlab/sim2sim/vendor/ausim2-main/ausim_biped`。
- 涉及文件：policies/parkour_model_35000、policies/provenance.json、run.sh、run_gamepad.sh、build.sh、CMakeLists.txt、tests/g1_policy_contract_test.cpp、README.md、CURRENT_IMPLEMENTATION.md、WORK_LOG.md、validation/20260929_model_35000_gamepad与旧验收后续状态。
- 修改内容：默认parkour从30000→35000，原stand保持；显式更新构建缓存参数、预检与启动提示。旧独立golden固定30000参考，生产ONNX smoke跟随新默认。模型包/原权重和源码快照完整复制，旧30000保留。
- 验证：17份新文件等同候选，原22份策略和22份控制src未变；首次format.sh缺PATH工具失败127，切已有clang-format15后成功，无无关改动。build.sh成功；CTest8/8、shell语法和真实北通--check通过。部署早停复测持续落脚0、RMS0.0010038rad/s；默认楼梯8.005秒root=(2.7276,-.0640,1.2430)m且有限/直立。正式run_gamepad启动实测加载35000、joy打开、桥收到速度，未有诊断preload；退出130且清理完成。
- 影响与边界：仅本地MuJoCo默认模型与相关构建/基准绑定变更；完整人工扶直/RB/LB/摇杆操作未代验收，未连接真机。原导出manifest状态保持。
- 回滚/备份：`/home/starry/isaac-data/备份/ausim_biped_before_model_35000_20260929_214256`含76文件及哈希；恢复原入口/构建/CMakeCache/参考测试并构建可回退，原30000权重仍在policies。
- 后续事项：用户按README的ColdStart→人工扶直→RB→2秒→LB流程验证短推后松杆，保持LB不切RB。

### 2026-09-29 21:45 — [EGO1P1] 固定目标候选收敛与矢量响应调优（阶段）

- 状态：实施中，仍未完成五轮最终验收，也未证明快于user_ego。
- 目的：减少候选方向与完整安全执行不一致、远端障碍干扰终点收敛及重复参考滤波。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：depth_angular_core.hpp/cpp、paper_guidance.hpp/cpp、paper_replay.cpp、depth_angular_controller_node.cpp、主launch；guidance_composition/motion_consistency/paper_guidance测试；主Shell、benchmark launch/driver/统计与实验目录。
- 修改内容：安全目标最多12次完整走廊验证后直接作为方向候选，target-only模式不计算也不伪造调和场（goal_valid与field_valid分开）；最终实际过渡/制动仍完整认证。固定终点限制规划距离，目标自然方位变化不作为手柄突变重置。增加精确证据AABB快速剔除；统一OMP_WAIT_POLICY默认PASSIVE。V12记录模型整形开关与jerk，正在V13中独立记录候选响应时间，物理tau仍.22。最新探索前视2.5秒/参考响应.10秒，全部速度、机体、认证和加速度边界不变。
- 验证：iteration17/18停滞中止59.32/68.25秒；19到达70.82秒；20到达69.25秒/jerk2.0566/净距.1571m，为当时最优但仍慢于user_ego68.75秒。模型反演21/22为69.33/69.65秒且jerk2.55/2.83，未采用默认；23静态帧龄余量去除至.55m后79.07秒，已恢复.58m；24前视2秒在68.12秒因停滞中止。完成轮离线碰撞重叠0、外部保护0。完整CTest17/17在target-only之前通过，target-only相关2项已通过；当前V13修改正在构建，尚未验收。
- 校准边界：原始静止起点有限深度与独立voxel+真实地板(-.2m)交线最大误差<.1mm，只支持该样本；初次错误使用地板0的统计单独保留，不能视为传感器误差。未据此宣称全运动误差界，原.03m深度余量及.58m总包络保留。
- 影响与边界：主链变为“安全深度目标候选+完整运动认证+矢量整形”，原论文调和场/流盒仍作失败后备，不能称论文公式完整原样实现。旧算法源文件未改，探索版本不同不能混算均值；最终须冻结版本、独占计算资源重跑。没有提交/推送。
- 回滚/备份：沿用19:29完整备份和每轮参数/二进制SHA；失败试验全部保留。
- 后续事项：完成针对响应延迟的试验，冻结后执行各五轮并报告真实均值、成功率和稳定性。


### 2026-09-29 21:29 — [ausim_biped] 远程微调完成，候选35000本地仿真8/8通过

- 状态：完成本轮训练状态核实、独立导出及自动仿真验收；未切换默认策略。
- 目的：验收LB运动策略松杆后持续踏步的针对性微调。
- 项目路径：`/home/starry/isaac-data/ausimlab/sim2sim/vendor/ausim2-main/ausim_biped`；远端`/home/ubuntu5090/cwl/ausim_rl`。
- 涉及文件：validation/20260929_retraining/acceptance_model_35000（候选包/checkpoint、criteria.json、run_acceptance.py、结果JSON/CSV、README）、remote_job.json、REMOTE_TRAINING.md、WORK_LOG.md；远端验收记录与项目日志。
- 修改内容：新增独立候选归档和8场景验收脚本；任务状态running→completed，保留原启动快照/失败记录。生产源码、控制参数、默认入口和模型不变。
- 验证：远端20:50:49完成，exit0、最终35000，耗时7h37m37s；364张量全部有限；3组ONNX/PyTorch误差最大2.682209e-7；15文件哈希与归档哈希通过。export contract完全一致；env仅记录的命名空间/资源路径/spawn状态不同。执行source scripts/runtime_env.sh和python3 validation/20260929_retraining/acceptance_model_35000/run_acceptance.py，8/8通过；早停47→0落脚、转向停车43→0，停车稳定后漂移<1cm。楼梯8秒root=(2.7276,-.0640,1.2430)m，finite/upright=true。22个部署文件哈希未变。未重新构建或运行CTest，未进行人工手柄/真机测试。
- 影响与边界：证明既有复现工况改善及有限楼梯回归通过，不等于任意工况或真机部署完成；此前同场景旧模型8秒x=3.1546m，新模型距离变短。当前run_gamepad.sh仍使用model_30000。
- 回滚/备份：默认策略未覆盖；新产物独立保存；原模型与远端源码修改前backup完整保留。checkpoint SHA-256为6a1e58199120f373e5dd43f47e99e51968ab26229b23b397268312fc5a33b631。
- 后续事项：候选模型可用于人工手柄复核，再决定默认策略切换。

### 2026-09-29 21:10 — [EGO1P1] 公共回调修复、等价几何加速与候选/执行失配诊断（阶段）

- 状态：实施中，未达到同时优于user_ego的目标，未做最终五轮验收。
- 目的：区分虚假失联、重复速度限幅与真实已知自由空间边界停车。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：Isaac运行器/navigation_benchmark.py、benchmark launch/driver/统计；depth_angular_core.hpp/cpp及节点；depth_geometry/guidance_composition/motion_consistency/protocol测试与CMake；实验目录和工作区记录。
- 修改内容：公共端每帧最多8个非阻塞回调，防诊断饿死Twist新鲜度；碰撞锥用精确球投影范围剔除不可能相交的像素，窄相仍为原二次交公式。候选安全角段可行时收回旧目标，固定终点速度考虑执行响应。新增direction_proposal_only接口，候选不再经过旧单相机速度限幅，最终完整运动认证唯一授权执行。第17轮改用实测速向及双tau响应预览，尝试解决虚拟方向先转、机体仍滞后的问题。探索可显式启用30秒停滞中止，标ABORTED_EXPLORATION_STALL而非到达/超时；最终默认0、仍完整240秒。
- 验证：第12轮统一回调修复后user_ego到达68.75s/jerk2.0516，新版69.8667s/jerk2.6148；新版最小净距.1472m、停车.2167s。第13轮退化至81.9667s；第14–16轮均240秒超时，全部保留。真实停车审计显示机体包络已知，但向前认证长度为0，部分后向只有厘米级可认证段。7+16个失败快照重放一致。精确投影与穷举随机500点×4半径×2内参逐射线对照及原固定夹具通过；完整CTest17/17通过（含协议首4例），追加探索中止后协议5/5通过。第17轮运行中，未完成。
- 更正：第14/15轮传入native_points接口时，当前观测此前已清空原始点指针，实际仍使用保守缩图，不能记为原始点方案实测。第16轮修复指针保留并打印真实点数，确认原始点实际启用，但计算变慢且仍停在相近位置；第17轮恢复保守缩图候选。原始点只用于候选试验，安全证据一直是保守深度、全部新鲜点矛盾撤销与运动认证。
- 影响与边界：旧版源码、地图、速度/动力学、.48/.58m尺寸、未知拒绝及计算截止不变。候选方向/完整证明分工属于工程扩展，不能称论文原样实现。失败样本的低全程jerk受长时间静止影响，不能据此宣称更平滑。
- 回滚/备份：沿用19:29备份与各轮参数/二进制SHA；公共执行端源码SHA从第15轮起保存；没有提交推送。
- 后续事项：继续验证状态匹配、冻结有效版本后做全量回归及各5轮公平统计；若尚未胜出必须如实说明。


### 2026-09-29 20:45 — [EGO1P1] 深度建议加完整运动认证；首次全程到达，性能仍在优化

- 状态：实施中；未完成最终五轮对照，尚不能宣称优于user_ego。
- 目的：解决原完整角域构造反复超时/停车，同时保持三维包络与制动认证。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：paper_guidance.hpp/cpp、paper_replay.cpp、depth_angular_core.hpp/cpp、depth_angular_controller_node.cpp、主launch、motion_consistency/intent_response测试、Isaac运行器、benchmark统计及协议。
- 修改内容：沿用旧版深度调和场生成候选，再由新版完整观测空间认证实际执行及制动全过程；增加矢量加速度/jerk整形，发布覆写同步状态。观测联合细分3→5层以减少数值误拒，必要端点/视锥AABB剔除保持保守性，搜索限12候选/周期。V11(EGOPAPRB)保存候选与加速度状态。96×72试验后准备64×48折中；安全可回正时取消旧目标滞留。发现公共仿真每帧单次spin_once可能让新版诊断消息挤占Twist新鲜度回调，改为统一每帧最多8次非阻塞处理，三版最终都采用相同修复。
- 验证：iteration3–8均240秒超时；iteration9首次安全到达71.483秒、净距.2122m、停车.167秒、jerk RMS9.7245，仍慢于user_ego首测68.733秒。iteration10放宽候选采样且缩小候选余量后再次超时，已撤销该配置；iteration11保守96×72加矢量整形安全到达73.55秒、净距.1347m、jerk4.9702，路径137.459m仍偏长。完成轮的离线完整扫掠均未发现相交。联合细分改动后CTest16/16通过；最新混合候选/公共回调改动尚待完整回归，不能沿用旧通过结论。
- 影响与边界：机体.48m、完整包络.58m、未知拒绝、四相机、80ms计算截止、速度2m/s及公共动力学不放松。混合候选与回正属于工程扩展，不是论文原公式逐项不变。前11轮均为探索数据，含不同控制配置和早期公共回调缺陷，不作为最终均值。旧版源码未修改；所有失败原始数据保留。
- 回滚/备份：沿用19:29整包备份；benchmark目录保存协议、每轮实际参数/可执行SHA及部分中间二进制，未提交或推送。
- 后续事项：修复后重新比较，继续优化并冻结版本，执行统一五轮、全量回归、回放及安全审计。


### 2026-09-29 20:00 — [EGO1P1] 起终点对照首测失败，继续迭代（阶段记录）

- 状态：实施中，尚未达到优于两版的目标；不作为最终验收。
- 目的：固定同地图起终点，查明旧版与新版的实际性能差距。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：主运行Shell/Isaac运行器、新增`navigation_benchmark.py`、`navigation_benchmark.launch.py`、`tools/run_navigation_benchmark.py`、`tools/analyze_navigation_benchmark.py`、paper_guidance.hpp/cpp、paper_replay.cpp、controller_node、主launch和motion_consistency/intent_response回归；协议及原始证据在`performance/navigation_benchmark_20260929/`。
- 修改内容：三版单独构建，统一4倍Cloud、起点(-64,-11.2,2.8)/终点(64,11.2,2.8)、2m/s、.48m机体、.22s响应/1.2加减速和到达判据；建立JSON/CSV与完整扫掠离线统计。新增响应预览和命令角速度限制；补全8m到1cm之间被漏掉的前视尺度；端点必要检查减少无效认证；修复静止重复认证不一致，静止允许从选出的安全目标重新初始化。完整走廊与实际制动均可证明时才使用直达参考。正在修正短期状态域与长期目标距离绑在一起造成的过晚绕障。
- 验证：三版构建成功；首轮user_ego安全到达68.733仿真秒/65.586墙钟秒，路径131.933m，机体扫掠重叠0、最小净距.0752m；EGO1P0和初始EGO1P1均240秒超时，有输入停车228.23/218.67秒。iteration1/2也超时，全部失败保留。响应预览空旷90°测试由10.98秒到1.42秒，180°为.96秒。最初全CTest14/16：静止重复认证及回放版本断言两项失败，修复后相关三项回归通过；尚未做最终完整回归和5轮最终统计。统计工具首运行NumPy int64 JSON序列化失败，已转原生整数并重跑成功。
- 影响与边界：旧算法源码不修改；无人机仍执行一条三维规划矢量；未知拒绝、.58m认证包络和80ms截止时间保留。调参试跑期间发生过并行构建/测试，因此探索轮墙钟数据不能当作最终公平性能成绩；最终轮应在空闲计算资源下重启运行。V8增加响应预览/认证直达策略并兼容V3–V7读取，仅同构建承诺决策重放一致。新增策略是工程扩展，不能宣称论文公式逐项不变。
- 回滚/备份：`备份/EGO1P1_before_navigation_benchmark_20260929_192938.tar.gz`；三个项目初始源码SHA清单和优化前可执行文件已存benchmark目录；保留此前未提交改动，未推送。
- 后续事项：继续优化提前避障及正则域边界停车，完成真实重复对照后如实报告是否胜出。


### 2026-09-29 — [EGO1P1] 三代算法固定起终点公平对照与迭代优化（实施中）

- 状态：实施中，未得出性能优劣结论。
- 目的：按用户要求固定同一地图、起终点，多次测量user_ego、EGO1P0和EGO1P1的到达时间与稳定性；若新算法较差继续分析优化。
- 项目路径：`/home/starry/isaac-data/EGO1P1`；旧基线读取`/home/starry/isaac-data/EGO1P0`与`/home/starry/isaac-data/user_ego/Fov-gvf`。
- 涉及文件：EGO1P1运行器/主入口、独立benchmark launch与协议/统计工具、后续控制优化、WORK_LOG及统一HISTORY。
- 修改内容：拟统一4倍Cloud地图、起点(-64,-11.2,2.8)、终点(64,11.2,2.8)、2m/s上限、0.48m实际机体、tau=.22/加减速1.2执行模型、统一目标输入/偏航和到达判据；原算法源代码快照留存，基线不参与调优。
- 验证：已读项目约束、控制及运行脚本；尚未运行新对照。user_ego无Git元数据，不能以Git状态代替源码SHA清单；EGO1P0和EGO1P1已有修改均保留。
- 影响与边界：只用地图几何验证起终点/离线安全和原有固定起始自由球，不给在线导航提供全图路线；失败、碰撞保护、超时计入结果，不把超时当成功平均值。不预先承诺一定胜出。
- 回滚/备份：见`EGO1P1/performance/navigation_benchmark_20260929/backup.txt`及三份初始源码SHA清单。
- 后续事项：建立协议、构建三个算法、初测、诊断和迭代、重复验收与平均时间报告。


### 2026-09-29 19:24 — [EGO1P1] 完成方向一致性与速度整形；限定验收通过，停顿未完全解决

- 状态：本轮代码和限定验收完成；全程平滑、任意状态持续可控、大角度低延迟及严格50Hz仍未通过。本条补充18:52实施中记录。
- 目的：修复停车后背离摇杆超过90°持续行驶与速度反复突变，保留完整安全认证。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：`src/pc_gvf/include/pc_gvf/paper_guidance.hpp`、`src/pc_gvf/src/paper_guidance.cpp`、`src/pc_gvf/src/depth_angular_controller_node.cpp`、`src/pc_gvf/src/paper_replay.cpp`、`src/pc_gvf/tools/paper_replay.cpp`、`src/pc_gvf/test/cpp/{motion_consistency_check,paper_guidance_check,intent_response_check}.cpp`、`src/pc_gvf/CMakeLists.txt`、`src/pc_gvf/launch/isaac_cloud_navigation.launch.py`、`tools/analyze_motion_consistency.py`、README、版本说明、PAPER_IMPLEMENTATION、MOTION_CONSISTENCY_ACCEPTANCE、WORK_LOG、`performance/motion_consistency_20260929/`及HISTORY三份状态/日志文档。
- 修改内容：取消90°轮转至后方的无进展搜索；最终虚拟图140°×140°，移动仍以实测速向居中，未采用实施中提到的25°偏置。主入口开启正向目标/最终命令约束，反向实测速先制动重设；摇杆目标及整条角段认证可行时INTENT_DIRECT收回旧绕障偏向，否则调和场/反馈。正则流盒失效先重设；锚点用解析J避免差分越界误拒绝。正常非零幅值增减限1.2m/s²，安全速度细化后完整认证；连续选择角步，失败/超时零输出同步回核心。V6保存新策略，离线audit支持120方向认证前缀检查。
- 验证：主入口最终三包构建成功；CTest16/16，平台15/15，Python AST和git diff --check通过；两轮84秒同输入Cloud持续逆向（排除改向制动窗口）均0，采样逆向命令0；意图有效位移旧33.68→41.36/45.11m；诊断大跳变71→30/20次，P95 0.378→0.120/0.100m/s；全机体扫掠/外部保护均0，最小间距0.1717/0.1339m；21帧V6重放一致。停车旧7.70→9.73/5.87秒，最长1.50/1.03秒，不能声称稳定减少。发布43.55/44.43Hz；空旷90°响应仍10.98秒，180°反向0.96秒。未做真实手柄/实物飞行验收。
- 失败记录：25°偏置导致空旷转向失败，删除；首次CTest两项NumPy/SciPy ABI收集失败，使用既有PYTHONNOUSERSITE=1解决；cloud4/6/7有输入停车38.75/16.22/51.02秒，均保留；停车帧审计揭示可认证前下方60°方向被旧虚拟垂直域遗漏，扩大候选域后继续验证；新增0.1mm几何余量用例受保守分辨率拒绝，改为3mm且仍禁止直前方后通过，未降低认证要求。详见验收报告与原始日志。
- 影响与边界：仍单一规划三维方向×标量速度；四相机、0.48m机体/0.58m总包络、未知拒绝、观测时效及80ms计算时限不变。半球约束和安全直达捕获是遥操作工程扩展，不是论文原式6/17的逐帧原样复现；可能拒绝必须先反向的路线。紧急零指令最大跳变仍约1m/s，不是严格jerk受限控制。EGO1P0未修改，未提交/推送。
- 回滚/备份：`/home/starry/isaac-data/备份/EGO1P1_before_intent_motion_20260929_184710.tar.gz`；独立差异及最终SHA256清单在本轮performance目录。保留原有未提交改动，按本轮差异恢复后重新构建。
- 后续事项：改善正则域边界短停、计算时延与实测角步/执行响应耦合，并补真实手柄联调；当前不宣称任意环境无停顿。


### 2026-09-29 18:52 — [EGO1P1] 修复背离摇杆的局部搜索与速度突变（实施中）

- 状态：实施中，未完成验收。
- 目的：按用户要求定位停车后超过90度持续偏航及速度突变。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：paper_guidance头/实现、控制节点、重放V6、launch、CMake及motion_consistency_check测试；证据`performance/motion_consistency_20260929/`；WORK_LOG/HISTORY。
- 修改内容：去掉停车后逐次转90度的无进展搜索；虚拟图在保留实测速向的前提下朝摇杆偏转，主入口增加意图前半球目标/输出约束，反向实测速先制动再按新意图起步。对可行正则状态原地重建流盒以恢复反馈；正常速度增加受标量加速度约束，安全失败时细查可接受速度，最终矢量完整认证。实际发布零命令同步到下一周期，避免计算成功但被看门狗丢弃的指令成为旧方向/速度。新策略开关进入V6重放。
- 验证：已读用户18:35真实日志，约34.47Hz，最大callback325.75ms且频繁TRACKING/COMPUTE_DEADLINE/OUTSIDE_FLOW_BOX；上一轮Cloud轨迹相对输入超过90度运动约12.73秒、最长4.98秒、指令最大跳变1m/s。当前正在构建，未宣称测试或运行通过。
- 影响与边界：属于遥控意图约束的工程扩展，不是论文原式6的无限制所有方向选择；无显式回退指令时不自动反向逃逸。未知、传感器、0.58m包络和完整制动认证不放宽，仍单规划方向乘标量速度。
- 回滚/备份：`/home/starry/isaac-data/备份/EGO1P1_before_intent_motion_20260929_184710.tar.gz`；用户原日志/快照已复制保存。
- 后续事项：完成针对性/全套回归及同输入Cloud对照，验证偏航、速度变化、停顿与安全指标。


### 2026-09-29 18:18 — [EGO1P1] 完成累计改向与水源初始化修复；新增方向响应验收

- 状态：本轮修复与限定验收完成；大角度低延迟、全场景摇杆方向跟随及严格50Hz仍未通过。
- 目的：解决深度刷新吞掉慢改向累计量，并修复本轮方向测试发现的源网格取整漂移/源边界反向初始化。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：`src/pc_gvf/include/pc_gvf/paper_guidance.hpp`；`src/pc_gvf/src/{paper_guidance,paper_replay,depth_angular_controller_node}.cpp`；`src/pc_gvf/tools/paper_replay.cpp`；CMake、launch；`src/pc_gvf/test/cpp/{intent_response_check,paper_guidance_check,paper_closed_loop_check}.cpp`；`src/pc_gvf/test/fixtures/paper/isaac_intent_response_trace.json`；采样脚本；`tools/{analyze_intent_response,verify_navigation_replays}.py`；README、版本、论文说明、当前/历史验收提示、WORK_LOG；`performance/intent_fix_20260929/`；HISTORY/README、FOV_GVF_FAMILY、CHANGELOG。
- 修改内容：独立参考意图，0.05rad累计变化立即重建/禁止旧参考；同一新鲜深度的小目标更新允许按100ms周期进行。世界源方向连续保存，源势边界先短步初始化后规则反馈。新增端到端方向字段，V5状态及事件重放；旧V3/V4仅迁移读取，不伪称恢复原文件未保存的参考基准。阈值范围校验，默认速度/转向/安全参数不变。
- 验证：最终构建成功，完整CTest15/15、平台15/15；水平/竖直1度/步至20度各6次重设（旧0次），微抖/幅值/松手/同深度更新、第一步不背离目标、水源不漂移、累计量重放通过。空旷动态90/180度分别12.22/28.40秒进入10度内，末尾趋近0；障碍/扰动/可行场变化闭环回正≤10度全部通过。原Cloud84.017秒，慢扫误差中位1.310度，路径56.314m，有输入停车7.700秒/最长1.067秒；0.48m完整扫掠重叠0、外部保护0、最小间隙0.1144m。9个V5真实快照及改向事件一致，V3/V4读取成功。Python语法/主脚本语法/git diff检查通过。
- 失败与限制：首次缺Eigen Geometry导致链接失败；抖动夹具Eigen临时表达式导致误零；早期90度反向/初始化停滞，继续修复。最初8秒大转向指标低于现有角步长+tau响应能力，保留失败并改为明确25/45秒有界检查，同时报告实际迟缓；52秒夹具飞出30m自由球后安全停车，扩大测试自由球至100m，仅测试生效。build7旧源区延续假设/过宽初始化导致2项回归失败，build8收紧源势边界并先进入正则场再检验延续，原30次反馈门槛保留。平台首轮缺安装环境收集失败，加载后通过。原Cloud+Y18秒阶段没有达到10度跟随，不能记为通过；目标受限且实际跟踪仍迟缓，回正阶段遇新障碍也再次偏转。约39.44Hz、仍有超时和短停；未验收实体手柄、实飞、全域证明。
- 影响与边界：仅EGO1P1/HISTORY；不改变0.48/0.58m机体/包络、四相机、场景、未知拒绝或完整制动；输出仍为单三维规划矢量，无新增逃逸/分轴控制。build10只加强测试，Cloud9对应同一运行算法。本次仿真退出0，无本任务运行进程残留，未提交推送。
- 回滚/备份：`/home/starry/isaac-data/备份/EGO1P1_before_intent_20260929_175528.tar.gz`；源码清单、最终重放程序与各阶段日志位于`performance/intent_fix_20260929/`。恢复后通过原主构建脚本重建。
- 后续事项：实体手柄现场验证；如继续要求快速大角度转弯，需单独评估角步长与真实速度响应模型的匹配，不能只提高水流刷新频率；继续优化源/流盒切换和最坏计算周期。


### 2026-09-29 18:00 — [EGO1P1] 累计改向参考重设修复（实施中）

- 状态：实施中，未完成验收。
- 目的：按用户要求完善摇杆改变方向时的水流更新和参考线重设。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：`src/pc_gvf/include/pc_gvf/paper_guidance.hpp`、`src/pc_gvf/src/{paper_guidance,paper_replay,depth_angular_controller_node}.cpp`、launch、CMake、`src/pc_gvf/test/cpp/intent_response_check.cpp`、改向输入夹具、`scripts/isaac/run_fov_gvf_navigation.py`；证据`performance/intent_fix_20260929/`。
- 修改内容：参考线意图独立于上次构场意图，0.05rad阈值相对当前参考累计；有效改向立即重建且禁止旧参考延续，同一新鲜深度可响应周期性小改向。重放V5保存新增状态，旧V3/V4以原上次构场意图作初始基准。新增意图/目标/参考/命令与重设诊断字段。
- 验证：首次主入口build1失败（新增cross计算缺少Eigen/Geometry定义导致链接错误），已补头文件并运行build2；核心、闭环和Isaac验收尚未完成。
- 影响与边界：仅EGO1P1与HISTORY；安全包络、传感器、未知拒绝及单矢量输出保持原配置。未提交推送。
- 回滚/备份：`/home/starry/isaac-data/备份/EGO1P1_before_intent_20260929_175528.tar.gz`，含本次之前未提交源码/脚本/说明。
- 后续事项：完成回归、慢改向/大改向/回正验收并记录所有失败及边界。


### 2026-09-29 17:44 — [EGO1P1] 核查摇杆改向：确认慢改向可漏掉参考线重设

- 状态：仅检查；诊断完成，控制源码与运行配置未修改。
- 目的：核对用户所问“摇杆改向后水流目标更新并从当前状态重设参考线”是否充分实现。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：`performance/intent_audit_20260929/{README.md,probe.cpp,probe.csv,compile.log}`、`WORK_LOG.md`、`HISTORY/CHANGELOG.md`。
- 修改内容：仅保存诊断与结论。确认明显改向会立即重建并禁止旧参考延续；但0.05rad阈值相对每次构场更新的previous_intent_比较，慢改向可能一直被判为不变。实时目标仍按最新意图计算，不能将漏重设等同于目标完全不更新。
- 验证：独立g++链接现有核心，编译与诊断退出0；初始化后1度/步至20度的20次更新均continued=1且未触发COMMAND_CHANGE，之后20→35度触发重设。空旷人工夹具前20步目标与输出正确跟随，故未证明实际偏航由此单独造成。已核对论文III.E式23–24和现有测试：明显改向事件有覆盖，慢改向与方向收敛时间/误差验收缺失。未运行Isaac、ROS、实体手柄、完整构建或全套回归。
- 失败与限制：默认sandbox命令失败，升级执行后可读；旧/tmp论文文本与主构建目录不存在，不能复用旧程序，改为重新提取与临时独立诊断。夹具固定位置、人工自由种子且非动力学闭环，仅支持事件逻辑结论，不代表真实飞行。飞行时局部角域跟随实测速向，侧向/反向意图可能先投影到域内目标，属于另一个响应限制。
- 影响与边界：仅新增检查证据和双重记录；未变更控制、安全、场景、入口、EGO1P0或其它项目，未提交推送。前次恢复用例通过不等于摇杆方向跟随已完整验收。
- 回滚/备份：无需源码回滚；本次新增记录可按目录定位，原有记录完整保留。
- 后续事项：分离上次构场意图与参考线对应意图，保留慢改向累计量；补充慢扫、90/180度改向、绕障后回正的方向误差与响应时间验收。


> 新记录一律追加在本说明下方、旧记录上方。  
> 详细格式见 `RECORDING_RULES.md`。

### 2026-09-29 13:18 — [ausim_biped / ausim_rl] 复现松杆踏步并远程启动5000轮静止微调

- 状态：诊断和训练启动验证完成；远程训练运行中，策略改善尚未验收。
- 目的：按用户授权连接指定机器查找配置并重新训练；用户进一步要求根据LB运动策略摇杆回中后间歇踏步的原因决定训练方式，预算参考原训练。
- 项目路径：本地`/home/starry/isaac-data/ausimlab/sim2sim/vendor/ausim2-main/ausim_biped`；远端`ubuntu5090@192.168.31.112:/home/ubuntu5090/cwl/ausim_rl`。
- 涉及文件：本地`validation/20260929_retraining/`（诊断源码/差异/构建、12组仿真CSV/JSON及汇总、远端配置和日志归档）、WORK_LOG、本总账；远端`task/hiking/mdp/rewards.py`、`task/hiking/configs/rewards.py`、`tests/test_stand_still_velocity.py`、`docs/standing_finetune_20260929.md`、WORK_LOG和`runs/remote_jobs/20260929_130740_stationary_finetune/`及新训练run。
- 修改内容：通过独立C++副本按时间清零指令、只读mj_step采样接触，正式本地控制器/二进制不改。新策略稳定初态零速可静止，但前进0.2秒后清零，在两秒过渡后到20秒仍47次交替落脚；旧策略同条件0次；新转向停车43次、旧0次。确认与停车状态有关，不能仅以finite/upright判断静止成功。依据当前静止奖励只约束姿态、缺少零速运动惩罚，选择原model_30000针对性续训：standing概率.05→.20、重采样8–12→4–8秒、静止项权重-.3→-.6、新增可选关节速度平方和系数.1，默认0保持旧配置；移动/转向超过阈值时新项为0。网络、观测、相机、动作和关节契约保持。
- 验证：远端依赖IsaacSim6.0.1.0/IsaacLab6.1.17/Torch2.10.0+cu128与资产检查通过；checkpoint SHA与用户文件相同。旧训练TensorBoard跨度48.7236小时；原配置8环境3轮恢复通过、新奖励4测试通过、候选配置8环境3轮恢复并保存model_30003。正式从原30000开始，2048环境、追加5000轮、每1000轮保存、12小时watchdog；13:13启动，验证到30015/35000，损失有限、traceback0、显存16306MiB、GPU89%、约6秒/轮。正式run为`/home/ubuntu5090/cwl/ausim_rl/runs/hiking/20260929_131316_quiet_stand_finetune_5000_20260929_save_interval-1000_from20260914_173101`。关闭SSH前13:18:43复核到30043/35000，监督进程存活、traceback0，剩余日志ETA约7.42小时；后台继续。本地所有22个已部署策略文件哈希保持，远端归档SHA校验通过。
- 失败与处理：两次候选整体params字典CLI覆盖在typed配置恢复阶段失败（command_name缺失）；IsaacLab直接参数层用ast.literal_eval将裸键映射保留为字符串，而恢复层Hydra解析为字典。未修改IsaacLab，改用独立复制候选env.yaml后恢复通过；两个失败日志保留。旧/新稳定初态及3秒停车对照未复现踏步，继续覆盖早停/转向后才复现；未把未复现或退出0写成问题不存在。
- 影响与边界：只强化新parkour的低命令静止目标；不从零训练，不动本地stand或runtime切换，不部署未验收候选；真机未连接。正式训练尚未完成，未证明新模型已消除踏步或保持上楼能力。SSH密码未写入工程/日志。未升级依赖或提交推送。
- 回滚/备份：远端作业backup/rewards.py与rewards_cfg.py保存原源码；原训练checkpoint和params未覆盖，resume_source保存独立候选配置并链接原checkpoint；停止脚本核对监督进程身份。诊断文件均新增，正式本地模型保持原哈希；更早ausim_biped备份保留。
- 后续事项：完成训练后导出独立候选包，以本轮相同早停/相位/转向停车、30秒静止及既有8秒上楼回归验收，再决定是否替换本地策略；当前后台任务进度以远端status.json/train.log为准。

### 2026-09-28 22:28 — [EGO1P1] 完成连续通道、近场观测保留与停车重放；限定恢复用例通过

- 状态：本轮方案实施与验收完成；定义的改向/长待机恢复用例通过，严格50Hz及任意状态持续可控未通过。补充前述实施中条目，失败证据保留。
- 目的：按用户批准的论文接轨方案解决已知空间在记录/查询中被裁掉、短前视被固定距离门槛否决及停车不可重放的问题。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：`src/pc_gvf/include/pc_gvf/paper_guidance.hpp`；`src/pc_gvf/src/{paper_guidance,paper_replay,depth_angular_controller_node}.cpp`；`src/pc_gvf/tools/paper_replay.cpp`；`src/pc_gvf/test/cpp/continuous_recovery_check.cpp`；CMake、launch；`scripts/run_isaac_fov_gvf_navigation.sh`、`scripts/isaac/run_fov_gvf_navigation.py`；`tools/verify_navigation_replays.py`；`{README,EGO1P1_VERSION,PAPER_IMPLEMENTATION,ENVELOPE_ACCEPTANCE,CONTINUOUS_ACCEPTANCE,WORK_LOG}.md`；`performance/continuous_20260928/`；HISTORY/{README,FOV_GVF_FAMILY,PROJECT_INDEX,CHANGELOG}.md。
- 修改内容：最多256个完整认证实测胶囊段、128个实际包络进入后保留原中心/半径的运动证明球；凸体/收缩证据中心线区间并集及有界细分证明连续扫掠，曲段合并扣除偏离误差。原始障碍命中空间索引逐点撤销，时间回退清空。32个深度关键帧改为按近场覆盖贡献淘汰；在已启用的静态保留且历史不确定性增长0的配置下，来源深度与到达几何统一静态保留，不再单独60秒过期，非静态仍按配置过期，0.3秒新鲜深度门禁保留。前视0.10m改作期望下限，实际下限由实测速率制动距离及5mm数值保留量确定，式22也使用同一保留量；0.58m物理/测量/执行包络不变。逐像素只做最多五级阈值认证，最终输出方向再精查；构场失败且有认证方向时虚拟图加密，真实深度不补全。新增细分构场原因、CSV字段、每运行最近16帧快照及确定性单步重放。输出仍为同一三维规划矢量，没有附加分轴控制。
- 验证：最终构建成功；CTest14/14、平台pytest15/15、真实ROS拒绝契约通过；36个Python AST、两个主Shell语法、git diff --check通过。最终94秒相同输入两轮停车6.93/19.30秒、最长1.53/3.48秒、累计53.00/34.54m，各5段输入均有位移（前一轮同类默认25.18秒/最长12秒）；67秒松手后10秒输入净位移7.946m（前一轮0）；2m/s输入沿X前进10.619m达到原≥8m标准，最高1.99977m/s；关闭起点认证保持零位移/零速度。最终5组0.48m独立扫掠球重叠0、外部保护0，运动组最小间隙0.109m。最终33个真实状态快照逐值重放一致，记录与可执行程序/源码哈希保留。
- 失败与限制：build1声明不匹配构建失败后修正；build5过深细分导致超时，停车66.07秒；build6紧通道接缝回归失败，build7解析区间并集修正；build8一次停车11.53秒，但build9复测46.42秒/最长12秒，其停车位置到达球仅比认证包络多0.295mm，故继续处理来源观测丢失。build11额外3cm终点余量停车34.72秒/最长11.95秒，默认关闭该实验约束。build13夹具绕过step历史接入导致失败，build14修正并通过；算法与build12一致。perf采样被系统权限限制，未更改系统权限；重放最初路径写错一次，修正隔离安装路径后最终验证成功。最终活跃运行约35.76–48.69Hz，仍有超过80ms的周期与短暂停车；不声明严格50Hz、全场景无停车、全域ISS或实物实验通过。原16:15手柄运行没有原始快照，本轮不能宣称逐帧重放其截图位置。
- 影响与边界：仅EGO1P1及HISTORY/本任务备份；场景、四相机、真实机体半径0.48m、统一包络0.58m、完整制动检查、未知拒绝不变。静态历史保留是工程前提，不推广为任意动态环境保证；保留球形机体，未实现可选的姿态相关非球形包络。未修改EGO1P0/其他工程，未提交或推送Git；未进行实体手柄/真实飞行验收。
- 回滚/备份：`/home/starry/isaac-data/备份/EGO1P1_before_continuous_20260928.tar.gz`；阶段日志、代表性源码/重放程序及最终清单在`performance/continuous_20260928/`。回滚需恢复对应源码后使用原构建主入口。
- 后续事项：真实手柄持续运行复核、扩大不同轨迹/场景样本，继续优化最坏计算周期；不能把有限用例改善当作任意位置必然可通行。

### 2026-09-28 21:47 — [ausim_biped] 模块内保存新模型契约并完成本地北通手柄入口

- 状态：本轮实现与自动验证完成；完整人工手柄操作待现场复核，旧两步距离门槛未通过。
- 目的：按用户要求将当前新模型与适配结果落实到原 C++ ausim_biped，可从模块内脚本直接运行北通手柄控制。
- 项目路径：`/home/starry/isaac-data/ausimlab/sim2sim/vendor/ausim2-main/ausim_biped`。
- 涉及文件：`CMakeLists.txt`、`src/control/g1_policy_contract.{hpp,cpp}`、`src/control/g1_onboard_policy.{hpp,cpp}`、`tests/g1_policy_contract_test.cpp`、`tests/data/`、`policies/`、`build.sh`、`run.sh`、`run_gamepad.sh`、`scripts/runtime_env.sh`、README/CURRENT_IMPLEMENTATION/INTEGRATION_PLAN/WORK_LOG、`validation/20260928/`；父目录 `run_g1_gamepad.sh` 转发脚本；本总账。
- 修改内容：本模块保存原 stand 与新 model_30000 parkour 的原始 actor/data/depth encoder、完整对应 env/agent/resolved_env/contract、checkpoint、动作参考及源码快照。此前实测新模型兼任零深度stand失败，因此当前可运行组合明确采用原stand+新parkour。新增每模型contract名称映射，解决25/29索引变化；位置/速度/上一动作的每帧及输出分别转换，跨策略缓存保持统一旧顺序。校验动作维度/周期/default/offset/scale/action_clip，ONNX保持原始字节。构建输出移至模块build/bin，复用父仓库资产与MuJoCo、已有local_deps及系统ROS；运行时不依赖独立SIM2SIM实现。
- 验证：`./format.sh`成功且无无关格式变化；`./build.sh`成功；`ctest --test-dir build --output-on-failure` 8/8通过，包含独立ONNX参考四次时序切换232值、容差1e-5。`./run.sh --headless --duration 30 --policy stand`退出0，root_z=.8091m；`./run.sh --headless --duration 8 --policy parkour --cmd-forward .5`退出0，真实深度/自由基座/无辅助，终点(3.1546,.3471,1.2364)m，upright=true。最终Shell语法、`./run_gamepad.sh --check`通过；22个保存文件SHA-256全部匹配。隔离ROS域81实际打开本机北通js0/viewer/手柄节点，未扶直stand拒绝、提前parkour拒绝、急停成功且锁存。记录均位于validation/20260928。
- 失败与修复：`--two-step-demo`退出1；两次落脚2.165/2.51s且回stand直立，但净前进.1411m未达旧.20m门槛，未改低门槛。初次手柄退出清理因后台SIGINT未生效超时，强制停止本次验证进程；修复为独立进程组和有界TERM/KILL，复测launcher退出130、无验证子进程残留。失败与复测日志均保留。
- 影响与边界：保留200Hz物理/PD、50Hz推理、仰躺ColdStart→人工扶直→RB stand→2仿真秒→LB parkour。未运行完整人工扶直/实体按键/偏航验收；未验证长期、下楼、任意地形或深度逐像素等价。远端manifest仍为export_candidate，未改真机就绪标记。未修改独立SIM2SIM源码、远端训练源码、机器人场景或真机DDS链路；未提交推送。
- 回滚/备份：`/home/starry/isaac-data/备份/ausim_biped_before_local_gamepad_20260928_212831`，含修改前整个模块和父手柄脚本；可保留当前目录后从该备份恢复两者。更早原模型备份仍保留。
- 后续事项：用户用模块内`./run_gamepad.sh`进行人工扶直、实体RB/LB与摇杆现场复核；若要求同一新模型兼任stand，需另行解决零深度站立契约，当前未将其伪报为通过。

### 2026-09-28 21:34 — [EGO1P1] 连续通道认证、低速恢复与失败帧重放（实施中）

- 状态：实施中，当前仅构建和部分回归已完成，尚未完成仿真验收。
- 目的：按用户批准方案减少已知空间被离散记录/保守查询丢失造成的停车，保持论文单三维规划矢量。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：`src/pc_gvf/include/pc_gvf/paper_guidance.hpp`、`src/pc_gvf/src/{paper_guidance,paper_replay,depth_angular_controller_node}.cpp`、`src/pc_gvf/tools/paper_replay.cpp`、`src/pc_gvf/test/cpp/continuous_recovery_check.cpp`、CMake、launch、主运行脚本、`tools/verify_navigation_replays.py`；证据在`performance/continuous_20260928/`。
- 修改内容：保存完整认证的实测连续胶囊通道并保留障碍撤销；按空间/视角冗余淘汰深度帧；凸证据精确包含和有界细分；前视下限与速度残余距离统一使用显式5mm认证分辨率（包络误差仍计入0.58m）；几何可行但角域构建失败时2倍方向图细化；细分构建失败原因，默认保留最近16个停车状态快照，支持同版本离线确定性重放。
- 验证：build1接口声明不一致失败，修正后build2/3/4构建成功；build3有缩进警告待清理；新增continuous_recovery_check通过，完整CTest进行中。未完成仿真/碰撞/性能验收，不宣称停车问题已解决。
- 影响与边界：仅EGO1P1及HISTORY。机体、场景、传感器、完整运动制动检查保留；不加入未知自由空间，不新增分轴控制；当前连续证据依赖原静态场景前提。未提交推送Git。
- 回滚/备份：`/home/starry/isaac-data/备份/EGO1P1_before_continuous_20260928.tar.gz`，含本任务开始前已有未提交工作。
- 后续事项：完成核心/ROS/原场景重放、长待机与未知拒绝验收，根据真实失败修正后更新最终结论。

### 2026-09-28 21:17 — [Hiking Data&Model] SSH 找回对应配置并确认新策略关节顺序差异

- 状态：配置定位与契约核对完成；诊断的原 stand→新 parkour 上楼通过；新模型兼任 stand 失败。
- 目的：按用户授权 SSH 访问训练机器，继续新模型控制契约匹配。
- 项目路径：远端 /home/ubuntu5090/cwl/ausim_rl；本地 `/home/starry/isaac-data/ausimlab/ausim-rl/runs/model_30000_remote_contract_20260928`。
- 涉及文件：完整远端 bundle 副本、verify_contract.py、contract_comparison.json、bundle_hash_verification.json、diagnostic_legacy_order/、三份闭环 JSON、REPORT.md；Data&Model README；HISTORY/CHANGELOG.md。
- 修改内容：远端只读查找与下载，未修改远端项目；同 run checkpoint 哈希为 f309ddca08f8200d7e0833268a4ac82ff29fda97866d236005b897c25d8c347e。新 contract 的 25/29 关节索引不同，按名称动作/default/PD相同；独立 ONNX 诊断副本加入输入历史与输出 Gather 映射。当前运行模型、env.yaml、C++源码和独立SIM2SIM正式包未改。
- 验证：15个bundle文件哈希匹配；远端run的env/agent与bundle同哈希；训练fixed input本地ONNX Runtime对拍最大误差2.98e-7，16组转换对拍误差0。无辅助真实深度仿真：原stand→适配新parkour在8.005s到(3.1546,0.3471,1.2364)、upright=true、退出0；适配新stand在5.005s倒地z=0.0801、退出1；两套适配新模型在8.005s倒地z=0.0472、退出1。未重新构建或做真机测试。
- 影响与边界：缺新配置问题已解除；关节顺序差异有实证，不能把新运动模型当当前零深度stand直接替代。诊断通过范围仅固定四级上楼，不代表完整部署就绪，bundle仍为export_candidate。
- 回滚/备份：原版模型备份仍保留；本轮所有转换副本位于独立审计目录，无运行参数需回滚。
- 后续事项：正式按每策略契约接入；若采用实证通过组合，应保留原stand并适配新parkour，不能全局改旧关节顺序。

### 2026-09-28 13:32 — [EGO1P1] 统一安全包络、校核真实机体并完成多轮余量对照；持续可控未通过

- 状态：本轮优化代码与验收完成；持续可控目标部分完成，长时改向/待机后恢复未通过。本条更新12:34实施中记录，保留中间失败。
- 目的：按用户批注统一运动/记录范围，按实际机体和误差核对附加余量，并对照停车与碰撞。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：`src/pc_gvf/include/pc_gvf/paper_guidance.hpp`、`src/pc_gvf/src/{paper_guidance,depth_angular_controller_node}.cpp`、`src/pc_gvf/launch/isaac_cloud_navigation.launch.py`、`src/pc_gvf/test/cpp/observed_space_check.cpp`、`src/pc_gvf/test/fixtures/paper/{isaac_envelope_recovery_trace,isaac_evidence_expiry_trace}.json`、`scripts/isaac/run_fov_gvf_navigation.py`、`tools/{calibrate_vehicle_envelope,calibrate_motion_discretization,analyze_envelope_trace}.py`、`{README,EGO1P1_VERSION,PAPER_IMPLEMENTATION,PAPER_ACCEPTANCE,ENVELOPE_ACCEPTANCE,WORK_LOG}.md`、`performance/envelope_20260928/`；同步HISTORY/{README,FOV_GVF_FAMILY,PROJECT_INDEX,CHANGELOG}.md。运行入口生成的普通性能记录保留。
- 修改内容：USD含桨外接半径0.4763707m，主入口/外部保护body_radius从0.25校正0.48m；安全/执行附加余量0.20/0.10→0.02/0.02m，深度0.03m及固定最大帧龄预算0.03m，共0.58m。15工况60Hz与1ms参考积分最大差0.0156668m，这是理想仿真有限样本而非实物误差界。统一当前位置、方向前缀、完整运动与到达记录的最低半径；不再额外要求10cm才能记录，只保留可独立证明的部分余量。记录松手制动后的实测点，最新点与15cm空间样本分开；完整制动预测证明只能在真实包络到达后接续，不能直接把未到达路径当自由。增加相邻已认证球根平面/球缺解析包含检查，修复粗分块的薄重叠误拒绝；未知月牙、端部与障碍撤销仍拒绝。最低前视1→0.10m，仍受实测速率制动需求约束；最后一次有界尝试显式落到安全下限，修复仅五次减半未实际到达下限的问题。原始命中用AABB筛选再精确检查；增加证据计数和可选CSV，诊断订阅仅在验收启用。
- 验证：主脚本build10三包成功；最终CTest13/13，平台pytest15/15，真实ROS节点未知/过期/松手拒绝探针通过。最终相同代码/输入/0.48m真实机体的94秒对照：宽总半径0.84m与默认0.58m，有输入停车59.98/25.18s（本次减少约58%）、最长13.17/12.00s、路程9.50/40.03m，独立0.48m全机体扫掠球最小间隙0.407/0.153m、重叠0、外部保护0。长待机组第二段10秒输入位移0，恢复未通过，且待机前已有NO_REGULAR_FIELD，不能单独归因于过期。2m/s/24秒前进12.641m，达到原≥8m标准；最大实测速率1.99976m/s、扫掠球间隙0.156m、保护0。禁用起点认证6秒位置/速度不变并拒绝未知。最终5组重叠及保护均0；默认改向/宽余量/待机组无UNOBSERVED_BODY_ENVELOPE或COMPUTE_DEADLINE转入。默认命令49.19Hz、最大间隔113.097ms，严格50Hz未通过。构建/测试/原始CSV/摘要/复现命令及源码哈希保留。
- 失败与比较边界：用户11:31原始日志为持续UNOBSERVED_BODY_ENVELOPE，11:28为NO_REGULAR_FIELD。旧0.25m机体基线同输入停车仅3.33s，未复现用户原始锁死，不能声称最终版全面优于旧版。build1仅统一范围、build3只保留0.4s证明、build4完整制动但1m前视、build5–7较小余量/部分证明均有长时停车；build8候选：窄/宽停车21.10/63.40s，2m/s前进7.660m低于8m未通过；build9窄/宽48.02/44.08s，并非余量越小每次都更好。完整原始结果保留。几何工具第一次工作目录/路径错误后移回项目tools，无第三方源码残留。Isaac退出仍有已有rosout context invalid告警，最终进程正常退出。
- 影响与边界：只修改EGO1P1及HISTORY；场景、相机、单三维规划速度链不变，新增未知及完整制动检查保留。当前余量适用于有明确前提的理想静态仿真，不是实物标定。长时连续可控、任意停止点恢复、严格50Hz及完整论文理论/实物验收仍未通过；未进行实体手柄交互。未修改EGO1P0/其他工程，未提交或推送Git。
- 回滚/备份：`/home/starry/isaac-data/备份/EGO1P1_before_envelope_optimization_20260928_123444`；`performance/envelope_20260928/source_stage9/`另保留解析两球查询前的源码。中间日志未删除，旧论文验收加日期说明。
- 后续事项：围绕失败帧的连续认证空间与狭窄可行角域做可重放诊断，继续处理NO_REGULAR_FIELD恢复；不能继续盲目缩小真实机体或取消未知拒绝。

### 2026-09-28 13:05 — [SVG 动画] 新增“孙悟空骑摩托车”单文件 HTML

- 状态：完成。
- 目的：按用户要求生成可直接打开、全部使用 SVG 绘制的孙悟空骑摩托车 2D 动画。
- 项目路径：`/home/starry/isaac-data`。
- 涉及文件：新增 `wukong-motorcycle.html`；更新 `HISTORY/CHANGELOG.md`。
- 修改内容：绘制金箍、猴脸、虎皮裙、猴尾、金箍棒、披风、复古摩托、落日、青山、祥云与公路；文字和交互控件也使用 SVG。内嵌 CSS 与 JavaScript，无图片、Canvas、外部字体、脚本或网络资源。统一 requestAnimationFrame 时钟驱动车轮、车身起伏、披风/尾巴/飘带、分层山景、道路和扬尘；支持暂停/继续、1×/2×/3×速度、重置及键盘操作；小屏重新构图，尊重系统减少动态效果设置，并在页面隐藏时停止帧更新。
- 验证：`node --check /tmp/wukong-animation-script.js` 通过；Python ElementTree 解析内联 SVG 通过，68 个 ID 无重复、29 个引用全部有效，无光栅图片/Canvas/外部资源。使用 `python3 -m http.server 8766 --bind 127.0.0.1 --directory /tmp/wukong-preview` 及 Codex 浏览器进行实际预览，检查桌面、390px 与 320px 布局；320px 时页面 scrollWidth=320，全部控件位于视口内。验证动画实际变化、暂停时车轮保持不变、重置后 rotate(0)、2×/3×选择状态以及 Enter/空格暂停与继续；浏览器 warn/error 日志为空。未在 Safari、Firefox 或真实手机上运行；减少动态效果分支未通过系统设置切换实测。
- 失败与限制：最初普通沙箱读取命令及一次日志 apply_patch 因 `mountinfo path is not absolute` 未执行，后续通过获准的提升权限命令完成；全工作区文件发现遇到既有受限目录后，改为针对根目录/HISTORY 的读取。浏览器直接导航 `file://` 被浏览器 URL 安全策略阻止，未绕过；上述运行验证使用已建立的本机 HTTP 预览，未声称完成浏览器直接文件打开测试。
- 影响与边界：只新增独立动画文件并补充历史记录，不修改机器人、仿真、算法或依赖环境；没有构建/安装步骤，无项目内既有 WORK_LOG 需要更新。
- 回滚/备份：文件为全新产物，无旧文件被覆盖；如需回滚，仅移除 `wukong-motorcycle.html` 并新增回滚记录，保留本历史条目。
- 后续事项：无。

### 2026-09-28 12:34 — [EGO1P1] 开始统一安全包络与到达证据，并按实际几何标定

- 状态：实施中。
- 目的：按用户批注要求统一运动/记录认证范围、核对真实机体、进行余量对照，解决持续拒绝运动。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：后续代码与验收另记；本条WORK_LOG.md及HISTORY/CHANGELOG.md。
- 修改内容：保存源码/配置/文档快照及用户两次卡住日志。只读USD发现螺旋桨几何最外缘约0.477m，旧0.25m碰撞半径不足；不能直接缩小机体。
- 验证：历史11:31运行持续UNOBSERVED_BODY_ENVELOPE，11:28运行NO_REGULAR_FIELD；当前未执行优化后测试。
- 影响与边界：仅EGO1P1与HISTORY；新增未知仍拒绝，沿用单三维矢量。
- 回滚/备份：`/home/starry/isaac-data/备份/EGO1P1_before_envelope_optimization_20260928_123444`。
- 后续事项：几何/误差标定、认证衔接、原参数和新参数对照、回归及最终记录。

### 2026-09-24 18:04 — [EGO1P1] 固定起点认证、论文自由域/反馈完善及实际绕障验收

- 状态：本轮实现与有界静态场景验收完成；完整论文复现仍部分完成（实际43–47Hz、理论全域条件/实物实验未验收）。本条更新15:55“实施中”状态，保留15:05严格停车失败记录。
- 目的：用户批准启动时验证固定起始自由邻域，随后依靠真实深度和已认证运动维护自由空间；按论文式1–31继续补齐工程实现并恢复正常运动，新增未知空间仍不可进入。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：`src/pc_gvf/include/pc_gvf/{paper_guidance,verified_start}.hpp`、`src/pc_gvf/src/{paper_guidance,verified_start,depth_angular_controller_node}.cpp`、`src/pc_gvf/{CMakeLists.txt,package.xml}`、`src/pc_gvf/launch/isaac_cloud_navigation.launch.py`、`src/pc_gvf/test/cpp/{paper_guidance_check,observed_space_check,paper_closed_loop_check}.cpp`、`src/pc_gvf/test/test_manual_control_math.py`、`src/pc_gvf/test/fixtures/paper/{isaac_verified_motion_trace,isaac_max_speed_trace}.json`、`scripts/isaac/{manual_control_math,run_fov_gvf_navigation}.py`、`scripts/run_isaac_fov_gvf_navigation.sh`、`src/pc_gvf_platforms/pc_gvf_platforms/command_bridge.py`及平台测试、`tools/{ros_vector_guidance_probe,validate_isaac_depth_contract,analyze_paper_isaac_run}.py`、`{README,EGO1P1_VERSION,PAPER_IMPLEMENTATION,PAPER_ACCEPTANCE,WORK_LOG}.md`、`performance/paper_completion_20260924/`；同步HISTORY/{README,FOV_GVF_FAMILY,PROJECT_INDEX,CHANGELOG}.md。
- 修改内容：控制器直接核验已知USD/occupancy的SHA-256并认证半径2.5m的单个固定世界坐标球；首个零位姿等待实际位姿，禁止运行中凭几何扩张。球/未知像素截断锥距离、胶囊覆盖、多视图八叉包含、连续实际方向认证和网格穿越检查取代过保守/不完整几何；正证书仅当帧复用。静态Cloud保留最长60s/最多32个深度关键帧及最多32个实测位置已认证到达球，真实原始像素障碍冲突撤销证据；不同相机乱序不误清历史，同路时间回退清空。通用模式非有限值仍未知，主入口明确采用已实测的Isaac正无穷无返回契约，只认证10m；修正半像素中心，NaN/0/-Inf未知。虚拟方向图不附带虚构深度；规则场采用24×18方向图/12×9粗场、最小1m可行前视、角速度16像素/s、最小100ms场更新、原分辨率掩码回退。参考按有序折线最近线段延续；增加有效跳变、2R界、J范数和冻结图内执行偏差诊断。所有输入模式统一tau=0.22s、加速度1.2m/s²执行模型，零指令恒减速到零，预测200ms延迟+200ms响应+完整制动。回调超过80ms拒绝非零结果，桥/执行端100ms超时发零。传感器独立回调组、最新帧队列；OpenMP4线程并行独立证据/方向检查、线程私有当帧缓存、等价平方距离球冲突检查提高性能；串行回退保留，导出OpenMP依赖。
- 验证：主脚本最终build33三包成功；`PYTHONNOUSERSITE=1 ctest --test-dir /tmp/fov_gvf_ego1p1_isaac_build/pc_gvf --output-on-failure` 13/13，平台pytest15/15；ROS真实节点探针通过无种子拒绝、过期深度/意图及松手停车。四路原始320×240捕获的19,163个+Inf像素，独立精确DDA在10m内真实几何命中0，工具和NPZ保留。九场景各500步独立闭环零碰撞：立柱终点x=9.27867、扰动x=9.24794、可行环境变化x=9.27453，分别75/297/72个TRACKING步；障碍侵入余量后停车是预期拒绝，不宣称动态到达。无反馈/无延续/单场消融执行，重置数167对7，原始chi不同坐标不能直接排序性能。最终实际Isaac四路90°相机：1m/s输入29s前进17.519m、2m/s输入24s前进19.608m，外部保护介入均0、COMPUTE_DEADLINE状态转入均0；实际指令分别46.97/43.37Hz（ROS时间），回调最大47.035/65.820ms，未满足所有20ms周期。三维输入/改向及t=3s横向速度扰动12s运行通过，t=10s松手后零命令，保护0；禁用起点认证6s保持(-64,-11.2,2.8)并UNOBSERVED_BODY_ENVELOPE。另保留同方法较慢实现两次16.419/16.676m重复和并行版16.551m结果。两主Shell语法、13个Python AST和git diff --check通过；闭环图已渲染并目视核对。
- 失败记录：初期零位姿认证拒绝、1.5–2.5m停滞、多球/原生高分辨率/抗锯齿试验不奏效，最终恢复单球、原相机和TAA；早期未加期限/匹配制动版本求解约3.109s、外部保护142次，明确失败。build18编译作用域错误，其后误跑旧二进制的方向图日志不作新代码证据，build19修复。CTest用户NumPy ABI与平台未source导入失败均保留，隔离/source后通过，未修改依赖版本。深度DDA早期错误像素/网格约定造成95/22个伪冲突，经实际约定修正为0，未筛除像素。自动审批拒绝可伪造ROS自由证书方案后改为本地文件SHA+几何验证，未创建证书消息。退出仍有rosout context invalid告警但节点正常退出。所有关键中间原始日志和说明保留于experiments/，旧验收/实现说明单独保存。
- 影响与边界：人工输入仍只是三维期望，执行一条规划矢量；没有XYZ分量合成、人工Z叠加或额外路径控制器。未增加相机或修改场景；历史/已到达证据仅针对静态Cloud前提，+Inf契约不能推广到未知真实设备。外部保护0只支持本轮轨迹未被阻断，不证明全局安全。表I米制参数与正文像素方向图转换缺失，当前参数明确不同；连续Laplace/flow-box/ISS全域条件、严格50Hz及真实平台/统计基线实验仍未证明。只改EGO1P1和HISTORY；EGO1P0/其他工程/远程分支未改，未提交或推送；既有未提交三维控制改动保留。
- 回滚/备份：`/home/starry/isaac-data/备份/EGO1P1_before_geometry_refinement_20260924_155516`。最终源码及验收输入SHA-256、构建/测试/实际运行日志存于`performance/paper_completion_20260924/`；不要把中间失败二进制/日志与最终版混用。
- 后续事项：将高开销自由域刷新与快速测量反馈做严格时限设计并验证50Hz；厘清论文表I与方向图单位；验证更广共同域/扰动界和多种子基线；具备实际平台后开展实物验收。当前通过项与未满足项详见PAPER_ACCEPTANCE.md。

### 2026-09-24 15:55 — [EGO1P1] 继续论文实现：精确自由域、规则场及运动验收

- 状态：实施中，最终验收尚未执行。
- 目的：用户要求继续按顺序补齐软件，采用更贴近论文的方法恢复可用运动；保留此前失败记录。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：本阶段WORK_LOG.md、HISTORY/CHANGELOG.md；后续实际修改和验收另记。
- 修改内容：备份当前源码/脚本/说明；复核论文式3–5确实要求可认证起始段，论文未说明机载近场盲区初始化。先改进独立于初始化约定的几何和场计算；向用户询问是否允许场景几何验证固定起始自由邻域。
- 验证：本阶段仅核对论文和建立快照；未宣称新算法或运行通过。
- 影响与边界：只在EGO1P1继续开发；EGO1P0、其他项目和远程分支不变。
- 回滚/备份：`/home/starry/isaac-data/备份/EGO1P1_before_geometry_refinement_20260924_155516`，包含src/scripts/tools和相关文档；场景及.git未修改，无需重复复制。
- 后续事项：自由体积查询、粗细场、参考延续、误差诊断及动态/Isaac验收。

### 2026-09-24 15:05 — [EGO1P1] 论文核心实现及严格观测验收；完整运行未通过

- 状态：部分完成；本轮实现与验收已执行，完整论文复现/导航验收未通过。
- 目的：按用户计划实现论文方法；用户明确选择未知空间不可通行、观测不足停车，允许完整运行验收暂不通过。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：新增 `src/pc_gvf/include/pc_gvf/paper_guidance.hpp`、`src/pc_gvf/src/paper_guidance.cpp`、`src/pc_gvf/test/cpp/paper_guidance_check.cpp`、`paper_closed_loop_check.cpp`、`src/pc_gvf/test/fixtures/paper/{isaac_intent_trace,isaac_strict_observation_trace}.json`、`PAPER_IMPLEMENTATION.md`、`PAPER_ACCEPTANCE.md`、`performance/paper_acceptance_20260924/`；修改 `src/pc_gvf/CMakeLists.txt`、`src/pc_gvf/src/depth_angular_controller_node.cpp`、`src/pc_gvf/launch/isaac_cloud_navigation.launch.py`、`scripts/isaac/manual_control_math.py`、`scripts/isaac/run_fov_gvf_navigation.py`、`scripts/run_isaac_fov_gvf_navigation.sh`、`src/pc_gvf/test/test_manual_control_math.py`、`tools/ros_vector_guidance_probe.py`、`README.md`、`EGO1P1_VERSION.md`、`WORK_LOG.md`；同步 HISTORY/README.md、FOV_GVF_FAMILY.md、CHANGELOG.md。
- 修改内容：主launch启用paper_enabled；保守深度缩减、40ms近邻采集位姿匹配、相机0.22m/0.02m外参；严格机体包络及方向扫掠自由距离下界，未知直接拒绝；24×18粗场/最多32×24细场与边界耦合；C2势场重建及C1规则向量场；等势截面返回、有限差分J及横向反馈；50ms场区间冻结和世界参考方向转图延续；单一三维指令及含制动尾段的扫掠检查。仅trace验证模式加入tau=0.22s、加速度1.2m/s²的一阶运动模型和文件扰动；正常人工输入不增加独立轴向控制。旧算法保留作对照。
- 验证：主脚本构建三包成功；最终PYTHONNOUSERSITE=1下CTest 11/12（退出8，paper_closed_loop_check未通过），平台pytest14/14。数值直场chi 3→1.0981、曲场3.08273→1.12845；J u、跨片导数、场冻结/换图/耦合及未知/制动拒绝断言通过。闭环八场景零碰撞，但立柱停在x≈2.0402m，未达到既定x>4.5m；未降低或跳过验收标准。障碍场景没有有效TRACKING样本，不能报告动态消融优势。真实ROS探针--paper退出0，全部机载输入命令为零并正确报告状态。最终Isaac严格trace运行6秒、363帧、301命令、200有输入调用，位置保持(-64,-11.2,2.8)，ESDF阻断0，主入口退出0；这是停车契约通过，不是运动通过。Shell语法/Python AST/git diff --check通过。
- 失败记录：初期Eigen链接、低速换图、源区/目标区处理和前视距离问题作出修正；严格规则下闭环仍失败。初轮CTest另有2项NumPy用户依赖冲突，隔离用户依赖后消除，未修改依赖版本。长扫掠包围盒过保守，改连续短段；最终方向域与rollout余量统一。Isaac仍有内部Humble回退和退出rosout context invalid告警，进程正常结束。中间失败与严格规则前运动结果在验收目录分别标记保留。
- 影响与边界：四水平机载相机无法完整覆盖自身包络，默认运行会返回UNOBSERVED_BODY_ENVELOPE并停车；未增加相机、先验自由球或多视图/历史观测融合。闭环外部相机数学夹具在严格域收窄时返回NO_REGULAR_FIELD；不能据零碰撞声称到达。连续模型稳定性全域条件、真实平台实验和完整论文复现未验证。源码只改EGO1P1，保留此前未提交三维控制改动；EGO1P0及其他工程不变，未提交/推送GitHub。
- 回滚/备份：`/home/starry/isaac-data/备份/EGO1P1_before_paper_20260923_205045/EGO1P1`；恢复时先保存本轮工作，不覆盖先前未提交修改。自动构建目录继续使用/tmp，验证原始日志已归档项目performance。
- 后续事项：取得机体及运动空间的真实观测覆盖；在严格域内建立可用规则场并通过障碍/扰动闭环，取得有效反馈/延续/粗细场消融样本，再做完整论文运行验收；详见PAPER_ACCEPTANCE.md。

### 2026-09-24 14:50 — [Hiking Data&Model] 新模型权重与控制契约审计

- 状态：部分完成；网络导出一致性通过，新训练语义核对受缺失配置限制。
- 目的：按用户要求核对 model_30000 与当前 C++ 适配层的关节、观测、动作缩放和相机契约。
- 项目路径：`/home/starry/isaac-data/ausimlab/ausim-rl/data/hiking/data&model`。
- 涉及文件：`/home/starry/isaac-data/ausimlab/ausim-rl/runs/model_30000_contract_audit_20260924` 下 audit.py、audit.json、config_provenance.json、REPORT.md；项目 README.md；HISTORY/CHANGELOG.md。
- 修改内容：新增可复现审计脚本与报告，列出 29 关节参数、观测 offsets、相机旧基线和缺失的新训练信息；模型、env.yaml 与控制源码未改。
- 验证：Isaac Python 执行 audit.py 退出 0；checkpoint 以 weights_only=True 加载。actor 34、depth 8 个参数张量与 checkpoint 全部逐值一致。18 组 PyTorch/ONNX Runtime 对拍全部通过（rtol=1e-4、atol=1e-5）：depth 最大误差 2.6226e-6，actor 同输入 5.3644e-7，端到端 8.9407e-7。按源码常量计算的 174 项旧 YAML 关节参数比较通过；6 份 env.yaml 哈希均与旧备份相同。新 ONNX 无模型 metadata，PT infos=None、无环境配置，无法确认新训练的物理语义。本轮未构建或重新运行 MuJoCo。
- 影响与边界：导出正确不代表控制契约匹配；MoE 与旧 MLP 结构不同不是已证实故障原因。上一轮闭环失败结论保留，不能标为已适配。
- 回滚/备份：本轮只增加审计记录，原模型备份不变；无控制参数需要回滚。
- 后续事项：用户提供对应训练 run 的 env.yaml、agent.yaml/runner、导出代码及 resolved 关节次序后继续逐项匹配与闭环验证。

### 2026-09-24 14:40 — [Hiking Data&Model] 新模型 C++ 闭环验证失败，原版对照通过

- 状态：验证完成；新模型运动验收失败，ONNX Runtime 推理通过。
- 目的：按用户要求验证补齐外部权重后的新模型。
- 项目路径：`/home/starry/isaac-data/ausimlab/ausim-rl/data/hiking/data&model`；运行器为 ausimlab/sim2sim/vendor/ausim2-main/build/bin/g1。
- 涉及文件：项目 README.md；`/home/starry/isaac-data/ausimlab/ausim-rl/runs/model_30000_validation_20260924_144008` 下 REPORT.md、JSON 日志和 model_hashes.json；HISTORY/CHANGELOG.md。
- 修改内容：仅新增验证产物和记录，模型与源码未改。测试进程显式指定迁移后动态库、MUJOCO_PLUGIN_DIR、场景和策略路径。
- 验证：新 stand 5.005 s、251 次推理，root_z=0.0792 m、upright=false；新 stand→新 parkour 8.005 s，root_z=0.0639 m、upright=false；原 stand→新 parkour 8.005 s，root_z=0.0631 m、upright=false；均有限但退出 1。原 stand 同环境 5.005 s，root_z=0.8200 m、退出 0；原 stand→原 parkour 真实深度上楼 8.005 s，root=(3.4314,0.1940,1.2199) m、退出 0。无虚拟基座或辅助。初次 STL 插件路径失败和首轮三组对照参数错误均保留日志，修正进程配置/脚本后重新执行。未重新构建，未进行真机测试。
- 影响与边界：证明新网络可以推理，但在旧 env.yaml/C++ 契约下不能通过闭环；不能确定倒地根因。独立 sim2sim 正式副本未变。
- 回滚/备份：本次未改模型与源码；原版备份仍为 备份/hiking_DataModel_before_model_30000_20260923_204119，未自动恢复模型。
- 后续事项：取得新训练配置，核对关节、动作、观测、相机和策略角色语义后再适配。

### 2026-09-24 14:34 — [Hiking Data&Model] 补齐两套 actor 外部权重

- 状态：完成文件补齐及 ONNX 参考推理检查，未做仿真验收。
- 目的：继续用户授权的模型替换，加入用户提供的 actor.onnx.data。
- 项目路径：`/home/starry/isaac-data/ausimlab/ausim-rl/data/hiking/data&model`。
- 涉及文件：`checkpoints/{stand_onboard,parkour_onboard_preview_stair}/exported/actor.onnx.data`；项目 README.md；HISTORY/CHANGELOG.md；备份目录与 manifest.json。
- 修改内容：两套 exported/ 补入同一外部权重文件，SHA-256 `0374a8892d32187a6a8b1da927aa3005852c46c22040f72c1bb3bea1df993ab9`；解除前次 actor 缺失外部数据的加载阻塞。
- 验证：完整备份逐文件 SHA-256 校验通过，两份新 data 与源文件一致；两套 actor/depth 完整加载及 onnx.checker 通过。ONNX ReferenceEvaluator 对每套运行两例 depth→actor（全零/全一深度，零本体输入），latent `[1,128]`、action `[1,29]`，均有限。当前 Isaac Python 未安装 onnxruntime；未运行 ONNX Runtime、构建、MuJoCo 或真机测试。
- 影响与边界：只补齐原 Data&Model 目录的权重；env.yaml、动作参考、PT、已有 ONNX 和独立 sim2sim 副本不变；训练语义兼容与实际运动能力仍未验证。
- 回滚/备份：`/home/starry/isaac-data/备份/hiking_before_external_weights_20260924_143408`。本次之前 data 文件不存在时删除新文件即可回滚权重补充；项目 README 可从备份恢复。原版整体备份仍为 hiking_DataModel_before_model_30000_20260923_204119，整体回滚还需删除新增 PT 和 data。
- 后续事项：核对新模型训练配置并在需要启用时验证部署运行时和闭环能力。

### 2026-09-23 20:50 — [EGO1P1] 开始分阶段实现论文方法

- 状态：部分完成，实施与验收进行中。
- 目的：按用户授权实现论文保守观测、锚定flow-box反馈、跨帧延续、粗细场及运动验收。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：后续阶段记录逐项列出；本条涉及WORK_LOG.md及HISTORY/CHANGELOG.md。
- 修改内容：保存当前含未提交三维控制改动的完整快照，再逐阶段实现；保留旧算法作为对照，不覆盖既有改动。
- 验证：本阶段仅完成快照复制；方法验收尚未执行。
- 影响与边界：只修改EGO1P1及统一记录，不修改EGO1P0或远程分支。论文不完整的数值实现细节将明确说明，不将数值测试等同实物实验或理论证明。
- 回滚/备份：`/home/starry/isaac-data/备份/EGO1P1_before_paper_20260923_205045/EGO1P1`。
- 后续事项：实施五个阶段并逐项记录实际结果。

### 2026-09-23 20:41 — [Hiking Data&Model] 备份并替换 stand/parkour 模型

- 状态：文件替换完成；运行验证阻塞（缺少 actor.onnx.data）。
- 目的：按用户要求先备份原版本，再将提供的三个模型文件同时用于 stand 和 parkour。
- 项目路径：`/home/starry/isaac-data/ausimlab/ausim-rl/data/hiking/data&model`。
- 涉及文件：`checkpoints/{stand_onboard,parkour_onboard_preview_stair}/exported/{actor.onnx,0-depth_encoder.onnx}`；两套目录各新增 `model_30000.pt`；`README.md`；本 CHANGELOG；备份目录与 manifest.json。
- 修改内容：两套 ONNX 使用用户源文件覆盖，PT 放在各 checkpoint 根目录；现有 env.yaml、agent.yaml 与动作参考保持不变。源目录：`/home/starry/文档/xwechat_files/wxid_2ly16bjl84yu22_3b16/msg/file/2026-09`。
- 验证：Isaac Python onnx 检查得到 actor `[1,896] -> [1,29]`、depth `[1,8,18,32] -> [1,128]`。actor 完整加载失败，原因是外部权重 actor.onnx.data 缺失，在源目录与 ausimlab 下未找到；depth onnx.checker 通过；PT ZIP CRC 检查通过，未反序列化。备份与原目录逐文件 SHA-256 一致，六个复制目标均与源 SHA-256 一致，其余原文件在记录追加前校验未变。未运行构建、推理或仿真。
- 影响与边界：仅修改原 Data&Model 迁移位置；独立 sim2sim 的 policies/imported/bundles 和 vendor C++ 配置未修改。两套策略现为相同新权重，不能据 shape 一致认定训练语义匹配或站立能力通过。
- 回滚/备份：`/home/starry/isaac-data/备份/hiking_DataModel_before_model_30000_20260923_204119`，完整原目录在 data&model/，哈希清单在 manifest.json。恢复四个 ONNX、删除新增两个 PT，README 可从备份恢复。
- 后续事项：补齐与 actor.onnx 配套的 actor.onnx.data；新 env.yaml/导出契约未提供，需核对后才能做推理与仿真验证。

### 2026-09-23 20:17 — [EGO1P1] 统一为深度规划三维建议矢量

- 状态：完成。
- 目的：用户确认人工输入只给三维期望方向，最终执行深度规划矢量，取消分别生成方向速度后再合成，不引入额外控制器。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：scripts/isaac/manual_control_math.py、beitong_joystick.py、run_fov_gvf_navigation.py；src/pc_gvf/src/depth_angular_controller_node.cpp、depth_angular_core.cpp、include/pc_gvf/depth_angular_core.hpp、launch/isaac_cloud_navigation.launch.py；src/pc_gvf/test/cpp/horizontal_360_check.cpp、test_manual_control_math.py、test_beitong_joystick.py；src/pc_gvf_platforms/pc_gvf_platforms/command_bridge.py、test/test_platform_math.py；新增 tools/ros_vector_guidance_probe.py；README.md、EGO1P1_VERSION.md、WORK_LOG.md、HISTORY/FOV_GVF_FAMILY.md、HISTORY/CHANGELOG.md。
- 修改内容：输入沿原始三维方向统一归一化和限幅；四相机仍按水平朝向选视图，但完整三维输入、当前速度及目标参与规划，horizontal_only=false；取消清零Z、独立升降回退及 composeHorizontalVerticalCommand。直接输出规划矢量，整体缩放满足总速度2m/s、Z分量1m/s；取消控制器 limited() 后置速度混合、加速度/jerk滤波及4个失效launch参数。保留规划器内部方向变化约束、制动和rollout检查。holonomic命令桥旋转坐标后整体缩放，不逐轴截断；仿真碰撞保护整体停止，不提取安全轴分量继续滑动。
- 传感器与行为边界：仍为四路水平90°相机，不新增传感器。纯上/下和所选视图外方向输出 DIRECTION_OUTSIDE_DEPTH_FOV；深度缺失/过期、输入过期、非法指令整体停止。视野内允许斜向升降，规划也可给出含Z的绕障方向。没有球面感知或完整三维全局规划。转向/yaw输入、场景与地图可视化保留。
- 验证：主构建脚本三个ROS包成功（最终构建14.3s）；CTest 10/10、平台pytest 14/14通过；Python AST和git diff --check通过。新增合成ROS探针在独立域83启动真实C++控制器，检查前上/左上/后下/右下/三维斜向、前方障碍、纯上下视野外、深度过期、输入过期和松杆；186组同帧发布速度与command_ray方向余弦>1-1e-10，所有限速/状态断言通过。合成障碍输出约(0.8931,0.4344,0.1172)，未叠加人工Z。日志 /tmp/ego1p1-vector-probe.log、/tmp/ego1p1-vector-controller-g3ti4ydb.log。
- 启动验证：经两个主入口完成构建和ISAAC_MANUAL_INPUT_MODE=keyboard、ISAAC_MANUAL_TIMEOUT=3、默认Cloud+RViz启动；183仿真帧、151命令、guidance=0、碰撞阻断0、MANUAL_TIMEOUT后退出码0。日志 /tmp/ego1p1-vector-smoke.log，性能记录 /tmp/ego1p1-vector-performance.md。系统rclpy不可用后内部Humble成功加载；退出仍出现一次rosout context invalid告警，各节点正常退出。本次未执行Isaac运动绕障或实体手柄操作；合成探针不是实际飞行验收。
- 影响与边界：当前EGO1P1控制语义变化，旧XY/Z与平滑性能结论不自动继承。EGO1P0及其他工程源码未修改；未提交或推送本次修改到GitHub。
- 回滚/备份：修改前精简基线为50f7c5500af86e31d0d9af03de8ec9a29ffb10e1（已发布远程ego1p0）；可在保存后续工作后按需恢复对应文件。
- 后续事项：动态Isaac绕障和实体手柄三维方向体验尚待验证；若需纯上下规划，须另行扩展深度覆盖范围。

### 2026-09-23 20:00 — [EGO1P1] 发布当前版本到 GitHub ego1p0 支线

- 状态：完成提交与推送；推送后独立远程查询受网络故障影响未完成。
- 目的：按用户要求以当前 EGO1P1 替换仓库 ego1p0 支线内容，不修改其他支线。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：此前复制和精简形成的全部项目改动，以及 WORK_LOG.md、HISTORY/CHANGELOG.md。
- 修改内容：本地 ego1p1 提交当前完整项目状态，显式推送 HEAD:refs/heads/ego1p0 到 Chenwill1899/Fov-gvf；保留提交历史，不强制推送、不创建其他远程分支。
- 验证：推送前远程 ego1p0 为 6d4e5778ccc3d97b585004c1d4f86e1f4a325ffc，dev 为 804f26e2e631d0571f5e1cc5088100481df1b16d；git diff --check 通过。本次不修改算法、不重跑构建或仿真；已有验证见上一条整理记录。
- 影响与边界：仅发布 EGO1P1 项目内容到指定远程支线；本地 EGO1P0 与其他远程分支不改动。
- 回滚/备份：旧版本提交 6d4e5778ccc3d97b585004c1d4f86e1f4a325ffc 仍保留在历史；整理前完整快照见上一条记录。
- 发布结果：提交 `50f7c5500af86e31d0d9af03de8ec9a29ffb10e1`；首次 SSH 推送连接关闭，重试成功，服务器返回 `6d4e577..50f7c55 HEAD -> ego1p0`，退出码0。本地工作树干净。使用单一 refspec，未请求更新 dev 或任何其他分支/标签。
- 失败与核验边界：推送后多次 SSH ls-remote 连接关闭，HTTPS 查询也出现 TLS 握手中断，未能独立复核远程全部引用。项目 WORK_LOG 保留提交前发布计划，本总账记录实际完成结果，避免仅为更新成功状态递归创建提交。
- 后续事项：网络恢复后可再次查询远程引用；无待推送项目改动。

### 2026-09-23 19:51 — [EGO1P1] 精简为两个主入口及运行/回归依赖

- 状态：完成。
- 目的：按用户要求整理 EGO1P1，主要保留 scripts/build_isaac_ros_workspace.sh 与 scripts/run_isaac_fov_gvf_navigation.sh 及相关依赖。
- 项目路径：`/home/starry/isaac-data/EGO1P1`。
- 涉及文件：完整整理前快照及清单在 `/home/starry/isaac-data/备份/EGO1P1_before_cleanup_20260923_194915`。55 条移出路径见 `REMOVED_PATHS.json`，包括旧 build/install/log、KEYBOARD/MISSANDKEYBOARD 独立入口、备用场景、场景生成/查看脚本、build_ros2.sh、未接入的 src/pc_gvf_core、隐藏研究框架和旧说明。迁移手柄模块到 scripts/isaac/beitong_joystick.py，测试到 src/pc_gvf/test/test_beitong_joystick.py；修改运行器导入、pc_gvf/CMakeLists.txt 测试注册、README、EGO1P1_VERSION、AGENTS、WORK_LOG、performance 自动记录及 HISTORY 四份状态/记录文档。
- 修改内容：scripts 顶层只保留构建/运行两个 Shell 入口，isaac 子目录保留运行器/手柄/控制数学三个 Python 文件，lib 保留设备识别。三个在用 ROS 包、Cloud/平地导航资产、RViz、算法测试/Python数值基准、ROS探针、性能记录和 Git 历史继续保留。算法、launch 参数和场景关键文件 SHA-256 与整理前一致；手柄模块仅迁移位置，内容一致。README 重写为当前最小运行指南，原说明完整保存在快照中，旧 WORK_LOG 不删除。
- 验证：整理前完整快照 1476 个文件/链接与 SHA-256/链接目标清单逐项一致。主构建脚本三包成功；新独立构建树 CTest 10/10（新增注册已有手柄4项测试），平台 pytest 13/13 通过；29 个 Python AST 与3个 Shell bash -n 检查通过；git diff --check 通过。OpenUSD ComputeAllDependencies 核对两个保留 USD 均为单层、无外部资产、无未解析引用。执行主入口，显式 keyboard、ISAAC_MANUAL_TIMEOUT=3、默认 Cloud+RViz，运行ID ego1p1_cleanup_smoke_20260923；成功加载4路320×240相机、0.40m ESDF、第三人称视图、在线地图及唯一控制发布者。183仿真帧、151命令帧、50Hz仿真时间命令频率，位置保持(-64,-11.2,2.8)，碰撞阻断0，MANUAL_TIMEOUT后退出码0。
- 失败/告警与边界：仿真加载内部 Humble rclpy 前尝试系统 rclpy 不可用，内部加载成功；退出时桥接 rosout 记录一次 context invalid 告警，节点仍正常退出。日志保存在快照 cleanup_smoke.log。未注入运动，guidance=0；本次仅证明整理后的完整启动/零输入/退出链可用，不声称动态绕障、实体手柄推杆或性能达标。手柄迁移由现有单元测试验证。EGO1P0 未修改。
- 回滚/备份：`/home/starry/isaac-data/备份/EGO1P1_before_cleanup_20260923_194915/EGO1P1` 为整理前完整文件树（含Git和未提交修改）；MANIFEST.json 校验来源，REMOVED_PATHS.json列出移出项目的路径。需要恢复时先保存后续工作，再按需取回，避免覆盖新的优化。
- 后续事项：算法优化继续在精简后的EGO1P1中进行，日常使用README中的两条命令。

### 2026-09-23 19:44 — [EGO1P1] 完整复制 EGO1P0 并建立后续算法开发主线

- 状态：完成。
- 目的：按用户要求将 EGO1P0 当前文件复制到 EGO1P1，之后以 EGO1P1 作为新开发主线。
- 项目路径：`/home/starry/isaac-data/EGO1P1`；来源 `/home/starry/isaac-data/EGO1P0`。
- 涉及文件：完整复制来源目录 1473 个文件/符号链接，包含 Git 历史、未提交修改、场景、性能记录、研究元数据及原 build/install/log/缓存。路径适配文件：`scripts/run_cloud_pillar_scene.sh`, `scripts/run_blender_isolated_cloud_scene.sh`, `scripts/prepare_ego_swarm_cloud_navigation.sh`, `scripts/prepare_ego_swarm_navigation.sh`, `scripts/prepare_flat_ground_navigation.sh`, `scripts/export_blender_cloud_to_isaac.sh`, `scripts/run_isolated_cloud_scene.sh`, `scripts/run_crack_maze_scene.sh`, `scripts/build_isaac_ros_workspace.sh`, `scripts/run_isaac_fov_gvf_navigation.sh`, `scripts/blender/generate_isolated_cloud_scene.py`, `scripts/isaac/generate_crack_maze_scene.py`, `scripts/isaac/generate_cloud_pillar_scene.py`, `scripts/isaac/generate_isolated_cloud_scene.py`, `KEYBOARD/run_keyboard_only.sh`, `KEYBOARD/run_joystick_only.sh`, `MISSANDKEYBOARD/run_joystick_avoidance.sh`。新增 `EGO1P1_VERSION.md`；更新 `AGENTS.md`、`README.md`、`DONG.md`、`USER_MANUAL_CONTROL_GUIDE.md`、`ISAAC_EGO_SWARM_CLOUD_NAVIGATION.md`、`ISAAC_FOV_GVF_NAVIGATION.md`、两个输入入口 README、`WORK_LOG.md`；统一更新 HISTORY 的 README、PROJECT_INDEX、FOV_GVF_FAMILY 和 CHANGELOG。
- 修改内容：完整复制后先校验逐文件 SHA-256/符号链接目标一致，再将新目录可执行脚本中的绝对根路径改为 EGO1P1，构建前缀改为 `/tmp/fov_gvf_ego1p1_isaac_{build,install,log}`，默认 ROS 日志为 `/tmp/fov_gvf_ego1p1_isaac_ros_log`。复制的独立 Git 仓建立无上游本地 `ego1p1` 分支，继承 `6d4e577`，保留所有来源未提交修改；未创建提交、未推送或修改远程。EGO1P1 设为后续优化主线，EGO1P0 保留基线。
- 验证：复制前后清单 1473 项完全一致；适配后复核来源清单未变，算法 src 与场景 scenes 的非缓存文件字节一致。14 个 Shell 文件 `bash -n` 和 38 个 Python 文件 AST 语法检查通过，可执行源码无 EGO1P0 绝对路径残留；`git diff --check` 通过。`bash EGO1P1/scripts/build_isaac_ros_workspace.sh` 在新前缀成功构建 pc_gvf_msgs、pc_gvf_platforms、pc_gvf，三包 colcon_build.rc 均为 0；source Humble/新 install 并设 PYTHONNOUSERSITE=1 后，独立 pc_gvf 构建树 CTest 9/9 通过。未启动 Isaac、未执行手柄动态避障或性能实验。
- 影响与边界：算法、参数、输入语义、ROS 话题与场景不变。共用 ROS_DOMAIN_ID=42 和原单实例锁，继续禁止两个副本同时控制。来源版本说明、WORK_LOG 旧条目、performance 与 .research 历史保留原内容，不宣称旧实验已在新版本复验。原目录内复制的 build/install/log 可能含旧绝对路径，仅保留来源记录，正式入口使用本轮新建的独立 /tmp 产物。
- 回滚/备份：EGO1P0 原目录完整未改；新目录与构建产物独立，可在明确要求回滚时移除，并追加历史更正，不删除旧记录。
- 后续事项：后续算法修改默认在 EGO1P1 进行，并同步项目 WORK_LOG 和 HISTORY；动态仿真另行执行。

### 2026-09-23 18:57 — [ChatGPT Linux] 下载官方最新 x64 DEB

- 状态：完成。
- 目的：从 OpenAI 官方下载入口获取当前最新 Linux x64 `.deb` 安装包。
- 项目路径：`/home/starry/isaac-data`。
- 涉及文件：`/home/starry/isaac-data/chatgpt_amd64.deb`、本记录文件。
- 修改内容：下载官方 CDN `https://persistent.oaistatic.com/codex-app-prod/linux/deb/latest/chatgpt_amd64.deb`；包元数据为 `chatgpt 26.917.62051 amd64`，大小 `420738082` 字节，SHA-256 为 `75536e3f197c6db8881a634f8bb9b0515184a8eff7cec9be5f408d0f4ae6e696`。
- 验证：读取官方 `dists/stable/main/binary-amd64/Packages`，确认版本、文件大小和 SHA-256；执行 `sha256sum /home/starry/isaac-data/chatgpt_amd64.deb` 与 `dpkg-deb -f ... Package Version Architecture Installed-Size`，结果分别匹配官方索引、`chatgpt 26.917.62051 amd64 1384745`。首次下载产生的未完整文件校验不匹配，已用完整校验通过的包替换；未安装、未启动应用。
- 影响与边界：仅新增安装包文件，不修改源码、ROS/Isaac 配置或系统已安装软件。本机为 `x86_64 / Ubuntu 22.04`；官网当前 Linux 公开预览支持 Ubuntu 24.04/26.04 LTS、Debian 13、Fedora 43/44，因此本机系统版本不在官网列出的支持范围内。
- 回滚/备份：删除 `chatgpt_amd64.deb` 即可移除本次下载的文件；未执行安装，因此没有系统安装状态需要回滚。
- 后续事项：如需使用，先升级到官网支持的 Linux 版本，再运行 `sudo apt install ./chatgpt_amd64.deb`；无安装授权，本轮不执行。

### 2026-09-23 18:50 — [EGO1P0] 兼容北通 A2P3A BFM 与 XInput 手柄

- 状态：完成双profile实现、静态/单元测试和当前BFM接收器启动门禁实测；本轮没有
  启动完整ROS/Isaac、推动摇杆、执行受控USB断连停车测试或重新执行动态避障。
- 目的：修复EGO1P0三个手柄入口写死
  `/dev/input/by-id/usb-BEITONG_BEITONG_A2P3A_BFM_DONGLE-joystick`，导致接收器以
  XInput `045e:028e`模式出现时即使已经插入也被拒绝的问题；同时按profile修正轴映射，
  避免把XInput空闲值为`+1`的LT axis 2误作Roll并阻塞回中解锁。
- 项目路径：`/home/starry/isaac-data/EGO1P0`，分支`ego1p0`，基线提交`6d4e577`；项目
  自有`WORK_LOG.md`已同步更新。
- 涉及文件：新增`scripts/lib/beitong_joystick.sh`、
  `MISSANDKEYBOARD/test_beitong_joystick.py`；修改`scripts/run_isaac_fov_gvf_navigation.sh`、
  `MISSANDKEYBOARD/run_joystick_avoidance.sh`、`KEYBOARD/run_joystick_only.sh`、两套Python
  joystick读取器，以及`EGO1P0_VERSION.md`、两份入口README、人工控制指南、Cloud人工
  控制说明、`DONG.md`、项目`WORK_LOG.md`和`HISTORY/FOV_GVF_FAMILY.md`。
- 修改内容：共享Shell解析器自动扫描唯一`/dev/input/js*`，用udev严格支持BFM
  `20bc:511c`与北通XInput `045e:028e`，后者额外要求BEITONG vendor/model字段；显式
  `JOYSTICK_DEVICE`仍不能绕过身份、字符设备和权限检查，显式profile经去空白/小写化后
  必须与检测结果一致。BFM要求准确8轴16按钮并使用Yaw/Throttle/Roll/Pitch=`0/1/2/3`；
  XInput要求准确8轴11按钮并使用`0/1/3/4`。Python层固定核对profile尺寸，不再允许
  expected环境变量覆盖契约；速度、方向符号、死区、回中门、断连停车和键盘兼容路径
  均保持原行为。
- 验证：四个Shell脚本`bash -n`通过；`MISSANDKEYBOARD/beitong_joystick.py`、新增测试及
  `KEYBOARD/keyboard_only.py`的`py_compile`通过；unittest `4/4`通过，覆盖BFM/XInput
  映射、已知尺寸推断、XInput空闲LT不阻止回中解锁、profile尺寸冲突及旧expected覆盖
  无法绕过检查；`git diff --check`通过。本轮较早的实机检查由udev枚举为BFM
  `20bc:511c`，节点
  `/dev/input/js0`可读，解析器实测选择`profile=bfm`、轴`0/1/2/3`。主入口使用故意
  不存在的ROS安装前缀进行无副作用门禁测试时，先成功打印上述手柄选择，随后按预期在
  `setup.bash`检查退出，未启动ROS/Isaac或发布控制指令。最后收紧尺寸契约后尝试重复
  实机检查时，解析器报告没有受支持设备；随后`lsusb`和`/dev/input`复核确认接收器已经
  不在系统中，因此没有把该次写成重复实机通过。
- 影响与边界：仅改变EGO1P0手柄设备发现及profile轴契约，不修改FOV-GVF算法、ROS话题、
  场景、速度、传感器或碰撞保护。用户之前提供的`lsusb 045e:028e`和此前udev诊断确认
  接收器曾处于北通XInput模式；本轮较早实机验证时硬件已切回BFM，故本记录不把XInput
  物理推杆、受控USB断连停车或完整动态飞行写成通过。
- 回滚/备份：本轮是`6d4e577`上的未提交工作树差异；删除两个新增文件并恢复上述EGO1P0
  文件及两份HISTORY记录即可回到单一BFM入口。没有修改`user/Fov-gvf`、`user_ego`、
  AusimLab SIM2SIM或远程分支。
- 后续事项：用原启动命令现场验证四个摇杆方向、回中停车和USB断连；若设备再次以
  `045e:028e`出现，应先确认终端显示`profile=xinput`及`0/1/3/4`，再进行动态飞行。

### 2026-09-21 20:53 — [AusimLab SIM2SIM] 兼容北通 A2P3A XInput 接收器并完成实机启动

- 状态：完成设备诊断、双模式适配、构建与接收器实机启动冒烟；本轮读取了中立手柄帧，
  没有人工逐个按下 RB/LB/Back/Start 或推动摇杆完成整套动作验收。
- 目的：解决北通接收器已经插入但 `run_g1_gamepad.sh` 仍报告找不到固定 BFM by-id 的问题，
  并避免把 XInput 下的扳机轴误当成右摇杆转向。
- 项目路径：`/home/starry/isaac-data/ausimlab/sim2sim`；项目没有独立 `WORK_LOG.md`。
- 涉及文件：修改 native `run_g1_gamepad.sh`、`g1_betop_gamepad_mapping.hpp/.cpp`、
  `g1_betop_gamepad_main.cpp`、mapping C++ 测试、native `README.md`、
  `cfg/remote_control.yaml` 注释和 `tests/test_mujoco_native_backend.py`。
- 设备证据：内核将当前接收器识别为 `BEITONG A2P3A XINPUT DONGLE`，udev 为
  `045e:028e`、`ID_VENDOR=BEITONG`、`ID_MODEL=BEITONG_A2P3A_XINPUT_DONGLE`，由 `xpad`
  驱动，输入节点为 `/dev/input/js0` 和 `event20`，稳定链接为
  `/dev/input/by-id/usb-BEITONG_BEITONG_A2P3A_XINPUT_DONGLE-joystick`。ROS joy 枚举名为
  `X360 Controller`；实读中立 `/joy` 为 8 个 axis、11 个 button，LT/RT 未按时分别为
  axis 2/5 的 `1.0`。设备带 uaccess ACL，`starry` 可以读取，本次失败不是 `input` 组权限。
- 修改内容：启动器不再写死一个 by-id，而是扫描 `/dev/input/js*`，只接受唯一一个经
  udev 严格确认的北通 A2P3A；同时支持既有 BFM `20bc:511c` 和当前带 BEITONG
  manufacturer/model 字符串的 XInput `045e:028e`，零匹配、多匹配、错误身份、非字符设备
  或不可读设备均拒绝。可用 `AUSIM_G1_BETOP_DEVICE` 显式选择，但不能绕过身份检查。
  adapter 根据 profile 区分映射：BFM 为 RX axis 2、LB/RB 6/7、Back/Start 10/11；XInput
  为 RX axis 3、LB/RB 4/5、Back/Start 6/7。两种模式均要求准确的 8x16 或 8x11 `/joy`
  shape；不匹配时发布零速度。测试从会在 Release 下被 `NDEBUG` 清空的 `assert` 改为显式
  失败检查。
- 验证：`bash -n`、`git diff --check`、专项 Python `5/5`、SIM2SIM Python 全测
  `92 passed, 7 skipped`；全新 Debug contract 构建与 CTest `4/4` 通过；全新 ROS Humble
  构建成功，原用户命令使用的 `build/native-betop-ros` 也已重建，Release mapping CTest
  `1/1` 通过。ROS 构建树完整 CTest 仍为 13 passed、1 skipped、1 failed，唯一失败仍是
  既有 `g1_startup_pose_smoke_test` 的 `SEGFAULT`。用真实 `/dev/input/js0` 启动约 12 秒时
  自动选择 `profile=xinput`，`joy_node` 成功打开 `Xbox 360 Controller`，adapter 接收中立帧
  并发布 forward/yaw 均为零，MuJoCo viewer 启动且 ColdStart 完成；随后按测试计划中断，
  检查没有遗留 g1、joy_node 或 adapter 进程。
- 影响与边界：只扩展可选 `mujoco-oracle + viewer` 人工控制入口；没有改变正式 direct
  Hiking 策略、bundle、场景和既有爬楼验收。XInput 物理按键/摇杆的索引来自 Linux xpad
  能力、ROS 实读 shape 和标准映射，并由合成测试覆盖；本轮没有人工操作每个实体控件，
  因此不把完整手柄行为写成全部实机通过。
- 回滚/备份：本轮改动是 SIM2SIM `main@6b22b69` 上的未提交工作树差异；移除上述八个文件
  的差异即可回到只支持 BFM 的基线。此前恢复北通及 CP2102N 实验记录均原样保留。
- 后续事项：用户可直接重跑原命令；在 viewer 中按提示扶正机器人后，依次验证 RB、LB、
  左/右摇杆和 Back+Start。若再接入多个游戏控制器，应显式设置
  `AUSIM_G1_BETOP_DEVICE` 并确认 ROS SDL 选中的仍是北通设备。

### 2026-09-21 20:29 — [AusimLab SIM2SIM] 恢复北通手柄控制链路

- 状态：软件恢复和自动验证完成；当前主机没有插入北通接收器，因此未执行实机按键和
  MuJoCo viewer 人工控制验收。
- 目的：按用户要求停止未获官方协议支持且实测持续读取到零字节的 Unitree CP2102N
  串口实验，恢复此前已经完成实体映射验证的北通手柄控制。
- 项目路径：`/home/starry/isaac-data/ausimlab/sim2sim`；项目没有独立 `WORK_LOG.md`。
- 涉及文件：将仓库根 `README.md`，以及
  `ausim_sim2sim/backends/mujoco/native/` 下的 `CMakeLists.txt`、`NOTICE.md`、`README.md`、
  `cfg/remote_control.yaml`、`run_g1_gamepad.sh`、北通 mapping/node/test 源码和
  `tests/test_mujoco_native_backend.py` 精确恢复到 `HEAD 6b22b69`；移除未提交的
  `g1_unitree_remote` 源码及两个串口协议/映射测试。最终 SIM2SIM Git 工作树相对 HEAD
  干净，没有改动 Hiking 策略、bundle、场景、正式 direct backend 或既有运行回执。
- 修改内容：可选人工控制重新采用 `BEITONG A2P3A BFM DONGLE`（USB `20bc:511c`）的
  稳定 by-id 节点，经 ROS2 `joy_node` 发布 `/joy`，再由 `g1_betop_gamepad` 发布
  `/g1/cmd_vel` 并调用 stand/parkour/emergency 服务。恢复映射为左摇杆 Y 前进、右摇杆 X
  转向、`RB=stand`、`LB=parkour`、`Back+Start` 为仿真备用锁存急停；LT/RT 继续保留。
- 验证：`bash -n run_g1_gamepad.sh` 通过；专项 Python 测试 `4/4`、SIM2SIM Python 全测
  `91 passed, 7 skipped`；全新 Debug contract 构建成功且 CTest `4/4` 通过，其中北通
  mapping 测试在没有 `NDEBUG` 的情况下实际执行断言；全新 ROS Humble 构建成功，确认
  `bin/g1_betop_gamepad` 和 `bin/g1` 均生成且没有 `g1_unitree_remote`。ROS 构建树完整 CTest
  为 13 passed、1 skipped、1 failed，失败仍是既有 `g1_startup_pose_smoke_test` 的
  `SEGFAULT`。无手柄运行启动脚本时按设计以 exit 1 拒绝，并指出缺少北通稳定设备节点。
- 影响与边界：只改变 `mujoco-oracle + viewer` 的可选人工输入方式；正式
  `simctl.py run --backend mujoco` 和已经通过的 Hiking 爬楼链路不依赖手柄，未重新运行
  爬楼。当前 `lsusb` 没有 `20bc:511c`、系统没有 `/dev/input/js*`；不能据软件测试声称
  实体按键已通过。`starry` 当前不属于 `input` 组，接回设备后还需核对该设备 ACL。
- 回滚/备份：北通恢复基线为 SIM2SIM 提交 `6b22b69`；上一轮 CP2102N 实验及其验证边界
  保留在下一条 20:01 历史记录中，没有改写旧记录。
- 后续事项：插入北通 USB 接收器后确认 stable by-id、`/joy` 的 8 轴 16 键数据和读取权限，
  再运行 `run_g1_gamepad.sh` 验证 RB/LB、摇杆、watchdog 与 Back+Start 急停。

### 2026-09-21 20:01 — [AusimLab SIM2SIM] 将可选遥控链路切换为 Unitree CP210x 串口接收器

- 状态：软件改造和自动验证已完成，真实接收器端到端验收暂停；当前用户 `starry` 不在
  `dialout` 组，无法读取 `/dev/ttyUSB0`。用户要求本轮到此结束，取得权限后再继续采样和
  MuJoCo viewer 实测，因此没有把默认波特率、串口帧边界或物理按键写成硬件已通过。
- 设备核对：只读检测到 `Bus 001 Device 004: ID 10c4:ea60 Silicon Labs CP210x UART
  Bridge`，udev 型号为 `CP2102N_USB_to_UART_Bridge_Controller`、序列号为
  `f64bb995046aef11be88af76d9b539e6`，稳定链接指向 `/dev/ttyUSB0`。设备权限为
  `root:dialout 0660`，当前进程无读取权限；`Bus 001 Device 004` 仅是易变枚举号，启动器
  改为发现唯一 `/dev/serial/by-id/*` 并强制校验 VID/PID `10c4:ea60`，也允许显式指定稳定
  路径和波特率，但不会回退到旧设备或旧二进制。
- 实现：删除 BEITONG HID、`sensor_msgs/Joy` 和 ROS `joy_node` 适配器，新增只读
  `termios` 串口节点 `g1_unitree_remote`、40 字节小端字段解析、流分片/粘包/失步重同步和
  有限范围校验。按钮位按公开 Unitree SDK2 定义处理；映射改为 `Ly > 0.5` 时固定前进
  `0.5 m/s`、`Rx` 经 `0.5` 死区后反向线性映射到 `±1 rad/s`、`R1=stand`、
  `L1=parkour`、任一 `L2/R2` 锁存急停，超过 `250 ms` 无有效帧则发布零速度。兼容保留
  `run_g1_gamepad.sh` 文件名，但内部只接受新串口节点。
- 边界：该改动仅影响 `mujoco-oracle + viewer` 的可选人工交互路径，不改变正式
  `simctl.py run --backend mujoco`、Hiking 策略、场景、bundle 或既有楼梯验收回执。串口
  默认值暂为 `921600`、帧头暂为 `FE EF`；因尚未读取真实字节，波特率、帧头、帧长、轴
  极性以及 R1/L1/L2/R2 物理对应关系均等待权限恢复后确认。
- 验证：contract-only 构建及 CTest `5/5` 通过；完整 no-ROS 构建通过，CTest
  `14 passed, 1 skipped`（无图形环境时 raw-depth capture 按设计跳过）；ROS Humble 的
  `g1_unitree_remote` 目标构建通过。专项 Python 测试 `5/5`、全仓 Python 测试
  `92 passed, 7 skipped`，`bash -n run_g1_gamepad.sh` 和 `git diff --check` 通过。ROS 构建树
  完整 CTest 为 `14 passed, 1 failed, 1 skipped`：既有 `g1_startup_pose_smoke_test` 再次以
  `SEGFAULT` 失败，未隐瞒或计作通过；本轮没有运行真实串口控制或 viewer 爬楼。
- 恢复与后续：源码基线仍为 SIM2SIM 提交 `6b22b69`，当前修改未提交；旧北通文件删除和
  新 Unitree 文件均可由工作树差异审计。取得 `dialout` 权限并重新登录后，应先采集空闲、
  两个摇杆以及 R1/L1/L2/R2 的原始帧，确认串口契约，再运行可选 viewer 链路；若采样与
  暂定参数不符，应先修改协议参数和 golden tests，不能绕过帧校验。

### 2026-09-21 19:35 — [AusimLab] 完成训练/SIM2SIM 分仓并通过 Hiking 真实深度爬楼验收

- 状态：完成结构迁移、双仓固化、构建与测试、30 秒站立、两步、真实深度楼梯和 viewer
  验收。正式 `sim2sim` 爬楼回执绑定干净源码提交且全部 stairs checks 通过；`sim2real/`
  按要求保持物理空目录，本轮没有声明真机部署就绪。
- 最终结构：统一根目录为 `/home/starry/isaac-data/ausimlab`。`ausim-rl/` 只保留 Isaac
  训练、回放、评估与便携策略导出；`sim2sim/` 独立拥有 Hiking 运行算法、MuJoCo/ONNX
  Runtime 窄 C ABI、场景、bundle、策略导入、本机依赖、运行回执与验收测试；二者只通过
  `policy.yaml + ONNX` 交接，不互相 import。Hiking 动作数据归到
  `ausim-rl/data/hiking/`，原始 `ausim2-main` 与 `ausim2-main.zip` 归到
  `sim2sim/vendor/`，正式运行不读取 vendor。
- 训练边界：删除 `ausim-rl` 中 tracked 的 `deployment/`、task deployment、通用运行接口、
  bundle 实现和部署测试；`labctl` 仅保留 `tasks/check/train/play/evaluate/export`。新增
  `hiking.g1.policy.v1` 策略包 builder/validator，固化角色、相对路径、模型哈希、tensor
  I/O、29 关节接口和 parity 证据，拒绝绝对路径；`check` 同时支持 Isaac standalone
  Python 3.12 与外置 `AUSIM_HIKING_MOTIONS`。清除旧 ignored `deployment/build/egg-info`
  后重新构建 wheel，295 个文件中没有 deployment、sim2sim 或 policy bundle 模块，wheel
  SHA-256 为 `a07a657961eb1a618589e5cc05f45c08a6f33b781bababb90f6d60a42badb8af`。
  训练侧最终 Python 测试 `38/38`、106 subtests 通过，`labctl check --task hiking` 在本机
  Isaac Sim `6.0.1-rc.7`、Isaac Lab `6.1.14`、Torch `2.10.0+cu128` 下通过。没有可供本轮
  重新训练/导出的新 checkpoint，且 standalone Isaac Python 未安装 Python
  `onnxruntime`，因此没有把真实新 checkpoint export 写成已执行；策略包 builder/parity
  边界由单测覆盖。
- SIM2SIM 边界：建立独立 `ausim_sim2sim` 包和 `simctl.py`，支持 `tasks list`、
  `policy import`、`bundle compose`、`check`、`run`/`sim2sim`。现有裸 ONNX 以明确
  `legacy_import` 身份导入 stand/parkour，不伪造 checkpoint；组合 bundle 校验角色、
  manifest 与模型 SHA-256、tensor shape/dtype、768 维 observation、128 维深度 latent、
  896 维 actor 输入、29 维动作/目标、PD、200/50 Hz、深度相机历史、关节映射、scene/mesh
  和 native 依赖闭包。正式 `mujoco` 为 Python task 算法直连进程内 C ABI；旧 C++ 单体仅
  作为显式 `mujoco-oracle` 行为对照和 viewer。
- 原生运行时：canonical scene SHA-256 为
  `9b1ad57a308dca798ed11fd0d114b576238ee0588dd781299dbfdedb293bc334`；MuJoCo/ONNX
  wrapper 分别为 `9dc0537fec80dcc4e79498020b80e92808e6e8a5792f6df648d7c038551160b6`、
  `c83b2e2231da90262818f040183bc2441955063a0be4a9fd749d368f8be52b39`；20 文件 `ldd`
  闭包指纹为 `8f36c3081c21965e10396685e24abcf060b4ce25d990e4f12523fadd2d8e9045`。
  三目标均无 `not found`，RPATH 只指向 `sim2sim/third_party`；其绝对 RPATH 绑定当前最终
  位置，今后再次移动目录必须重建和重新验收。
- 自动验证：contract build/CTest `4/4` 通过；no-ROS full build 与 CTest `14/14` 通过，
  包含真实 raw-depth capture；SIM2SIM Python 全测 `91 passed, 7 skipped, 12 subtests`
  通过；真实 C++/Python 深度历史、三帧全链路及 ONNX legacy golden opt-in `3/3` 通过，
  Python→MuJoCo C ABI 的 load/reset/step/raw-depth/清理 opt-in `4/4` 通过；预检最终报告
  `artifact_valid=true`、`composition_valid=true`、`sim2sim_ready=true`。首次 Python 全测
  因环境自动加载 ROS `launch_testing` 且缺 `lark` 失败，禁用无关外部 pytest plugin 后
  重跑；迁移中的 YAML eager import、旧 license 路径、顶层 native 产物解析、能力名不一致
  和旧 opt-in 路径假设均经测试暴露、修正并全量复测。
- 正式爬楼：bundle manifest SHA-256 为
  `2afe1f2704e2972217ad1839e45f2b6d19aadc94322e2f27e12a2d037b4e5672`。direct 真实深度
  stairs 回执位于 `sim2sim/runs/20260921_112031_088900`，绑定干净提交
  `6b22b6912cb501502342337e49af57aa5feb0adb`；8 秒完成 400 control/1600 physics、100
  stand warmup、300 parkour inference 和 300 帧 MuJoCo 相机深度，无基座辅助，末端 root
  `[3.439318, 0.191218, 1.223986]`、垂直上升 `0.323986 m`，stairs acceptance 全部为
  true，summary SHA-256 为
  `d63ab02e0f726fd79f2474be2b3e7ff1f9275cbb407344f3bf2a1c7ef44342bf`。
- 补充行为验收：direct 30 秒站立回执为 `runs/20260921_112127_732157`，1500 control/
  6000 physics、保持直立并通过 stand profile，summary SHA-256 为
  `ac7a5f96456dcde2632e2fba9bb59167113f6140a5cce6c9eb50eb1c14d70f5a`。oracle 首次额外
  带 `--synthetic-depth` 的两步诊断位于 `runs/20260921_112138_794160`，虽检测到两次落脚
  但向后跌倒并按设计验收失败；恢复真实 MuJoCo 相机后，`runs/20260921_112300_556796`
  完成两次落脚、前进 `0.310335 m`、横漂 `0.031520 m` 且保持直立，summary SHA-256 为
  `9445b65b9bada1618befb1bebd8f37acb6beb9a95f340df7f6b93d19433d73d5`。viewer 爬楼回执
  `runs/20260921_112325_698525` 末端为 `[3.431443, 0.193966, 1.219928]`、300 帧真实深度，
  stairs profile 通过，summary SHA-256 为
  `c96eea63bd1ab19322f487d6098a3bb98e3a3cde25c3a2eedd30d3520db0200c`。
- Git、清理与恢复：训练仓提交为 `f8d4a05`（`refactor: keep ausim-rl training-only`）；
  新 SIM2SIM 仓根提交为 `6b22b69`（`feat: establish standalone Hiking sim2sim`），最终两仓
  工作树均干净，未 push。旧顶层 `/home/starry/isaac-data/ausim-rl` 经 HEAD/refs/Git 对象、
  126 个历史 run、4 个 bundle、84 个 mesh 和 ONNX 哈希核对无唯一内容后，可恢复地移到
  `/tmp/ausim-rl-old-20260921`；训练仓旧 ignored build/cache 移到
  `/tmp/ausimlab-training-stale.bCCG7u`。历史 receipts 原样保留旧绝对路径，不作为当前可移植
  bundle。正式爬楼在隔离旧目录后执行，证明当前链路没有暗中依赖旧结构。

### 2026-09-21 17:47 — [ausim-rl] 适配 ausim2-main 新位置并现场运行 Hiking 爬楼

- 状态：完成外部 native 依赖路径迁移、空构建目录全量重建、运行时重新批准、bundle
  重新 compose、关键回归、正式 direct 爬楼和 MuJoCo viewer 现场演示；最终 direct receipt
  绑定干净提交且 stairs acceptance 全部通过。
- 背景与目的：用户要求给出运行指令并现场运行时，发现完成上一轮验收后外部
  `/home/starry/isaac-data/ausim2-main` 已移动到
  `/home/starry/isaac-data/ausimlab/sim2sim/ausim2-main`。formal runtime 的 RPATH 和批准依赖
  清单有意绑定绝对路径，因此第一次现场 `labctl sim2sim --backend mujoco` 在启动仿真前以
  exit 2 拒绝缺失的 `libstl_decoder.so`；本轮没有使用 `LD_LIBRARY_PATH` 或关闭哈希检查
  绕过门禁，而是针对新位置重新构建和批准。
- 依赖核对：新位置的 MuJoCo 3.6.0、GLFW、ONNX Runtime 和 STL decoder 文件 SHA-256
  与旧 receipt 逐项一致，35 个 G1 mesh 也全部一致；外部目录自带 `scene.xml` 只因
  `meshdir` 改为其本地相对路径而哈希不同，本项目仍使用并校验 `ausim-rl` 内 canonical
  scene，没有用该外部 scene 冒充旧资产。四个 stand/parkour ONNX 仍位于独立
  `hiking-in-the-wild_Data&Model`，内容哈希均未改变。
- 重建与批准：最初复用 CMake build tree 配置时，内部 `_mujoco_lib` cache 仍引用旧路径，
  第一次增量 build 因旧 `libmujoco.so` 目标不存在而失败；清除该 cache 后构建成功。随后
  审计发现孤立 dependency metadata 仍保留旧路径，因此没有把该增量目录作为最终恢复
  基线，而是将原 `build/runtime` 和 `build/no-ros` 可恢复地移动至
  `/tmp/ausim-build-relocation.e0jCjm/`，从空目录分别完整配置和编译。最终两个 build tree
  对旧路径的全文扫描均为 0，`ldd` 全部解析到新位置，runtime/no-ros 两套 wrapper 哈希
  完全一致。
- 契约更新：MuJoCo C ABI 批准 SHA-256 更新为
  `fd8630ec44d541aa7ff414779a95b1306b61a8e19e5977d4c018f1441613a7f0`，ONNX C ABI 更新为
  `f22486e04b61654996bd2afbb09f82a6ddc35bd2fe10bd70a99643910b64451d`，20 文件依赖闭包
  指纹更新为 `6bb9bb808131680d8099588a7958fa88e59f9a7a8a6de36e5c80994187fb193e`；修改仅涉及
  `task/hiking/deployment/manifest.py` 的 task-owned 批准值。用 `labctl bundle compose`
  重新生成本地 schema-v2 manifest，SHA-256 为
  `75850b0adf2810e4638df984f2279f1dd3727b7afce5a86bb83b0ed8534b1c0b`；生成结果与预先
  手工核对版本逐字节一致，后者备份为 `/tmp/ausim-hiking-manifest-manual-relocation.yaml`。
- 验证：空目录最终重建后 native CTest `14/14` 通过，其中 raw graphical opt-in 按默认
  配置 skip；deployment bundle 与 direct process 关键 Python 回归 `28/28` 通过；
  `git diff --check` 通过。正式 direct 真实深度运行位于
  `runs/deployment/20260921_094701_952381`，绑定干净提交
  `d5fb8bd0a036965e9fdd6e00a50875bf1737eb45`、空 `git_status` 和新 manifest，8 秒内完成
  400 个控制步、1600 个 physics step、100 次 stand warmup、300 次 parkour 推理及 300 帧
  MuJoCo 相机深度；末端 root 为 `[3.439318, 0.191218, 1.223986]`，垂直上升
  `0.323986 m`，`base_assist=none`，所有 stairs checks 为 true，summary SHA-256 为
  `93d21def670090913aa522318f9333ecad979d6970a570d2bb09b239212dda4c`。
- 可视化演示：按用户要求启动 `mujoco-oracle --viewer` 实时窗口 8 秒，运行目录为
  `runs/deployment/20260921_094021_856682`；前 2 秒 stand warmup 后切换 parkour，采集
  300 帧真实深度，末端 root 为 `[3.431443, 0.193966, 1.219928]`、垂直上升
  `0.319928 m`，无基座辅助且 stairs acceptance 全部通过。该 viewer receipt 产生于批准
  source commit 前，作为现场视觉/行为证据；最终可审计正式证据以上述干净 direct receipt
  为准。
- Git 与边界：提交 `d5fb8bd`（`chore(deployment): reapprove relocated native runtime`），
  提交后 `integrate_hiking_mujoco` 工作树干净；没有 push、PR 或修改 `dev`。build、bundle、
  runs 仍为忽略产物。旧历史 receipts 保留旧绝对路径和指纹，未被改写；SIM2REAL 门禁仍为
  false。本机再次移动或升级动态依赖时，formal preflight 会继续 fail closed，并需要按同一
  流程重新构建和验收。

### 2026-09-21 16:49 — [ausim-rl] 完成 Hiking 任务算法直连 MuJoCo 的 SIM2SIM 集成与爬楼验收

- 状态：完成六阶段实现、Git 集成提交、全量自动测试、真实深度楼梯闭环自检和原生
  oracle 对照；默认 `mujoco` 已由原先的拒绝/外部 bridge 路径改为“Python task 算法直接
  调用进程内 C++ MuJoCo/ONNX 窄 C ABI”的正式 SIM2SIM 路径。SIM2REAL 仍按设计关闭，
  本轮没有声称实机部署就绪。
- 目的：落实 `task/` 保存任务算法、`deployment/backend` 保存部署接口和 SIM2SIM 能力的
  分层，使 Hiking 的 observation、深度历史、stand/parkour 推理、动作映射和 PD 控制归
  task 所有，而 MuJoCo 只提供模型加载、状态、raw depth、力矩和 step；同时保留旧 C++
  单体程序为显式 `mujoco-oracle` 行为基准，以中间张量和闭环结果证明迁移不是“能运行但
  数值已经改变”。
- 项目与基线：项目为 `/home/starry/isaac-data/ausim-rl`，没有独立 `WORK_LOG.md`；从
  `refactor_train_layout@0e29b2e` 创建 `integrate_hiking_mujoco`，以 merge commit
  `3ca33e1` 引入 `refactor_mujoco_g1@5f4c8ae`，只人工合并 `README.md` 与
  `docs/repository_layout.md` 的文档重叠，没有从 `ausim2-main` 再次复制源码，也没有提交
  `native/build`。
- bundle v2：在兼容读取既有 v1 的基础上增加 Hiking deployment composition，同时引用
  stand 和 parkour 两个角色；固化四个角色级 ONNX 批准哈希、实际 tensor 名称/shape/dtype、
  200 Hz physics/50 Hz control 与传感器时序、768 维 observation 分段和历史初始化、
  `8×18×32` 深度历史及相机内外参/裁剪/滤波/索引、29 维动作 scale/offset/clip、PD/力矩/
  速度限制、MuJoCo↔policy 关节映射和方向、canonical MJCF/mesh 哈希以及 golden vector。
  stand/parkour 调换、任意模型重签 manifest、scene 或 mesh 字节变化均会在启动前拒绝。
- native runtime 批准面：正式路径拒绝环境变量替换 wrapper；批准的 MuJoCo C ABI SHA-256
  为 `72ce5e11f6ca29501fbce58c96d99ff210cc8c14a12f3f8d60a99a8d07db17b9`，ONNX C ABI
  为 `830a52a45696a29378fd58aa220f7d2b97fe2574e660bf9662eaff71bc7912c3`，20 个 `ldd`
  依赖构成的闭包指纹为
  `fa6c044b504714e40601f9e2448eedf48f97953731e2da2b3a1b2885872fa018`。父 launcher、
  direct 子进程和验收器都会复核；`libstl_decoder.so` 作为精确 `DT_NEEDED` 依赖进入闭包，
  不再扫描 `MUJOCO_PLUGIN_DIR`。该批准面绑定当前主机/构建，依赖升级后必须重新验收。
- backend 与 task 拆分：新增通用 MuJoCo C ABI v2、Python direct wrapper、raw depth renderer、
  独立 ONNX Runtime C ABI，以及 task 侧 `contract/observation/depth/action/inference/direct`
  和闭环 runner；先以固定姿态命令独立验收 backend 的 load/reset/PD/step，再按
  `state → obs768 → depth latent128 → actor input896 → raw action29 → q_target29 → PD torque`
  搬出算法。reset 会清空时间、控制相位与任务历史；状态时间戳、四元数 `xyzw`、200/50 Hz
  计数和重复 reset 均成为可测试契约。正式 source bootstrap 固定当前 checkout，并从子进程
  环境清除 `PYTHONPATH/PYTHONHOME/LD_AUDIT/LD_LIBRARY_PATH/LD_PRELOAD/MUJOCO_PLUGIN_DIR`。
- 调度与凭证：Hiking registry 现在声明 adapter factory、默认 scene、所需策略角色、可用
  backend 和 capability；`labctl check/sim2sim --backend mujoco` 组合 task-owned direct
  路径，只有显式 `--backend mujoco-oracle` 才调用旧单体。新增 stand/two-step/stairs 等任务
  acceptance，并把命令、预检、backend summary、source commit/status、运行指标和摘要哈希
  写入 `runs/deployment/`；backend exit 0 但任务验收失败会返回 3。原先断言 MuJoCo bridge
  必须失败的 workflow 测试已替换为正向 registry/backend 契约测试。
- 数值验证：no-ROS native CTest 最终 `14/14` 通过；Python/Isaac 全仓测试最终 `139/139`
  通过，另有 7 个默认关闭的真实资产/图形 opt-in 正常 skip。显式 opt-in 的真实
  `G1DepthCamera` 40 帧跨实现预处理、三帧 oracle/task 全链路追踪和真实 ONNX golden 共
  `3/3` 通过，所有指定中间量误差均不超过 `1e-4`；40 帧测试覆盖首帧 repeat、37 帧完整
  历史和填满后的连续滚动。真实 raw-depth 图形 CTest `1/1`、Python direct backend 真实
  深度测试 `4/4` 通过；错误 hash/shape/角色、模型维度/关节、时间戳/四元数、单步 PD、
  summary tamper、重复 reset 和异常清理均有拒绝或回归覆盖。
- 最终正式自检（五份 receipt 的 source 均为干净提交 `bba0245c2d7d29d3c5fec742f31669c1e555fa9a`）：
  direct stand 30 秒位于 `runs/deployment/20260921_084404_363178`，完成 1500 次控制/
  6000 次 physics、水平漂移约 `0.0124 m`，验收通过；direct 真实深度 stairs 8 秒位于
  `runs/deployment/20260921_084437_073622`，完成 400/1600 次控制/physics、100 次 stand
  warmup、300 次 parkour 推理和 300 帧真实深度，root 从 canonical 起点到
  `[3.439318, 0.191218, 1.223986]`，位移约 `[3.439318, 0.191218, 0.323986]`，无基座
  稳定器并通过 stairs acceptance；oracle 同场景对照位于
  `runs/deployment/20260921_084518_749621`，终点 `[3.431443, 0.193966, 1.219928]`；oracle
  两步回归位于 `runs/deployment/20260921_084538_251133`，记录 2 次落脚、前进
  `0.310335 m`；短 viewer 生命周期位于 `runs/deployment/20260921_084601_684553`，正常
  启动并清理。五份 canonical summary SHA-256 依次为
  `5dcfd344a721c62ddd25dfe1b19c3063e050f87713ca1d13fa0103a6c25af828`、
  `2321b3a6ec49d1a8ef9f43f09a629d5db6a3712f63bb2798524a0fe0c33790c8`、
  `c96eea63bd1ab19322f487d6098a3bb98e3a3cde25c3a2eedd30d3520db0200c`、
  `9445b65b9bada1618befb1bebd8f37acb6beb9a95f340df7f6b93d19433d73d5`、
  `1363416463c15c086a50306e3dd9035bd3690b437b68c95c1171f6a1d3741b31`。
- 未通过、修正与重试：移除通用 plugin 扫描后的第一次 CTest 有 3 项因 MuJoCo 3.6 无法
  解码 STL 失败，随后把确切 decoder 作为链接依赖并纳入批准闭包，重跑 `14/14` 通过；
  无有效 `DISPLAY` 的 parkour 真实深度预检按预期拒绝，配置图形环境后通过。首次在干净
  Isaac Python 中执行 help 因顶层 eager 导入 YAML 失败，改为轻量 registry 元数据和延迟
  导入后解决；另一次全量测试因测试 patch 旧 direct CLI 符号出现 3 个错误，增加延迟代理
  后最终 `139/139`。系统 Python 缺 YAML/Torch、Isaac PATH 引发的 `_sre` 版本冲突均通过
  使用项目指定解释器和干净 PATH 纠正。可选 ROS startup-pose 路径在新旧二进制中都曾
  exit 139，因此正式产物保持 ROS OFF，未将该可选路径写成通过。旧的 `071917/071954/
  072020` 运行以及无 display 失败的 `072148` 均为加固前或失败证据，不作为最终验收；
  display 重试 `072220` 仅是阶段性 oracle 两步证据。
- Git 与产物：最终实现提交为 `bba0245`（`feat(deployment): integrate Hiking direct
  MuJoCo sim2sim`），共 88 个跟踪文件、15434 行新增/385 行删除；提交后工作树无已跟踪
  修改。本轮没有 push、PR 或合并到 `dev`。正式本地 bundle manifest 位于
  `policy_bundles/hiking/deployment/manifest.yaml`，SHA-256 为
  `53c212fbc45e8c332ba9ee45f6bd29bed07318620d22b21734b187d407d3493a`；build、bundle、runs、
  cache 和外部 ONNX checkpoint 均保持忽略且未提交，旧 manifest 备份在
  `/tmp/ausim-hiking-manifest-pre-native-approval.yaml`。
- 回滚与边界：可在独立集成分支回退 `bba0245`，或回到 merge 基线 `3ca33e1`；原
  `refactor_train_layout`、`refactor_mujoco_g1` 和 `dev` 未改。viewer、two-step、synthetic
  depth 仍明确属于 `mujoco-oracle`；默认 direct 当前只承诺 headless 正式闭环，且真实深度
  即使 headless 仍需要可用 OpenGL display。后续若进入 SIM2REAL，必须另行完成硬件接口、
  急停/限幅、时延、传感器标定和实机安全验收，不能沿用本次 SIM2SIM 结论直接放行。

### 2026-09-21 15:14 — [ausim-rl] 增加 Hiking 原生/Python 三帧全链路数值追踪

- 状态：完成源码、构建与 opt-in 实测；三帧跨实现数值对比通过。
- 目的：在 Hiking SIM2SIM 迁移中以中间张量而非最终“能走”现象验证 C++ native
  oracle 与 Python task 的一致性，覆盖连续历史更新和 stand→parkour 模式切换，便于把
  误差准确定位到 observation、深度编码、actor 或动作映射边界。
- 项目路径：`/home/starry/isaac-data/ausim-rl`；项目没有独立 `WORK_LOG.md`。
- 涉及文件：更新
  `deployment/backends/mujoco/native/src/control/g1_onboard_policy.hpp/.cpp`、
  `deployment/backends/mujoco/native/CMakeLists.txt` 和
  `deployment/backends/mujoco/native/tests/g1_policy_smoke_test.cpp`；新增
  `deployment/backends/mujoco/native/tests/g1_policy_trace.cpp`、
  `tests/test_hiking_native_trace_parity.py`；更新本文件。
- 修改内容：为 `G1OnboardPolicy` 增加只读 `LastTrace()`，只复制最近一次成功 active
  policy step 的 `proprioception[768]`、selected depth `[8,18,32]`、latent `[128]`、
  actor input `[896]`、raw action `[29]` 和 native `q_target[29]`，reset 或模式切换即令
  旧 trace 失效，不参与控制计算；新增 `g1_policy_trace`，用两个连续 stand 帧和一个
  stand→parkour 帧驱动真实编译期 ONNX 策略，状态、命令和 selected depth 均为确定性
  非平凡值并输出 JSON；Python 测试以任务侧 observation/action 和独立 ONNX C ABI 重演
  三帧，包含切换时“清空 observation 历史但保留上一 raw action”的契约。
- 验证：在既有 no-ROS runtime build 中重新配置并构建 `g1_policy_trace`、
  `ausim_onnx_c_api` 和 `g1_policy_smoke_test` 成功；`ctest -R
  '^g1_policy_smoke_test$'` 为 `1/1` 通过。设置实际 trace executable、ONNX C ABI 和
  `/home/starry/isaac-data/hiking-in-the-wild_Data&Model/data&model/checkpoints` 后运行
  `tests.test_hiking_native_trace_parity`，`1/1` 通过；三帧的 state→obs768、selected
  depth、latent128、actor input896、raw action29、native q_target29 均满足绝对误差
  `<=1e-4`。清除三个 opt-in 环境变量后复跑，测试按设计报告 `OK (skipped=1)`。
- 影响与边界：只增加诊断快照、生成器和测试，不改变策略输入、ONNX 调用、历史更新、
  action scale 或 MuJoCo 控制结果；selected depth 的 raw 相机预处理仍由已有独立测试
  覆盖，本测试从确定性 selected depth 边界开始；未执行新的整机楼梯仿真。
- 回滚/备份：可移除新增 trace executable/Python 测试及 `LastTrace` 诊断成员，并回退
  CMake 和 smoke-test 对应增量；现有 `integrate_hiking_mujoco` 分支与迁移基线提交
  `3ca33e1` 保留。
- 后续事项：由主迁移任务继续执行全量 CTest、Python 测试及最终真实深度楼梯验收。

### 2026-09-20 16:47 — [论文审稿] 移除审稿汇总文档中的双星号标记

- 状态：完成。
- 目的：按用户截图反馈，移除 Markdown 中会以原始字符显示的双星号加粗标记，使正文保持纯文本标签并提升阅读观感。
- 项目路径：`/home/starry/isaac-data`；本任务无独立项目 `WORK_LOG.md`。
- 涉及文件：更新 `IoT-72783-2026_审稿意见汇总_12条.md`；更新本文件。
- 修改内容：机械移除审稿文档内全部 `**` 标记，保留标题层级、12 条意见正文、编号、公式、列表和单星号斜体不变。
- 验证：全文搜索确认 `**` 剩余数量为 0；12 个三级编号意见标题和 12 个“修改要求”标签均保留。
- 影响与边界：仅调整 Markdown 显示格式，不改变审稿结论、公式、页码或技术内容；原始 PDF 与用户附件未修改。
- 回滚/备份：可根据上一条 16:40 记录恢复加粗标记；无额外备份文件。
- 后续事项：无。

### 2026-09-20 16:40 — [论文审稿] 汇总 IoT-72783-2026 的 12 条审稿意见

- 状态：完成。
- 目的：将用户附件中的 6 条逐式密码学审计意见与对话中形成的 6 条综合审稿意见整理为一份可直接阅读、筛选和后续翻译的 Markdown 文档。
- 项目路径：`/home/starry/isaac-data`；本任务无独立项目 `WORK_LOG.md`。
- 涉及文件：新增 `IoT-72783-2026_审稿意见汇总_12条.md`；更新本文件。
- 修改内容：统一稿件信息、PDF 物理页码说明、12 条连续编号、LaTeX 公式、涉及位置和“修改要求”格式；将两组意见分别组织为“逐式密码学与协议专项审查”和“综合审稿意见”，对重叠主题增加交叉引用但不合并或删除；补充总体评价、建议决定及作者优先处理顺序。
- 验证：执行文本结构检查，确认文档包含且仅包含 12 个三级编号意见标题，所有主要公式均使用 Markdown 数学块，未执行论文协议代码、密码学证明或硬件实验。
- 影响与边界：仅新增审稿意见文档，不修改原始 PDF、用户附件、任何项目源码、配置或运行方式；审稿内容仍需作者根据正式投稿系统要求自行取舍。
- 回滚/备份：删除新增 Markdown 文件并移除本条日志即可回滚；原始 PDF 与附件未修改。
- 后续事项：如需提交，可进一步生成正式英文审稿报告或精简为 6 条不重复的主意见。

### 2026-09-20 13:42 — [课程演示] 交付“龙餐馆外交”PPTX与课堂讲稿

- 状态：完成 17 页可编辑 PPTX、19 页 DOCX 课堂讲稿、演讲者备注、课堂化文字优化和
  最终渲染复验；本轮交付文件为 `deliverables/龙餐馆外交_课堂演示_v3.pptx` 与
  `deliverables/龙餐馆外交_课堂讲稿.docx`。
- 目的：将已确认的 HTML 演示转换为能在 PowerPoint 中继续编辑的 16:9 课件，同时把
  资料型备注整理成可直接讲授的口语稿；用问题链、短投票和转场控制课堂节奏，使其适合
  中国高校“新时代中国特色社会主义理论与实践”课程的约 15–20 分钟讲授。
- 项目路径：`/home/starry/isaac-data/dragon-restaurant-diplomacy-html`；项目仍无独立
  `WORK_LOG.md`。本轮未修改用户附件 DOCX，也未发布或上传课件。
- 涉及文件：新增 `pptx-build/build_pptx.mjs`、`pptx-build/lecture_content.json`、
  `pptx-build/inspect_notes.mjs`、`docx-build/build_lecture_docx.py`、两份最终交付物和
  PPTX/DOCX 渲染检查目录；更新本文件。PPTX 的 v1、v2 为迭代中间版本，最终以 v3 为准。
- 内容与设计：按“电影情节—餐馆隐喻—《经济学人》批评—视频论证—共同尺度检验”重建
  17 页原生可编辑版式，保留电影公开宣发图和文章截图，梗图继续明确标注为“二创、非本人
  原话”。17 页均含建议时长、互动提示、现场讲稿、转场、原始材料/事实备查与来源；用户
  提供的 12 个视频时间戳及完整逐字内容均保留在演讲者备注。独立讲稿采用“互动提示—现场
  讲稿—转场—必要备查”结构，建议总时长 17 分 10 秒，完整逐字稿位置明确指向 PPT 备注。
- 课堂审阅修正：最终审阅后把第 1 页与第 3 页统一为“给交战双方都做饭，是中立还是已经
  站队”的开场问题，把“刺痛了谁”留到第 17 页回答；精简第 15–17 页口播、将史料校准移入
  备查，并修复 PPT 第 14 页孤立标点。保留第 10、12、17 页的核心互动，使结论从立场表态
  落到规则一致、发展结果、共同安全和自我约束四项检验。
- PPTX 验证：Artifact Tool finalizer 对最终 v3 报告 17 页、标准 13.3333×7.5 英寸画布，
  包完整性、几何布局、批准字体策略和首次回读均通过，0 findings、0 warnings；最终
  SHA-256 为 `4965907afa5e173bbd06cbb2750640c38ac6fd9ed18c778474befb0d0cfcb56f`。
  17 页全部渲染为 1600×900 PNG，越界检测通过；v3 未改动的 16 页与已逐页检查的 v2
  渲染逐字节一致，第 14 页重新目视确认。回读验证 17 页备注、现场讲稿/备查标记及
  `00:00` 至 `06:29` 的全部 12 个时间戳；PPTX 压缩包 CRC 检查无错误。
- DOCX 验证：最终文档为 Letter 竖版 19 页，含封面、使用说明/课堂主线和 17 页逐页讲稿；
  使用 Noto Serif/Sans CJK SC。经 LibreOffice 转为 PDF 后生成 19 张页面 PNG并逐页目视
  检查，无缺字、重叠、溢出或错误断页；PDF 为 19 页、612×792 pt，DOCX 压缩包 CRC
  检查无错误。
- 未通过/重试与边界：PPTX 首次 finalizer 调用被沙箱子进程权限阻止，第二次因未传入
  `RUNTIME_NODE_MODULES` 未完成；补齐打包运行时环境并授权本地校验后通过。DOCX 首次
  渲染因打包 LibreOffice/Poppler 需要 GLIBC 2.38、宿主只有 2.35 而失败；随后使用本机
  snap core24 动态加载器运行同一套打包二进制，重试并完成全部页面渲染。未在原生
  Microsoft PowerPoint/Word 中复验字体渲染，公开发布前仍需使用者确认电影宣发素材的
  授权范围。
- 回滚/备份：原 `index.html` 与 `assets/` 未被覆盖，仍可独立运行；可移除本轮
  `pptx-build/`、`docx-build/`、`qa-pptx*`、`qa-docx/` 和 `deliverables/` 中新增文件以
  回到纯 HTML 版本。

### 2026-09-20 12:44 — [ausim-rl] 清除 train 根目录平铺兼容文件

- 状态：根据 GitHub 目录截图的反馈，完成 `train/` 根部二次收口、集中兼容、
  测试、Git 提交与远程支线推送；只修改 `refactor_train_layout`，未修改、提交、
  推送或合并 `dev`。
- 目的：前一轮已将实现按职责移入分类子包，但 22 个 5–17 行的兼容 wrapper
  仍以 `train/*.py` 形式出现在 GitHub 页面，容易被误认为实现没有正常归类。本轮让
  `train/` 根部真正只保留 `__init__.py` 这一个 Python 文件，同时不破坏已发布的旧路径。
- 项目路径：`/home/starry/isaac-data/ausim-rl`；项目没有 `WORK_LOG.md`。修改基于
  `refactor_train_layout` 的 `d85770257cf4e0ddaecba547c9d91fdc674d7520`；本地
  `dev` 和 `origin/dev` 始终均为 `b93eeb9a1ce2564c9ab1ddb70a42d4b447fa2934`。
- 涉及文件：删除 `_env.py`、`_utils.py`、`amp.py`、`check.py`、
  `checkpoints.py`、`cli_args.py`、`config.py`、`evaluate.py`、`evaluation.py`、
  `export.py`、`export_contract.py`、`isaac.py`、`networks.py`、`onnxer.py`、`play.py`、
  `ppo.py`、`runner.py`、`setup.py`、`storage.py`、`tensorboard.py`、`train.py` 和
  `verify.py` 这 22 个根部兼容文件；新增 `train/runtime/legacy_imports.py`；更新
  `train/__init__.py`、仓内 launcher、恢复配置迁移、TensorBoard entry point、目录文档、
  测试和本文件。
- 修改内容：用一个仅使用 Python 标准库的、精确白名单 `MetaPathFinder` 延迟映射
  历史平铺模块到 `commands/`、`configs/`、`algorithms/`、`models/`、`runtime/`、
  `records/` 和 `export/`；只在真正导入旧模块时加载 canonical 实现，根包导入和
  `find_spec` 不加载 Torch、IsaacLab、ONNX Runtime 或命令模块。旧 `python -m
  ausim_rl.train.<command>` 通过同一集中机制转发；实体 `evaluation/` 和
  `export/` package 不拦截。仓内脚本和 console entry point 已全部改用 canonical
  路径；历史 `module:Class` 字符串在恢复时迁移到新模块名。
- 验证：IsaacSim Python 3.12 下全仓 unittest `31/31` 通过，包含 CPU PPO/AMP
  checkpoint roundtrip、保存配置迁移、固定 seed ActorCritic 精确输出、新目录白名单和
  旧/新对象 identity。旧/新 train、play、evaluate、export、tensorboard 共 10 个
  `--help` 均 exit 0，三个仓内 launcher 也均 exit 0；全量 compileall 和
  `git diff --check` 通过。wheel 从本轮源码构建成功，SHA-256 为
  `1a434418cca8c0d64b6d99844086d12b91446adcf9e2eee3091c172c4c5b1e58`，共 322 个条目；
  wheel 中 `train/` 根部只有 `__init__.py`，不含旧 wrapper，集中兼容文件、旧/新
  导入 identity 和旧/新 train/export 命令均从 wheel 直接复验通过。
- Git 结果：在 `refactor_train_layout` 上提交
  `0e29b2ea5972153ab6a300f4ec341a9f5015315d`，消息为
  `refactor(train): remove flat compatibility files`，并显式推送到远程同名支线。
  推送后使用 `ls-remote` 核对：远程 `refactor_train_layout` 为该提交，远程
  `dev` 仍为 `b93eeb9a1ce2564c9ab1ddb70a42d4b447fa2934`；本地 `dev` 与
  `origin/dev` 也未变。未创建或合并 PR。
- 未通过/未执行项：`check` 的旧/新入口仍一致报告当前环境未识别
  `isaacsim` distribution，且缺 Hiking 动作 YAML；`setup` 旧/新入口均保持环境
  检查失败，`verify --help` 旧/新入口均因缺 `--checkpoint` exit 1。这些是两组入口
  一致的既有前置条件，本轮没有声称真实 Isaac 训练/回放通过。
- 影响与边界：本轮不修改 PPO/AMP 数学、网络结构、checkpoint 字段、任务配置、
  Isaac 环境或 MuJoCo 后端；不产生新的根部业务实现。虚拟别名专为迁移保留，不会
  作为实体文件出现在 GitHub、`pkgutil.iter_modules()` 或 IDE 目录中。
- 回滚/备份：`dev` 本地与远程基线不变；在 `refactor_train_layout` 上回退本轮单一
  提交即可恢复平铺 wrapper，不会影响 `dev` 或 MuJoCo 支线。

### 2026-09-19 22:01 — [ausim-rl] 在独立支线完成 train 目录职责分层

- 状态：完成训练模块重组、兼容层、文档、测试、Git 提交与远端支线推送；没有修改、
  提交或推送 `dev`，没有创建或合并 PR。
- 目的：按已整理的 `task/` 风格降低原平铺 `train/` 的阅读和维护成本，把任务无关的
  训练框架按命令、配置、算法、模型、运行时、记录、评估和导出职责分类，同时继续支持
  历史 checkpoint、配置字符串、导入路径和命令入口。
- 项目路径：`/home/starry/isaac-data/ausim-rl`；项目没有 `WORK_LOG.md`。本轮从远端
  `dev` 的 `b93eeb9a1ce2564c9ab1ddb70a42d4b447fa2934` 建立
  `refactor_train_layout`，没有在先前 `refactor_mujoco_g1` 上叠加修改。
- 涉及文件：新增 `train/commands/`、`configs/`、`algorithms/`、`models/`、
  `runtime/`、`records/`、`evaluation/`、`export/`、`train/README.md` 和
  `tests/test_train_layout.py`；原 `train/*.py` 改为薄兼容入口；更新 `labctl.py`、任务
  默认配置导入、Isaac VecEnv 导入、`pyproject.toml`、根 README、两份架构文档、
  `train/UPSTREAM.md`、现有 workflow 测试和本文件。
- 修改内容：命令实现在 `commands/`，轻量默认值/CLI/保存配置恢复在 `configs/`，
  PPO/AMP 及拆开的 rollout/AMP storage 在 `algorithms/`，原 1265 行 `networks.py`
  按 layer、normalizer、encoder、actor-critic、discriminator、factory 和工具拆入
  `models/`，runner/VecEnv/Isaac/观测工具进入 `runtime/`；checkpoint 和源码状态进入
  `records/`。仓库内部全部改用 canonical 分类路径；旧 `train.ppo`、`networks`、
  `runner`、`config` 等导入和旧 `python -m ausim_rl.train.<command>` 继续转发到同一
  对象/命令。`train/export.py` 与新 package 同名的特殊情况由
  `train/export/__main__.py` 维持旧 `-m` 入口。训练、回放、verify 继续遵守
  AppLauncher 启动后才导入训练 runtime/算法的顺序。
- 兼容性结论：本轮不改 PPO/GAE/AMP 数学、模型参数创建顺序、`state_dict` 键、
  optimizer/checkpoint 字段、Hydra 恢复语义或任务超参数。独立基线对照确认 18 个旧
  定义的签名哈希一致；ActorCritic 与 EncoderMoEActorCritic 的固定 seed 权重摘要、
  参数顺序和输出逐项一致。旧/新 PPO、WasabiPPO、RolloutStorage、AmpStorage、
  ActorCritic、OnPolicyRunner、默认配置和恢复函数均为同一个 Python 对象。
- 验证：IsaacSim Python 3.12 / Torch `2.10.0+cu128` 下全仓无 GPU unittest
  `29/29` 通过，覆盖真实 CPU PPO+AMP 更新、checkpoint/optimizer/discriminator 恢复、
  GAE、PPO clipping、保存配置恢复、轻量导入和新目录契约；固定 seed ActorCritic 输出
  与拆分前逐 bit 相同。旧/新 train、play、evaluate、export、tensorboard 共 10 个
  `python -m ... --help` 均 exit 0；四个 train/play 入口确认 help 退出前没有加载
  `runtime.runner` 或 `algorithms`。全量 compileall、`git diff --check` 通过。最终 wheel
  构建成功，SHA-256 为
  `dcf5a3761287df0910a874024713965919af80f29ddce92d932d90624a100639`，含 343 个条目，
  新分类文件、训练 README、旧/新对象 identity 均从 wheel 直接验证通过；train CLI
  按项目原设计需要设置 `AUSIM_ROOT`，设置后旧/新入口帮助均通过。
- 未通过/未执行项：`labctl check --task hiking` 仍报告当前环境不能识别基础依赖
  `isaacsim`，且仓内缺
  `data/hiking/data&model/parkour_motion_reference/parkour_motion_without_run.yaml`；因此本轮
  没有声称真实 Isaac 有限步训练/回放通过。当前 Python 也没有 `onnxruntime`，只验证
  了 ONNX 旧/新接口 identity，没有执行 ONNX 推理。旧/新 verify 的 `--help` 都保持
  既有“缺 `--checkpoint`”退出 1 行为，未启动仿真。
- Git 结果：提交 `d85770257cf4e0ddaecba547c9d91fdc674d7520`，消息为
  `refactor(train): organize modules by responsibility`；远端
  `refs/heads/refactor_train_layout` 已指向该提交。首次普通推送因受限 DNS 失败，授权后
  默认 SSH 22 又因无 `github.com` host 条目失败；随后复用本机已有 GitHub 专用密钥和
  已保存的 `ssh.github.com:443` 官方 Ed25519 host key 完成认证及推送，没有写入新密钥
  或改远端 URL。最终只读核对远端 `dev` 仍为
  `b93eeb9a1ce2564c9ab1ddb70a42d4b447fa2934`，`refactor_mujoco_g1` 仍为
  `5f4c8ae81e4981a2b244a7a439cc7caf70c1aedc`。
- 影响与边界：提交共 77 个文件，Git rename/copy 检测后为 2165 行新增、4821 行删除；
  没有提交 checkpoint、ONNX、训练数据、日志、构建产物或凭据。旧 flat 文件暂不删除，
  它们是明确的迁移兼容面；任务环境、奖励、观测和地形仍归 `task/<name>/`，训练框架不
  反向吸收 Hiking 专属实现。
- 回滚/备份：`dev` 本地和远端均未改变，Git 支线本身即隔离备份；可删除
  `refactor_train_layout`，或在该支线上回退 `d857702`，不会影响主线与 MuJoCo 支线。
- 后续事项：管理员审核后可从 `refactor_train_layout` 向 `dev` 创建 PR；真实训练验收
  前需恢复可识别的 IsaacSim 环境和 Hiking 动作数据，再做有限步 train/resume/play。

### 2026-09-19 21:51 — [课程演示] 按电影叙事重构“龙餐馆外交”HTML PPT

- 状态：完成 17 页 HTML 演示重构、完整视频逐字稿讲者备注、电影宣发图替换、事实
  校准和浏览器逐页复验；本轮仍不生成 PPTX。
- 目的：落实用户指定标题《“龙餐馆外交”刺痛了谁——一顿饭背后的两种国际秩序
  逻辑》，先讲《欢迎来龙餐馆》剧情，再展示《经济学人》批评页面，继而沿视频问答
  剖析“保留什么、改革什么、如何避免新霸权”的国际秩序问题，用于约 15–20 分钟的
  “新时代中国特色社会主义理论与实践”课程讲授。
- 项目路径：`/home/starry/isaac-data/dragon-restaurant-diplomacy-html`；项目仍无独立
  `WORK_LOG.md`。
- 涉及文件：重写 `index.html`；在 `assets/` 增加并整理《欢迎来龙餐馆》公开宣发
  海报/剧照、《经济学人》文章转载页截图和张维为节目截图等本地素材；更新本文件。
  用户附件 DOCX 未修改。
- 修改内容：将原 13 页扩为 17 页，建立“电影情节—餐馆隐喻—媒体批评—责任边界—
  两种秩序逻辑—四项检验”的叙事；封面和绝大多数页面改用电影官方公开宣发素材，
  第 4 页直接呈现带《经济学人》署名的转载页面截图，第 13 页加入明确标注为非原话的
  张维为节目梗图。把用户提供的 00:00、00:17、00:47、01:57、02:35、03:10、
  03:53、04:52、05:10、05:42、05:47、06:29 全部视频文本逐段收入第 7–16 页讲者
  备注，并保留页面时码。新增 `N` 备注、`B` 文献、`O` 总览、方向键翻页和 `F` 全屏；
  每页保留来源脚注与 15 条集中参考文献。
- 事实校准：区分 RCEP 与中国—东盟自贸区；说明“中国约 30%＋东盟约 10%”不可跨
  年份/口径机械相加；把“阿拉伯之春”死亡与难民数字拆分为可核口径；补充 NAFTA 已
  被 USMCA 取代、美国退出 TPP 后其余成员实施 CPTPP；限定北约名言的历史出处；将
  “第三次世界大战”“弱 100 倍”“成年人”等标为反事实修辞或嘉宾转述；按 2026 年
  8 月公开口径把全球发展倡议更新为 1800 多个项目。
- 验证：用打包浏览器在 1600×900 视口检查 17 页截图并修正两处标题断行；自动边界
  审计未发现可见文本越出舞台；18 个页面图片节点均完整加载且自然尺寸有效；全部 12
  个视频时间戳均可在讲者备注中检索。实测备注面板能显示对应逐字稿，文献面板含 15
  条条目且可滚动，总览含 17 个缩略页，缩略页跳转与方向键翻页正确；控制台日志为空。
- 影响与边界：仅修改独立静态课程演示及其素材，不改变其他项目；未发布网页、未修改
  原始附件、未把电影情节或评论性判断伪装成新闻事实。HTML 仍需与 `assets/` 同目录
  携带；素材用于本地课堂演示，公开发布前需由使用者复核版权授权范围。
- 回滚/备份：可用前一版本记录中描述的 13 页结构与三张概念图恢复，或整体移除该独立
  演示目录；本轮未删除用户文件。
- 后续事项：用户确认 HTML 内容后，可继续转换为 PPTX，并按学校模板、授课者署名与
  最终课堂时长做第二轮排版。

### 2026-09-19 18:10 — [课程演示] 生成“龙餐馆外交”HTML互动PPT

- 状态：完成 13 页 HTML 演示、讲者备注、来源链接、概念视觉和逐页浏览器检查。
- 目的：依据用户提供的逐字稿与选题思路，为“新时代中国特色社会主义理论与实践”
  课程制作一套约 15–20 分钟、具有问题意识且能区分隐喻、媒体框架和政策事实的课堂
  演示；本轮先交付 HTML，不生成 PPTX。
- 项目路径：`/home/starry/isaac-data/dragon-restaurant-diplomacy-html`；新目录没有项目内
  `WORK_LOG.md`。
- 涉及文件：新增 `index.html`、`assets/hero.png`、`assets/round-table.png`、
  `assets/empty-chair.png`；更新 `HISTORY/PROJECT_INDEX.md` 和本文件。用户原始
  `/home/starry/文档/.../新建 Microsoft Word 文档.docx` 只读提取，未修改。
- 修改内容：采用 1600×900 固定舞台整体缩放，设计深夜蓝、琥珀、米白、玉绿和警示红
  的“桌面之上谈规则，桌面之下看力量”视觉系统；内容依次覆盖事件复盘、《经济学人》
  两面评价、三层证据边界、两种秩序逻辑、发展优先、国际体系改革、四大全球倡议、
  “发展和平”机制、东盟与沙伊和解/维和案例、四项压力测试及资料页。加入方向键/点击/
  触摸翻页、URL 深链接、进度条、`N` 讲者备注、`F` 全屏、`H` 帮助、打印导出和
  reduced-motion 支持；所有外部资料以可点击来源呈现。3 张 AI 生成概念图均在页面标注
  “仅作隐喻”，没有作为真实事件照片使用。
- 验证：使用打包浏览器在 1600×900 视口逐页检查 13 页，确认标题、正文、图片、脚注
  和结论均无可见重叠或越界；DOM 边界审计显示各页 `scrollWidth/clientWidth` 与
  `scrollHeight/clientHeight` 均为 `1600/1600`、`900/900`，字体状态 `loaded`；控制台
  无 warning/error；方向键、哈希定位、讲者备注和帮助面板通过。按实际截图修正了圆桌/
  空椅背景被样式优先级遮蔽的问题、东盟纠错句换行和脚注字号。附件 DOCX 的打包
  LibreOffice 渲染因宿主 `GLIBC/GLIBCXX` 版本低于运行库要求失败，已如实保留失败结论；
  随后用打包 Python 的 `python-docx` 成功提取全部 27 个非空段落和 0 个表格，用作内容
  比对，不把该失败写成通过。
- 影响与边界：新增的是独立静态演示目录，无外部 JavaScript/CSS 依赖，不改变无人机、
  ROS、Isaac 或其他项目；未修改原始 Word 文档，未发布到互联网，也未把电影情节、
  媒体评论或中方官方自述混写成第三方事实。HTML 需与 `assets/` 目录一同移动。
- 回滚/备份：删除新增演示目录并移除 `PROJECT_INDEX.md` 对应一行即可回到任务前状态；
  3 张生成图的原始副本仍保存在 Codex 生成图目录。本任务未执行删除或覆盖。
- 后续事项：用户确认内容与风格后，可在同一视觉体系下转换为正式 PPTX，或根据授课者
  信息、学校模板和现场时长继续精简。

### 2026-09-19 17:47 — [ausim-rl] 在独立 refactor 分支迁入 G1 MuJoCo 后端

- 状态：完成本地迁移、构建、仿真回归、Git 提交与远程支线推送；没有修改或推送
  `dev`，也没有创建或合并 PR。项目级 Python launcher 接线仍待后续完成。
- 目的：从私有仓库 `dev` 基线建立独立重构支线，把此前在 `ausim2-main/ausim_biped`
  完成的 G1 29DoF MuJoCo、ONNX、台阶、启动状态机和北通控制实现迁入
  `deployment/backends/mujoco`，同时固化用户图片所示分支/提交命名规则。
- 项目路径：`/home/starry/isaac-data/ausim-rl`；该项目没有 `WORK_LOG.md`。
- 涉及文件：新增 `CONTRIBUTING.md`、`deployment/backends/mujoco/README.md`、
  `deployment/backends/mujoco/native/` 全部源码/测试/场景/脚本/许可证及
  `tests/test_mujoco_native_backend.py`；更新根 `README.md`、`configs/upstreams.yaml`、
  旧 MuJoCo Python 骨架说明、`docs/`、`environments/`、`licenses/README.md` 和本文件。
- 修改内容：从 `dev` 提交
  `b93eeb9a1ce2564c9ab1ddb70a42d4b447fa2934` 创建 `refactor_mujoco_g1`；新增独立
  CMake 工程，支持 ROS2 Humble 遥控构建及 `AUSIM_G1_ENABLE_ROS2=OFF` stub 构建，
  支持 `MUJOCO_DIR`、`AUSIM_G1_POLICY_ROOT`、`AUSIM_G1_BUILD_DIR` 和可配置 ROS setup；
  迁入 29DoF 场景、200/50 Hz 控制、真实深度、三套关节顺序、仰躺 ColdStart、
  stand/parkour、北通映射、自动两步和四级台阶。场景复用仓内 84 个字节一致的 G1
  mesh，不重复提交网格；Hiking ONNX 因缺少明确再分发许可证继续由本机路径提供。
  保留 AGPL-3.0、InstinctMJ CC BY-NC 4.0 和 MuJoCo Apache-2.0 三类许可证边界；明确
  native 是源码树后端，不作为 Python wheel 数据或可重定位 CMake install bundle。
  新增 `refactor_<topic>`、`feat_<topic>`、`debug_<topic>` 及
  `type(scope): summary` 规则。
- Git 结果：提交
  `5f4c8ae81e4981a2b244a7a439cc7caf70c1aedc`，消息为
  `refactor(mujoco): migrate G1 simulation backend`；远程
  `refs/heads/refactor_mujoco_g1` 已指向该提交。推送后只读核对远程
  `refs/heads/dev` 仍为 `b93eeb9a1ce2564c9ab1ddb70a42d4b447fa2934`。
- 验证：首次完整 CMake 配置因 `target_link_libraries` keyword/plain signature 与
  `ament_target_dependencies` 混用失败，统一签名后修复；最终 ROS2 Humble 完整构建和
  ROS2 关闭构建均成功。新增 Python 迁移契约 4/4 通过；七个 C++ 程序全部通过：关节
  顺序、北通映射、启动状态机、stand/parkour ONNX finite、模型
  `nq=36/nv=35/nu=29`、四级台阶几何和仰躺启动姿态。仰躺测试在受限环境首次退出
  139，随后在桌面 OpenGL 环境通过：`root_z=0.0668332 m`、
  `phase=awaiting-upright`、ONNX 0 次。自动两步 8.005 秒检测两次落脚，最终
  `dx=0.3103 m`、`root_z=0.8189 m`、状态有限且直立；真实深度 parkour 以
  `0.5 m/s` 运行 8.005 秒，最终 `root=(3.4314,0.1940,1.2199) m`、300 次推理、
  状态有限且直立，达到 `0.40 m` 台阶顶面。两个 Shell 脚本语法及
  `git diff --cached --check` 通过。
- 未通过项：尝试运行全仓 Python unittest；系统 Python 缺 Torch/Hydra，现有
  `isaacsim` Conda Python 又缺 Torch/PyYAML，且仓库未安装时子进程无法导入
  `ausim_rl`，因此全仓套件未通过。本任务没有为迁移擅自安装或升级训练依赖；MuJoCo
  专项 Python/C++/闭环验证均已单独通过。
- 影响与边界：共提交 77 个文件，约 612 KiB；没有提交 ONNX、PT、NPZ、重复 mesh、
  MuJoCo 二进制、ROS overlay、构建产物或缓存。旧 `bridge.py`/`terrain.py` 仍明确标为
  legacy pending，`deployment_ready` 仍为 `false`；未运行 Unitree 真机，未验证 ROS2
  Jazzy，未将支线合入 `dev`。
- 回滚/备份：Git 支线本身即隔离版本；本地和远程可保留 `dev` 基线不动并删除
  `refactor_mujoco_g1`，或在该支线上回退上述单一提交。本任务未执行删除，原
  `ausim2-main` 源目录也未修改。
- 后续事项：管理员审核后从 `refactor_mujoco_g1` 向 `dev` 创建 PR；后续更改继续使用
  `refactor_/feat_/debug_` 支线和对应 conventional commit。另需完成项目级 native
  launcher/policy bundle 接线、Jazzy 复验和实体北通现场验收。

### 2026-09-19 15:29 — [ausim2] 固化 G1 当前实现与上游项目关系总览

- 状态：完成文档整理；本轮只修改说明文档，没有改变模型、策略、控制、场景或运行
  参数，也没有重新执行构建和仿真测试。
- 目的：把 InstinctMJ、InstinctLab、Hiking 官方网站与本地 Data&Model、
  `instinct_onboard`、Embrace Collisions 和 `ausim_biped` 的职责、数据流及边界集中写清，
  避免把训练框架、部署参考、复制资产和当前 MuJoCo 运行时混为一谈。
- 项目路径：`/home/starry/isaac-data/ausim2-main`；项目没有本地 `WORK_LOG.md`。
- 涉及文件：新增 `ausim_biped/CURRENT_IMPLEMENTATION.md`；更新
  `ausim_biped/README.md`、根 `README.md` 和本文件的导航/记录。
- 整理内容：采用“资产与仿真、策略与控制、任务与交互”三层划分；逐项注明上游内容是
  直接复制、运行时加载、参数对齐还是语义重写；记录 200/50 Hz 闭环、896→29 ONNX、
  三套关节顺序、真实深度、正式仰躺启动、北通映射、自动两步和四级楼梯的实现路径；
  单列当前历史验收与尚未实现/尚待现场验收内容；明确运行时直接加载四个 ONNX，
  `env.yaml` 只作为已固化参数契约的来源、当前不会在 C++ 启动时动态解析。
- 验证：人工核对文档所列本地文件、checkpoint、测试和备份路径存在；新增总览内的
  本地链接及本轮新增的两处 README 导航链接可解析。历史测试结果来自已有
  README/INTEGRATION_PLAN/CHANGELOG，本轮未重测，未将其写成本轮通过。
- 影响与边界：文档明确当前不是 Isaac Sim、InstinctMJ Python/mjlab 或 Unitree DDS
  运行时；自主倒地起身仍未接入，实体北通正式链和手柄上楼仍待用户现场验收。
- 回滚/备份：删除新增总览并恢复两处 README 导航和本条日志即可；文档修改未另建
  整项目备份。

### 2026-09-19 15:14 — [ausim2] 加入训练范围四级楼梯并完成真实深度自动上楼验收

- 状态：完成默认楼梯场景、专用几何/射线测试、构建、平地回归和真实深度自动上楼
  验收；实体北通手柄人工上楼仍待用户现场操作。
- 目的：在当前 G1 MuJoCo 场景中增加可供 Hiking parkour checkpoint 实际感知和碰撞的
  楼梯，供后续手柄控制上楼测试。
- 项目路径：`/home/starry/isaac-data/ausim2-main`；项目没有本地 `WORK_LOG.md`。
- 涉及文件：`assets/g1_29dof/scene.xml`、`ausim_biped/tests/g1_stair_scene_test.cpp`、
  `ausim_biped/CMakeLists.txt`、`ausim_biped/README.md`、`ausim_biped/INTEGRATION_PLAN.md`、
  根 `README.md` 和本文件。
- 修改内容：依据 InstinctLab 普通楼梯训练范围（级高 `0.05–0.23 m`、进深 `0.30 m`、
  楼梯命令 `0.45–0.8 m/s`），在 +X 前方 `1.20 m` 设置四级低难度上楼：每级
  `0.10 m` 高、`0.30 m` 深、净宽 `1.60 m`，顶面高 `0.40 m` 并延伸至
  `x=3.80 m`。各层显式使用地面摩擦 `1.0 0.005 0.0001`、碰撞位 `1/1` 和 group 0，
  避免继承默认 group 3 后被策略深度相机屏蔽。新增测试会核对四层位置/尺寸/摩擦/
  碰撞/group，并以 policy 可见组射线验证每个踏面确实可见；运行文档补充手柄上楼和
  到顶停车说明。
- 验证：仓内 clang-format 15 执行 `./format.sh` 成功；因新增 CMake target，首次直接
  构建提示无目标，执行 `cmake -S . -B build` 后恢复。专用测试首次编译因 MuJoCo 3.6
  `mj_ray` 新增 normal 参数失败，补 `nullptr` 后通过；首次直接加载 XML 又因测试未
  初始化 MuJoCo STL decoder 失败，改为先走正式 `G1Sim::Load()` 插件初始化后通过。
  `g1_stair_scene_test` 最终确认四级几何、碰撞和策略射线；`g1_model_smoke_test` 通过：
  `nq=36,nv=35,nu=29,t=5.005,root_z=0.793595`。仰躺测试在受限沙箱内退出 139，随后
  在授权桌面环境通过：`root_z=0.0668332`、`awaiting-upright`、ONNX 0 次。新场景自动
  两步回归通过：落脚 `2.475/2.795 s`，最终
  `root=(0.4318,0.0021,0.8195) m`、`dx=0.3103 m`、`dy=0.0315 m`。关键上楼测试使用
  真实深度相机、parkour ONNX、自由基座、`0.5 m/s`、无 balance assist，8.005 秒后
  `root=(3.4314,0.1940,1.2199) m`、最大力矩 `14.2960 Nm`、300 次推理、状态有限且
  直立，已到达 `0.40 m` 顶面。
- 影响与边界：默认 G1 场景现在始终包含上楼和顶面；固定两步在第一阶前结束，不受
  阻挡。未增加下楼、随机地形或碰撞侧墙，未改变 ONNX、关节映射、手柄按键、启动链、
  GetUp 或急停逻辑；本轮没有人工操作实体手柄，顶面末端后是 `0.40 m` 落差，手柄测试
  应在完整登顶后及时松开左摇杆。
- 回滚/备份：删除 `scene.xml` 中四个 `stair_level_*` geom，移除专用测试及其 CMake
  target，并恢复三份说明即可回到平地场景；本次未另建整项目备份。
- 后续事项：由用户完成仰躺→扶直→RB stand→LB parkour→左摇杆上楼的人工复核；随后
  再增加下楼、逐像素深度对比和接触/足底滑移日志。

### 2026-09-19 14:52 — [ausim2] 修复北通一键启动对 rg 的隐式依赖

- 状态：完成脚本修复、实体设备核验和限时 viewer/手柄启动冒烟测试。
- 目的：用户执行 `./run_g1_gamepad.sh` 时系统 PATH 中没有 `rg`，USB 属性校验管道
  失败并被错误报告为 `/dev/input/js0` 不是北通 vendor `20bc`。
- 项目路径：`/home/starry/isaac-data/ausim2-main`。
- 涉及文件：`run_g1_gamepad.sh`、`/home/starry/isaac-data/HISTORY/CHANGELOG.md`。
- 修改内容：将 USB vendor/model 校验、旧 G1 ROS 服务检测、旧 `joy_node` 检测和服务
  就绪轮询共 5 处 `rg -q` 替换为 Ubuntu 基础环境已有的 `grep -E`；匹配规则、设备
  路径、VID/PID 和拒绝条件保持不变，没有放宽手柄身份验证。
- 验证：`bash -n run_g1_gamepad.sh` 通过；检查脚本不再包含 `rg` 调用，并用模拟
  udev/ROS 文本验证五个正则的成功与拒绝路径。授权读取实体设备确认稳定链接指向
  `/dev/input/js0`，udev 为 `ID_VENDOR_ID=20bc`、`ID_MODEL_ID=511c`。首次限时启动被
  13:28 遗留的同项目 `run_g1_gamepad.sh -> joy_node` 保护性拒绝；确认该 `/joy` 无
  订阅者且无 G1/手柄控制配套进程后，仅中断其明确 PID 并等待 ROS 图清理。随后 10 秒
  冒烟测试成功越过 USB/ROS 预检，MuJoCo viewer、`g1_onboard_bridge`、`joy_node` 和
  `g1_betop_gamepad` 均启动，手柄被识别为 `BEITONG A2P3A BFM DONGLE`，ColdStart
  完成并进入等待人工扶直；测试超时后确认相关进程全部退出。未在本轮操作 RB/LB 或
  验收实际行走。
- 影响与边界：只修复启动脚本的命令可用性及误导性失败根因；机器人启动状态机、
  北通轴/按钮映射、L2/R2 保留策略、ONNX 和 MuJoCo 控制逻辑均未改变。
- 回滚/备份：恢复 `run_g1_gamepad.sh` 中 5 处 `grep -E ... >/dev/null` 为原 `rg -q`
  即可；本次为单文件最小兼容修复，未另建整项目备份。
- 后续事项：用户在桌面终端重新执行一键脚本，完成扶直、RB/LB 和实体摇杆操作；若仍
  失败，保存从第一行到失败行的完整输出以继续定位。

### 2026-09-19 14:34 — [ausim2] 核清官方倒地起身边界并释放 L2/R2 固件组合

- 状态：完成官方源码、分支、发布附件、论文与本地 checkpoint 审计；完成北通
  L2/R2 映射修正、格式化、构建及定向回归。当前 Hiking stand/parkour 继续可用，
  自主倒地起身尚未接入，原因是官方 Embrace Collisions 部署权重和命令数据未公开。
- 目的：响应用户对真实“倒地起身”能力和实体手柄额外急停设计的补充：优先寻找
  Project Instinct 原有实现，禁止把单独 L2/R2 抢占为 MuJoCo 急停，也禁止把现有
  Hiking stand actor 冒充起身策略。
- 项目路径：`/home/starry/isaac-data/ausim2-main`；项目不是 Git 仓库，没有项目内
  `WORK_LOG.md`。
- 修改前备份：
  `/home/starry/isaac-data/备份/ausim2-main_g1_gamepad_before_official_startup_20260919_135702`，
  快照内 710 个普通文件、约 133 MB，清单树 SHA-256 为
  `bbbc8e8702bb8e178a65e29cce5b57a514741cae5d04ba0f4f95ca623891a475`；另有
  `BACKUP_INFO.md` 记录范围、当时状态和恢复方法。
- 官方起身审计：Embrace Collisions 官网和论文确认 G1 存在 `Get up from ground`
  策略，方法是未来动作命令序列、Transformer encoder、本体历史、关节动作及专门
  extreme-action 数据；它与 Hiking 的 `896 -> 29` stand/parkour 网络不是同一接口。
  官网代码仍标为 `Code (Comming Soon)`，其仓库只有网页、论文和视频，无 checkpoint、
  ONNX、训练数据或部署 rosbag。官方 InstinctLab main 仅列出外部路径下的六个
  `fallAndGetUp` NPZ 和被注释的训练示例；Isaac Lab 3.0 迁移分支新增 fall-reset/
  curriculum/grace 基础设施但没有发布策略。InstinctMJ main 同样只有注释配置；官方
  Drive 的 `model_64000.pt` 属于 Deep Whole-body Parkour，不是起身。onboard 的
  `g1_track.py`/`TrackerAgent` 提供 ColdStart 到动作首帧、heading 对齐、名称映射和
  50 Hz 通用跟踪骨架，但所有公开分支均未附 get-up actor、normalizer 或动作 NPZ；
  ColdStart 本身仍只做关节插值。
- 策略 A/B 诊断：临时只读诊断程序在自由基座、无 assist 下运行。仰躺→ColdStart→
  直接 stand 15 秒/750 次推理始终未直立，最高根高度 `0.1022 m`，最终
  `root_z=0.0588 m`、倾角 `84.82°`；同一 actor 在模拟人工扶直后连续直立 15 秒，
  最终 `root_z=0.8156 m`、倾角 `0.53°`。诊断源码/可执行文件只位于 `/tmp`，未写入
  项目。由此保留 `AwaitingUpright` 安全门，未实现 free-root 瞬移、虚拟基座或 stand
  旁路。
- 手柄修正：`g1_betop_gamepad` 和旧 GUI YAML 不再把按钮 8/9 或扳机轴 4/5映射为
  急停；单独 L2、单独 R2、`L2+R2`、`L2+A`、`L2+B` 全部保留给真机固件。
  `Back+Start` 继续作为 MuJoCo 备用软件急停，未来独立硬件急停仍通过
  `/g1/emergency_stop` 接入。该项覆盖并取代 13:30 记录中的 `LT/RT→锁存急停` 映射，
  不改写当时历史记录。
- 涉及文件：修改 `ausim_biped/src/control/g1_betop_gamepad_mapping.{hpp,cpp}`、
  `src/g1_betop_gamepad_main.cpp`、`tests/g1_betop_gamepad_mapping_test.cpp`、
  `cfg/remote_control.yaml`、`run_g1_gamepad.sh`、`ausim_biped/README.md`、
  `ausim_biped/INTEGRATION_PLAN.md`、根 `README.md` 和本文件；备份目录新增
  `BACKUP_INFO.md`。未修改 InstinctLab、InstinctMJ 或 onboard 本地源码；官方仓库
  只克隆到 `/tmp` 进行只读审计。
- 构建/验证：使用仓内 clang-format 15 执行 `./format.sh` 成功；定向构建 `g1`、
  `g1_betop_gamepad` 及六个相关测试目标成功。`g1_betop_gamepad_mapping_test`、
  `g1_startup_state_machine_test`、`g1_joint_order_test`、`g1_policy_smoke_test`、
  `g1_model_smoke_test` 全部通过，模型结果仍为
  `nq=36,nv=35,nu=29,t=5.005 s,root_z=0.793595 m`。启动姿态测试在沙箱内因 GLFW
  显示初始化退出 139，随后在授权桌面环境复测通过：2 秒后
  `root_z=0.0668332 m`、`phase=awaiting-upright`、ONNX 推理数 0。`bash -n` 检查
  `run_g1_gamepad.sh` 通过。
- 影响与边界：当前可执行启动链仍是
  `仰躺→ColdStart→人工扶直门控→Stand→Parkour`；目标链明确预留为
  `仰躺零力矩→GetUp ColdStart/首帧→heading 对齐→独立 GetUp Tracker/动作命令→
  连续直立验收→Stand→Parkour`，并优先复用官方 `g1_track.py`/`TrackerAgent` 语义。
  在取得作者产物或按官方 shadowing 路线完成训练/导出前，不宣称已实现自主起身。
  本轮未运行或控制 Unitree 真机，未触发实体手柄按键。
- 回滚：从上述 13:57 快照恢复可回到“直立启动且 LT/RT 软件急停”的北通版本；恢复
  时复制到新目录并重新构建，不直接覆盖当前源码。若只回滚本轮手柄修正，则恢复
  mapping/YAML/节点/脚本及三份文档，并同步本记录。
- 后续事项：优先取得 Embrace Collisions 官方 get-up checkpoint、导出元数据和动作
  命令 rosbag；若仍未发布，则以 InstinctLab whole-body shadowing 与 fall-reset 课程
  训练独立 GetUp actor，分别验收仰卧/俯卧后再接状态机。

### 2026-09-19 13:30 — [ausim2] 备份自由基座两步版本并接入北通官网语义遥控

- 状态：完成源码快照、官网/设备审计、北通专用控制实现、构建、自动两步回归、合成
  手柄闭环、锁存急停，以及实体手柄中立、RB/LB、前进和回中检查；最终 viewer 与
  手柄节点保持运行，实体偏航和 LT/RT 仍待用户现场确认。未连接或控制 Unitree 真机。
- 目的：先固化 12:52 已通过的自由基座“两次落脚”版本，再在同一源码基础上按 Hiking
  in the Wild/`instinct_onboard` 的状态机与按键语义加入当前北通 A2P3A BFM 控制；正式
  链路不使用键盘、通用 GUI、虚拟基座或 `--balance-assist`。
- 项目路径：`/home/starry/isaac-data/ausim2-main`；项目不是 Git 仓库，且没有项目内
  `WORK_LOG.md`，因此使用目录快照和本统一日志记录版本。
- 备份：修改源码前创建
  `/home/starry/isaac-data/备份/ausim2-main_g1_two_step_before_gamepad_20260919_130306`，
  保留源码、配置、场景、模型资产、脚本、文档和第三方源码，排除可重建 `build/`、
  MuJoCo 日志和 Python 缓存；`rsync -anic --delete` 校验无差异，共 705 个文件、约
  133 MB。按相对路径排序的逐文件 SHA-256 清单树摘要为
  `3645210ab31d5d182d3d4c6e9eaf3406c2fd60eac5462d9dee8460ae361f3088`，范围和恢复方法
  见快照内 `BACKUP_INFO.md`。
- 官网审计：固定 `instinct_onboard` 提交
  `b6965a4202d8dceaf163dd95edb7742ed5d65e38`。实际状态顺序为
  `cold_start→R1/stand→L1/parkour`，parkour 中 R1 返回 stand；`L2` 或 `R2` 任一触发
  关电机退出。左摇杆 Y 控制前进、右摇杆 X 控制偏航，默认门槛 0.5、前进固定
  `0.5 m/s`、后退/横移为 0、偏航上限 `±1 rad/s`。官网 `2.5 m/s` 是成果速度，不是
  当前 walking checkpoint 的手柄设置。源码注释所称“方向键从 cold_start 直接进
  parkour”没有实际实现，本项目未照搬。
- 设备审计：`udevadm/evtest/joy_node` 确认设备为 `BEITONG A2P3A BFM DONGLE`，USB
  `20bc:511c`、稳定 by-id 指向 `/dev/input/js0`，8 轴 16 按钮；本机布局为左 Y 轴 1、
  右 X 轴 2、LB/RB 按钮 6/7、LT/RT 按钮 8/9并同时提供轴 4/5、Back/Start 10/11。
  独立话题和最终正式会话的中立样本均为四摇杆约 `-0.0039`、扳机轴 `+1`、全部按钮
  0。早先一次 `/joy` 读到 10/11 为 1，定位为同域旧发布器干扰；改用唯一重映射话题
  后复验正常，未把异常值写入映射。
- 涉及文件：新增 `run_g1_gamepad.sh`、
  `ausim_biped/src/control/g1_betop_gamepad_mapping.{hpp,cpp}`、
  `ausim_biped/src/g1_betop_gamepad_main.cpp`、
  `ausim_biped/tests/g1_betop_gamepad_mapping_test.cpp`；修改
  `ausim_biped/CMakeLists.txt`、`cfg/remote_control.yaml`、`src/main.cpp`、
  `src/control/g1_remote_control.{hpp,cpp}`、`src/sim/g1_sim.cpp`、
  `ausim_biped/README.md`、`INTEGRATION_PLAN.md`、根 `README.md` 和本文件；备份目录新增
  `BACKUP_INFO.md`。
- 实现：新增 50 Hz G1 专用 ROS2 手柄节点，按本机符号把左摇杆上推过半程映射为固定
  `0.5 m/s`，右摇杆水平半程外连续映射为 `±1 rad/s`；RB→stand、LB→parkour，LT 或
  RT→锁存急停，Back+Start 仅作为本项目备用急停。250 ms 手柄超时发布零速度，G1
  bridge 另有 250 ms 超时；拒绝非有限 Twist。模式与速度改为同一互斥快照，切换模式
  先清旧速度；启动前 2 仿真秒拒绝且不排队 parkour，急停后 RB/LB 无法重新上力，必须
  重启仿真。旧 G1 GUI YAML 同步肩键/扳机映射、0.5 门槛并禁用键盘。
- 一键入口：`run_g1_gamepad.sh` 先核验 by-id 与 `20bc:511c`、动态解析 `jsN`，确认无
  旧 G1 service 或 `joy_node` 后启动自由基座 viewer、`joy_node` 和专用节点；任一
  子进程或 viewer 结束即清理其余进程。正式命令为 `cd /home/starry/isaac-data/ausim2-main &&
  ./run_g1_gamepad.sh`。
- 构建/静态验证：首次 `./format.sh` 因系统无 clang-format 15 失败；随后只把
  `clang-format-15` 与 `libclang-cpp15` Debian 包下载并解压到 `/tmp`，以 v15.0.7
  成功格式化。首次 `./build.sh` 因系统未装 `libglfw3-dev` 且受限环境不能 sudo 失败；
  继续使用既有 `build/local_deps/{glfw,onnxruntime}` CMake cache，重新配置并完整编译
  100% 成功。`bash -n` 检查两个 G1 启动脚本通过。
- 可执行测试：`g1_betop_gamepad_mapping_test`、`g1_joint_order_test`、
  `g1_policy_smoke_test`、`g1_model_smoke_test` 全部通过；模型结果仍为
  `nq=36,nv=35,nu=29,t=5.005 s,root_z=0.793595 m`。自动两步真实深度回归保持
  `2.475/2.795 s` 两次落脚，最终
  `root_xyz=(0.4284,-0.0008,0.8199) m`、`dx=0.3138 m,dy=0.0286 m`，全部通过。
- 遥控动态验证：隔离 ROS 域使用单一合成 Joy 发布器，首次提前 LB 被明确拒绝；2 秒
  后重新 LB 成功，满前推行走后 RB 回 stand。真实深度自由基座运行 8.005 秒，最终
  `root_xyz=(0.7262,0.0331,0.8200) m`、`policy=stand`、有限且直立。另一隔离测试以
  合成 LT 触发急停，随后 stand service 返回 `success=false`；3.005 秒摘要为
  `max_torque=0 Nm, policy=emergency-stop`，无力矩倒地及 `upright=false` 是预期结果。
- 失败与纠错：无授权运行自动两步时 GLFW 初始化失败，授权桌面显示后通过。首次遥控
  动态测试使用 synthetic depth 且逐次启动多个 `ros2 topic pub`，命令到达过晚，机器人
  在 7 秒结束前倒地；该失败不作为控制验收。改用真实深度和单一发布器后获得上述通过
  结果。正式启动前发现上一轮遗留的旧 GUI `joy_node`，已向其准确 PID 发送正常终止，
  未删除数据。
- 交付运行态：最终 `./run_g1_gamepad.sh` 会话 `93269` 已打开 viewer；专用节点和
  `joy_node` 成功读取 `/dev/input/js0`，首条速度为零且 2 秒 stand 门控完成。随后实体
  `RB`/`LB` 分别得到 stand/parkour accepted，左摇杆产生 `0.5 m/s` 后回中为 0；没有
  软件注入这些正式会话输入。用户可继续操作，关闭 viewer 会结束整组进程。
- 影响与边界：本次只控制 MuJoCo 仿真；合成 Joy 已覆盖轴曲线、RB/LB 和 LT 锁存，
  实体会话已覆盖中立、RB/LB、前进和回中，但尚未实按右摇杆偏航或 LT/RT。平地前进
  通过不代表偏航、楼梯或复杂地形已验收；Unitree DDS、真机关节命令和真机电机均未
  接入。
- 回滚：停止当前 viewer 后，把备份内 `ausim2-main/` 复制到新的恢复目录并重新构建，
  不要直接覆盖当前工作；也可按上列文件逐项撤销。`build/` 可重建，不在备份中。
- 后续事项：由用户在当前 viewer 中轻推右摇杆确认偏航方向，最后在明确需要时短触
  LT/RT 验证锁存急停；之后再做 30 秒遥控行走、偏航稳定性和单级台阶。

### 2026-09-19 12:52 — [ausim2] 修复 G1 sim-to-sim 契约并通过自由基座自动两步验收

- 状态：完成平地“站立→前行两次落脚→恢复站立”闭环及重复验证；楼梯和复杂地形
  尚未验收。运行不使用键盘、手柄、ROS2 或虚拟基座/balance assist。
- 目的：处理用户观察到的 G1 不能正常站立/行走问题；重新核对 Hiking in the Wild
  官网、InstinctLab、InstinctMJ、发布 checkpoint 和 pinned `instinct_onboard`，先获得
  可重复的自由基座前行两步，并增加不干扰策略的地面参照。
- 项目路径：`/home/starry/isaac-data/ausim2-main`。项目内没有 `WORK_LOG.md` 或其他
  项目变更日志需要同步。
- 涉及文件：`assets/g1_29dof/scene.xml`、`assets/g1_29dof/NOTICE.md`、
  `ausim_biped/src/control/g1_pd_controller.cpp`、`g1_onboard_policy.cpp`、
  `ausim_biped/src/sim/g1_depth_camera.cpp`、`g1_sim.cpp`、`g1_sim.hpp`、
  `ausim_biped/src/main.cpp`、`ausim_biped/tests/g1_policy_smoke_test.cpp`、
  `ausim_biped/README.md`、`ausim_biped/INTEGRATION_PLAN.md`、根 `README.md` 和本文件。
- 上游审计结论：发布 ONNX 由 InstinctLab 训练，29 维输出确为 shoulder-first 顺序；
  当前按名称做 policy↔MuJoCo-native 的转换方向正确，不能改成 InstinctMJ-native，也
  不能把仅用于 Unitree 真机腰关节的符号应用到 MJCF。真正的不一致包括正式 parkour
  使用 `with_shoe` URDF、stand→parkour 动作历史、深度可见集合和预处理顺序。
- 模型与控制修正：左右脚各 7 个碰撞胶囊中心从 `z=-0.025` 下移到官方鞋底的
  `-0.048 m`；初始根高度从 `0.82` 改为 checkpoint 的 `0.9 m`；去除训练 URDF 没有的
  MJCF 被动 `damping=0.5/frictionloss=0.1`。动作 target 不再先夹到机械角度范围，保持
  `clip=null` 语义，只在 200 Hz PD 端执行官方 effort saturation，并由 MuJoCo 关节
  limit 负责物理限位。
- 策略/感知修正：模式切换不再把最后 raw action 清零，首次 parkour 的 8 帧 action
  history 由最后 stand action 填充；深度渲染明确只开 floor 与机器人 visual mesh，
  排除 torso 自身、collision primitive 和 viewer-only 标尺。预处理改为 metric depth
  先做 3×3 Gaussian/`REFLECT_101`，再 clip 到 2.5 m 并归一化，37 帧按训练的 50 Hz
  每 5 帧抽取 8 帧。
- 自动验收与场景：新增 `--two-step-demo`，固定执行 2 秒 stand、`[0.5,0,0]` parkour，
  检测两次左右交替落脚后切回 stand；落脚需要至少 50 ms 腾空和 10 ms 连续接触，
  最终还要求 `dx>0.2 m`、`|dy|<0.2 m`。地面新增红色起点、0.25/0.5/0.75/1/1.5/2 m
  刻度和 `y=±0.4 m` 车道线，均为无碰撞 group 4 且在策略相机中隐藏。
- 构建/静态验证：使用本地 clang-format 15 对修改的 C++ 格式化，并在 dry-run 确认
  全仓非 third-party C++ 均符合格式后运行 `./format.sh`；定向构建 `g1`、
  `g1_model_smoke_test`、`g1_joint_order_test`、`g1_policy_smoke_test` 成功。三项可执行
  测试均通过：29 关节映射哨兵、两套 ONNX 有限输出及切换 action 保留、
  `nq=36/nv=35/nu=29` 模型 5.005 秒积分。`ctest` 报告 `No tests were found`，因为
  这些现有 smoke 可执行程序尚未注册到 CTest；未把它记录成 CTest 通过。
- 动态验证：最终自动两步连续三次结果逐项一致；带防抖的最终复验落脚时间为
  `2.475/2.795 s`，6.005 秒结束时
  `root_xyz=(0.4284,-0.0008,0.8199) m`，步行段
  `dx=0.3138 m,dy=0.0286 m`，`finite/upright/two_step_complete=true`。自由基座 stand
  30.005 秒通过，`root_z=0.8091 m`；自由基座固定 0.5 m/s 前进 8.005 秒通过，
  `root_xyz=(3.4687,0.2077,0.8418) m`。以上策略深度测试均使用真实 OpenGL 渲染。
- 交付运行态：最终以 `./build/bin/g1 --viewer --two-step-demo --duration 0` 启动持续
  viewer（会话 `25509`）；终端确认两次有效落脚发生于 `2.475/2.795 s` 并已自动切回
  stand。窗口保持运行供用户观察红/黄/绿/蓝距离线及两侧横漂线，关闭窗口即可结束。
- 失败与纠错：修复前 synthetic depth 在约 3 秒倒地，真实深度在约 6 秒倒地并明显
  横漂；证明“ONNX 能推理”不等于观测契约正确。排查中曾把相机四元数和 Y 偏移按
  新版 IsaacLab 的 `xyzw` 工具结果临时改错，轴向检查显示视轴变为近水平侧向后立即
  恢复；最终相机为原先经验证的 MuJoCo/OpenGL 位姿。首次直接调用 `clang-format-15`
  因命令不在 PATH 失败，随后使用 `build/local_deps` 中的 v15 完成格式化。
- 影响与边界：默认关节映射没有改动；现有 ROS2/北通遥控接口继续保留，但本次验收
  不介入遥控。结果只覆盖平地、固定前进命令和两次落脚，不宣称楼梯、任意转向、
  30 秒连续行走或 Unitree 真机通过；`--balance-assist` 仍只作诊断。
- 回滚/备份：无独立备份。回滚时需把足底 `z` 恢复为 `-0.025`、root 恢复 `0.82`、
  default joint 恢复 `damping=0.5/frictionloss=0.1`，撤销深度 geom group/预处理与模式
  action 传递，并移除 `--two-step-demo`、接触计数和 group 4 标尺；上游原始 XML 仍在
  `assets/g1_29dof/xml/` 保持字节不变。
- 后续事项：保存同一帧做 Python/C++ 的 896 维 observation、128 维 latent、29 维
  raw action 逐元素比对；再做 30 秒连续前进/停止和单级台阶，最后接入预览楼梯。

### 2026-09-19 11:55 — [ausim2] 将 G1 遥控默认映射切换为已连接的北通 A2P3A

- 状态：完成配置修改与设备/ROS2 输入验证；未让机器人实际移动，避免在未由用户
  确认操作区域的情况下主动发送运动指令。
- 目的：让 G1 MuJoCo 遥控直接使用当前电脑连接的北通手柄，并用该设备的实际 Linux/
  ROS2 编号替换原先按通用 Xbox 布局填写的轴和按钮。
- 项目路径：`/home/starry/isaac-data/ausim2-main`；项目内没有 `WORK_LOG.md` 或其他
  项目变更日志需要同步。
- 涉及文件：`ausim_biped/cfg/remote_control.yaml`、`ausim_biped/README.md`、
  `ausim_biped/INTEGRATION_PLAN.md`、根 `README.md` 及本文件。
- 修改内容：确认设备为 `BEITONG A2P3A BFM DONGLE`（USB `20bc:511c`、`js0`、
  8 轴 16 按钮）；前进保持左摇杆 Y 轴 1，但把比例由 `+0.5` 改为 `-0.5` 以匹配
  SDL/ROS 竖轴方向；偏航由错误的右摇杆 Y 轴 3 改为右摇杆 X 轴 2，并使用 `-1.0`
  使摇杆左/右对应左/右转。动作按钮从通用假设改为设备实际编号：RB `5→7`、
  LB `4→6`、Back+Start `6+7→10+11`。键盘备用映射不变。
- 验证：`udevadm` 确认稳定 by-id 链接和 `20bc:511c`；`evtest` 只读确认
  `ABS_X/Y/Z/RZ/GAS/BRAKE/HAT0X/HAT0Y` 及 `BTN_TL=6`、`BTN_TR=7`、
  `BTN_SELECT=10`、`BTN_START=11` 的顺序；短时启动 ROS Humble `joy_node` 成功打开
  `BEITONG A2P3A BFM DONGLE`，一次 `/g1/beitong_probe` 消息为 8 轴、16 按钮且摇杆
  中位为 0。在隔离的 `ROS_DOMAIN_ID=77/78` 中加载修改后的配置，注入“左摇杆向上+
  右摇杆向右”得到 `/g1/cmd_vel linear.x=0.5, angular.z=-1.0`；注入按钮 7、6、
  10+11 后日志依次路由至 `/g1/stand`、`/g1/parkour`、`/g1/emergency_stop`。隔离域
  未启动这些服务端，因此日志中的 `service not ready` 是测试边界，不是映射失败。
  `run_g1_remote_control.sh` 的 `bash -n` 通过；本次仅改 YAML/文档，不需要重新编译。
  随后用 `--use-joy true` 启动实际 GUI（会话 `2425`），ROS 图显示 `/joy` 恰有
  `joy_node` 发布者和 `remote_control_node` 订阅者，现场采样为 8 轴/16 按钮且
  `/g1/cmd_vel` 为零；再启动 G1 viewer（会话 `27471`），bridge 收到首个零速度命令。
- 运行异常记录：检查上一任务留下的 viewer 会话 `16982` 时，它报告
  `Nan, Inf or huge value in QACC at DOF 0, Time=134.7550` 后结束；应用退出摘要仍为
  `finite=true, upright=true`。该会话在本次改映射前已长时间运行，且北通接入时命令为
  零，不能把异常归因于本次配置；本次已用新会话重启，但也不据此宣称长时间稳定。
- 影响与边界：仅改变 G1 专用遥控配置和相关说明；UAV/UGV 遥控配置、ONNX 策略、
  MuJoCo 动力学和 Unitree 真机接口均未改变。后退仍由 G1 bridge 限制为 0，横移仍禁用。
- 回滚/备份：无独立备份；恢复 YAML 的 `yaw: 3`、`linear.x: 0.5`、
  `angular.yaw: 1.0`、动作按钮 `[5]`/`[4]`/`[6,7]` 即可回到旧配置。
- 后续事项：由用户在 viewer 中低速确认实体摇杆方向与三组按键手感；自由基座 parkour
  稳定性问题仍按上一条计划继续处理。

### 2026-09-19 11:42 — [ausim2] 完成 G1 关节适配、ONNX 策略与 ROS2 遥控第二阶段

- 状态：第二阶段接口与可操作基线完成。自由基座 stand 策略通过；parkour 的 ONNX、
  真实深度和遥控链已运行，但无辅助 MuJoCo 动力学仍会倒地，因此不宣称无辅助
  sim-to-sim 行走通过。显式 `--balance-assist` 可用于当前遥控和动作可视化。
- 目的：把 `hiking-in-the-wild_Data&Model` 提供的 stand/stair checkpoint 接到 G1
  MuJoCo 模型，完成训练策略、MuJoCo 与 Unitree 真机三套关节顺序适配，并按
  `instinct_onboard` 的 20 ms 周期接入手柄/键盘遥控、模式切换和仿真急停。
- 项目路径：`/home/starry/isaac-data/ausim2-main`。模型来源为
  `/home/starry/isaac-data/hiking-in-the-wild_Data&Model/data&model/checkpoints`；继续沿用
  P0 记录中的三仓固定提交。项目内没有 `WORK_LOG.md` 或其他项目变更日志。
- 涉及文件：新增 `ausim_biped/src/control/g1_joint_order.*`、
  `g1_onboard_policy.*`、`g1_remote_control.*`、`src/sim/g1_depth_camera.*`、
  `tests/g1_joint_order_test.cpp`、`tests/g1_policy_smoke_test.cpp`、
  `ausim_biped/cfg/remote_control.yaml`、`run_g1_remote_control.sh`；修改
  `g1_pd_controller.*`、`g1_sim.*`、`src/main.cpp`、`ausim_biped/CMakeLists.txt`、
  `README.md`、`INTEGRATION_PLAN.md`、根 `README.md`、`build.sh`、
  `assets/g1_29dof/scene.xml` 及本文件。
- 关节与策略实现：以名称定义 MuJoCo native、旧 policy/onboard 和 Unitree real 三套
  29 关节顺序，提供 gather/scatter 和双向转换；真机三个腰关节符号仅保留给未来
  LowState/LowCmd 边界，当前 MJCF 不应用。读取两套 depth encoder
  `1×8×18×32 -> 128` 和 actor `896 -> 29`，按 checkpoint 构造六组 8 帧本体历史、
  29 维动作缩放和默认角，200 Hz 物理/PD 每 4 步执行一次 50 Hz ONNX。
- 感知与遥控实现：在 torso 增加按训练外参转换的 `policy_depth_camera`；MuJoCo 离屏
  深度经 `64×36 -> 32×18` 裁剪、3×3 Gaussian、0–2.5 m 归一化和 37→8 帧抽样后
  输入 encoder。新增 `/g1/cmd_vel`、`/g1/stand`、`/g1/parkour`、
  `/g1/emergency_stop`；速度 250 ms 超时清零，限制为前进 `[0,0.5] m/s`、横移 0、
  偏航 `[-1,1] rad/s`。急停会清零 29 个关节力矩并停用虚拟辅助。
- 运行方式：新增 `--policy stand|parkour`、`--remote`、`--cmd-forward`、`--cmd-yaw`、
  `--balance-assist` 和诊断用 `--synthetic-depth`；固定 parkour 命令先自动运行 stand
  2 秒。`run_g1_remote_control.sh` 启动专用 GUI，RB/T=stand、LB/G=parkour、
  Back+Start/X=急停。`build.sh` 现在显式检查 `ros-humble-onnxruntime-vendor`。
- 构建与静态验证：CMake 定向构建 `g1`、`g1_model_smoke_test`、
  `g1_joint_order_test`、`g1_policy_smoke_test` 成功；新增/修改的 biped C++ 已用
  clang-format 15 格式化，`build.sh` 与 `run_g1_remote_control.sh` 的 `bash -n` 通过。
  关节测试确认 29 个哨兵值三套顺序往返一致并与 onboard `joint_map` 精确相等；ONNX
  smoke 同时加载 stand/parkour 两套 actor/depth 并得到有限输出；模型 smoke 为
  `nq=36,nv=35,nu=29,t=5.005 s,root_z=0.775454 m`。
- 动力学结果：自由基座 stand 运行 5.005 秒后
  `root_xyz=(-0.0153,-0.0048,0.7976) m`、251 次推理、`upright=true`。自由基座 parkour
  采用真实深度、先站立 2 秒再以 0.5 m/s 运行，7.005 秒时
  `root_xyz=(0.8673,1.0891,0.1036) m`、`upright=false`，明确判定失败。显式辅助模式同样
  运行 7.005 秒，得到 `root_xyz=(3.4912,-1.5702,0.5221) m`、`upright=true`，说明动作
  链产生平面运动但仍有明显横漂，不能替代无辅助验收。
- ROS2 结果：在遥控发布端预先连接、站立约 2 秒后，`/g1/parkour` 返回 success，节点
  明确收到 `forward=0.500,yaw=0.000`；7.005 秒辅助闭环最终
  `root_xyz=(3.4962,-2.4877,0.5297) m`、`upright=true`。急停服务返回 success，最终
  `policy=emergency-stop`、`max_torque=0.0000 Nm`，机器人按无力矩预期倒地并由
  `upright=false` 报告，而非伪报运行成功。
- 交付运行态：最终以 `--viewer --duration 0 --policy stand --remote --balance-assist`
  启动持续 MuJoCo viewer（会话 `16982`），并以 `--use-joy false` 启动 G1 专用遥控
  GUI（会话 `1537`）；viewer 端已收到 GUI 的首个零速度消息，证明两端已连接。用户
  可在 GUI 使用 T/G/X 与 W/J/L；关闭两个窗口即可结束。
- 失败与环境边界：首次将真机腰部方向符号误用于 MJCF 后，stand 从稳定变为倒地；
  复验定位后已撤回，证明顺序映射与真机方向适配必须分层。无授权沙箱中的首次 GLFW
  初始化失败，授权桌面环境后真实深度通过；首次 ROS2 合成测试受沙箱 UDP 权限产生
  警告，授权后无该警告。一次 SciPy 辅助四元数计算因系统 NumPy 2.2.6 与 Ubuntu
  SciPy ABI 不兼容失败，随后按 IsaacLab 源码公式独立计算并由渲染运行验证。本机没有
  `/dev/input/js*`，未实测实体手柄轴号、方向或按钮；GUI 键盘及 ROS2 合成消息已测。
  G1 遥控脚本首次启动时因 ROS setup 在 `set -u` 下读取未定义变量而退出，已按仓内
  `build.sh` 的方式在 source 前后临时切换 nounset；第二次发现 ROS launch 不接受
  `--use-joy false` 原样参数，脚本已增加到 `use_joy:=false` 的转换并复验启动。
- 依赖与回滚：系统尚未安装 `ros-humble-onnxruntime-vendor` 和 `libglfw3-dev`；本次将
  ROS 官方 ONNX Runtime Debian 包解压到 `build/local_deps/onnxruntime`，继续使用 P0
  的用户态 GLFW/clang-format，未修改系统包。源码回滚需移除上述新增适配/策略/遥控/
  深度文件，恢复 biped CMake、PD/sim/main、场景、文档和 `build.sh`；
  `build/local_deps` 可直接重建。
- 后续事项：先完成 Python onboard 与 C++ 同状态下 896 维 observation、128 维 latent
  和 29 维 raw action 的逐元素比对，再对齐足底碰撞/鞋底、摩擦、质量惯量和求解器，
  以自由基座平地 30 秒为通过门槛；之后再加入楼梯。连接 Unitree DDS 真机需要另行
  明确授权、实体急停与现场安全措施。

### 2026-09-19 10:55 — [ausim2] 导入 G1 29DoF 并完成 MuJoCo 运行基线

- 状态：P0 模型与控制链路完成；headless、30 秒稳定性和官方 viewer 实际运行通过。
  训练后的行走/parkour 策略、深度感知和板端链路尚未接入，不宣称已完成自主行走。
- 目的：阅读 InstinctLab、InstinctMJ、instinct_onboard 后，在既有 `ausim_biped/`
  中先完成 Unitree G1 模型导入、29 关节控制和 MuJoCo 可视化运行，并固化后续
  sim-to-sim 兼容方案。
- 项目路径：`/home/starry/isaac-data/ausim2-main`。参考版本为 InstinctLab
  `de6b92f01eb155d51f30e8ed1ea7aecd2eb1f057`、InstinctMJ
  `6edbc19d4e386ba42ec8a0f8c705ec4a2f983ffb`、instinct_onboard
  `b6965a4202d8dceaf163dd95edb7742ed5d65e38`。
- 涉及文件：新增 `ausim_biped/CMakeLists.txt`、`README.md`、
  `INTEGRATION_PLAN.md`、`src/control/g1_pd_controller.*`、`src/sim/g1_sim.*`、
  `src/main.cpp`、`tests/g1_model_smoke_test.cpp`；新增 `assets/g1_29dof/` 下模型、
  84 个网格、派生场景、许可证和来源说明；修改项目根 `CMakeLists.txt`、`README.md`
  及本文件。项目内没有既有 `WORK_LOG.md` 或项目变更日志需要同步。
- 修改内容：保留字节一致的 InstinctMJ 上游 MJCF，SHA-256 为
  `4412cca99e549e70c00b98ef81749ebebc085209fe7b810baa76a97a4f6a1c67`；本地派生
  `scene.xml` 修正网格相对路径并增加地面、灯光、0.005 秒物理步长和 29 个力矩
  actuator。C++ 按名称校验 `nq=36/nv=35/nu=29`，使用 InstinctLab popsicle 初始
  姿态和 BeyondMimic armature/Kp/Kd/力矩上限运行 200 Hz PD。默认增加可显式关闭的
  虚拟基座稳定器，便于策略接入前检查模型；`--floating-base` 恢复真实自由基座。
- 兼容规划：文档固定三仓职责、MuJoCo 原生顺序与旧肩部优先顺序的双向 29 关节
  映射，以及 P1 actor ONNX、P2 200/50 Hz 双速率、P3 深度/parkour、P4 板端安全
  联调的顺序和验收边界。后续必须以实际 ONNX 导出配置判断是否重排，不能只凭仓库名。
- 验证：ROS overlay 三包构建成功；定向 CMake 构建 `g1` 和
  `g1_model_smoke_test` 成功；smoke test 运行 5.005 秒，`root_z=0.775454 m`；稳定
  模式 headless 运行 30.005 秒，`root_z=0.7600 m`、状态有限；官方 MuJoCo viewer
  实际启动并运行 2.005 秒，`root_z=0.7762 m`、正常退出。关闭稳定器运行 1 秒也能
  正常积分，`root_z=0.7385 m`；此前仅固定关节 PD 的 5 秒试验最终
  `root_z=0.0780 m`，确认没有平衡策略会倒地，因此没有把它误记为稳定站立。
  交付时另以 `--viewer --duration 0` 启动持续可视化，会话 `78211` 保持运行，用户
  关闭窗口即可结束。
- 失败与环境边界：首次派生场景使用 `<include>` 时，MuJoCo 3.6 将 mesh 路径解析到
  `xml/` 而加载失败；改为保留原件并生成直接可加载的派生 XML 后通过。系统缺少
  `libglfw3-dev` 且 `sudo` 需要用户密码，统一 `./build.sh` 在安装依赖阶段失败；本次
  只把 Ubuntu GLFW `.deb` 解压到 `build/local_deps` 完成构建，没有修改系统包。
  `./format.sh` 首次因缺少 clang-format 15 失败；随后同样以用户权限解压工具并只格式化
  新增 C++ 文件，避免改写其他现有源码。完整全目标构建未执行，不宣称通过。
- 影响与回滚：UAV、UGV、ROS2 话题和现有资产行为未修改；新增二足目标为
  `build/bin/g1`。回滚可移除根 CMake 的 `add_subdirectory(ausim_biped)`、删除
  `ausim_biped/` 和 `assets/g1_29dof/`，并还原根 README；`build/local_deps` 是可重建
  构建产物。资产受上游 CC BY-NC 4.0 约束，许可证和固定提交已随目录保留。
- 后续事项：需要用户提供或指定与训练配置匹配的 actor ONNX（parkour 还需 depth
  encoder/相机参数）后进入 P1；先做 Python/C++ 单状态输出对齐和关节映射回归，再关闭
  虚拟基座稳定器做 30 秒真实浮动基座闭环。真机接入须另行明确授权和现场安全条件。

### 2026-09-18 21:38 — [InstinctLab] 下载、适配并启动 Isaac Sim 6 的 G1 仿真

- 状态：G1 平地 locomotion 环境完成安装、300 步 GPU 无界面验证，并已在桌面启动
  Isaac Sim Kit 可视化窗口；其余需要额外数据或可选大依赖的任务未宣称通过。
- 目的：阅读 `project-instinct/InstinctLab`，把项目下载到本机，并在现有 Isaac Sim 中
  实际运行机器人仿真。
- 项目路径：`/home/starry/isaac-data/InstinctLab`；配套算法库
  `/home/starry/isaac-data/instinct_rl`；复用 `/home/starry/isaac-data/IsaacLab` 和
  `/home/starry/isaac-data/isaacsim`。
- 上游版本：InstinctLab `main@de6b92f01eb155d51f30e8ed1ea7aecd2eb1f057`；
  `instinct_rl@b1ee3f84983e10da385eafcd7da1f010e34f01ca`（v1.0.2，对应本机
  Torch 2.10/torchvision 0.25），后者保持 detached HEAD。项目覆盖 G1/H1 的
  locomotion、shadowing、perceptive、VAE、HOI、BeyondMimic 和 Parkour 等强化学习
  任务；本次选择无需外部动作数据的 `Instinct-Locomotion-Flat-G1-Play-v0` 做首个运行。
- 安装内容：使用 Isaac 自带 Python 3.12 以 editable、`--no-build-isolation --no-deps`
  安装 `instinctlab 0.1.0` 和 `instinct_rl 1.0.2`，避免上游依赖解析把本机可用的
  Torch/Isaac Lab 核心降级；补装 `pytorch_kinematics 0.10.0`、
  `arm_pytorch_utilities 0.5.0`、`pytorch-seed 0.2.0`、`joblib 1.6.0` 和
  `tabulate 0.10.0`。已有 `opencv-python-headless 4.13.0.90` 提供 `cv2`，但不满足
  上游对 `opencv-python` 包名的元数据检查。
- InstinctLab 兼容修改：将旧噪声类、PhysX tensors 模块路径、接触传感器导入、
  Python 3.12 `ClassVar`、Warp 类型注解和 Isaac Lab 已移除的 world-pose helper 适配到
  当前 API；延迟导入非 locomotion 传感器；增加 `INSTINCTLAB_TASK_BLACKLIST`，本次用
  `parkour,shadowing` 隔离未验证任务；G1 三个 URDF 配置关闭 Sim 6 分层/多物理转换，
  修正碰撞字段；新增 ProxyArray 到 Torch 的集中兼容助手并用于当前 locomotion 奖励；
  `play.py` 新增 `--max_steps` 便于有界验收。
- Isaac Lab 兼容修改：`sim/schemas/schemas.py` 的接触 API 激活在遇到刚体后继续遍历
  子节点，以覆盖 URDF Importer 3.0 生成的嵌套 G1 连杆；原代码只处理到
  `torso_link`，使终止项无法解析肩、肘、腕、髋和膝。
- 验证：RTX 5070、驱动 580.173.02 可用；任务枚举成功注册 G1 train/play 两个环境。
  最终无界面命令建立 1 个 CUDA 环境，解析 29 个关节、29 维动作、96 维 policy 观测、
  99 维 critic 观测、2 个终止项和 16 个奖励项，明确输出
  `Reached requested simulation limit: 300 steps` 后正常清理。随后用 `--viz kit` 启动
  可见 Isaac Sim，日志确认 Kit 可视化后端和完整环境完成设置；交付时进程会话
  `26147` 保持运行。
- 失败与边界：首次 editable 安装因隔离构建联网获取 setuptools 失败，改为
  `--no-build-isolation` 后成功；早期运行依次暴露旧导入路径、接触遍历和 ProxyArray
  差异，均保留失败事实并修复后复测。补装 `pyvista/scikit-learn/snakeviz` 时网络仅
  数十 KB/s，`pyvista` 下载未完成且后续还需大型 VTK，已主动中止；三包确认未安装。
  `pip check` 还报告 Isaac Sim 基础环境既有的 `aiobotocore/pyjwt` 缺失及
  `psutil/pillow` 版本冲突，本次没有擅自改动。Sim 6 接触视图仍打印嵌套路径的非致命
  警告，但 300 步实际运行通过。仓库没有随附 locomotion checkpoint，本次
  `--no_resume` 且前 300 步/可见运行使用零动作，只证明模型、环境和物理链可运行，
  不声称机器人已执行训练后的行走策略。
- 影响与回滚：InstinctLab 和 instinct_rl 是新增目录；前者所有本地兼容修改均可由
  Git 查看，后者工作树干净。IsaacLab 只有上述接触遍历一处本地源码修改。关闭当前
  Isaac Sim 窗口可结束仿真；若回退需分别恢复这些工作树修改，不能把新增目录或现有
  IsaacLab 整体当作普通缓存删除。
- 后续事项：如需展示稳定行走，需要提供或训练与当前配置一致的 checkpoint；如需
  Parkour/shadowing 等任务，再在网络条件允许时补齐 VTK/PyVista、scikit-learn、
  snakeviz 及对应动作/地形数据，并分别验证，不能沿用本次 locomotion 结论。

### 2026-09-18 19:54 — [EGO1P0] 从dev建立并推送ego1p0分支

- 状态：完成。
- 目的：按用户确认，在GitHub仓库`Chenwill1899/Fov-gvf`的`dev`主分支下建立独立
  `ego1p0`分支，并上传当前EGO1P0完整内容。
- 项目路径：`/home/starry/isaac-data/EGO1P0`。
- 涉及文件：项目本地Git元数据与配置、`EGO1P0/WORK_LOG.md`和本文件；项目外新增
  专用SSH密钥`/home/starry/.ssh/id_ed25519_codex_github`并向GitHub账号
  `dhmiaolovestar-hash`添加对应公钥。
- 修改内容：用户接受仓库协作者邀请后，将本地`ego1p0`重建为以远程
  `dev=804f26e2e631d0571f5e1cc5088100481df1b16d`为直接父节点的当前文件树快照；快照
  提交为`ff08e31f7c3cb97addeb05a2bb9f3f9f240b4dfe`。使用GitHub SSH 443端口创建并推送
  远程`ego1p0`，不改远程`dev`。
- 验证：22端口握手因当前网络超时，如实保留失败；改用官方`ssh.github.com:443`后
  身份验证成功。接受邀请前推送被GitHub拒绝；接受后`git push -u origin ego1p0`
  成功报告`[new branch] ego1p0 -> ego1p0`，本地建立远程跟踪。提交图核对为
  `ff08e31 -> 804f26e(dev)`；成功记录提交`6d4e577`也已再次推送，工作区干净。此次
  未重新运行构建/仿真；代码快照沿用
  2026-09-17已记录的构建、9/9 CTest和手柄动态验证。
- 影响与边界：只新增远程分支和专用SSH认证，不合并、不覆盖、不强推`dev`；
  `build/install/log`及缓存未纳入Git；未创建Pull Request。
- 回滚/备份：远程分支`ego1p0`和本地提交`ff08e31`构成备份；如需撤销，需另行明确
  授权删除远程分支和GitHub SSH公钥，本次不执行删除。
- 后续事项：远程HEAD核对完成；是否创建Pull Request由用户另行决定。

### 2026-09-18 19:16 — [EGO1P0] 初始化Git分支，远程推送等待认证

- 状态：部分完成；本地历史和提交已建立，GitHub推送被缺少认证阻塞。
- 目的：把当前EGO1P0版本保存到用户现有`Chenwill1899/Fov-gvf`仓库，同时保护远程
  `dev`分支。
- 项目路径：`/home/starry/isaac-data/EGO1P0`。
- 涉及文件：新增项目本地`.git/`元数据；更新`EGO1P0/WORK_LOG.md`、`EGO1P0/DONG.md`
  和本文件。
- 修改内容：以本机研究历史`d267feb`为父提交建立新分支`ego1p0`，配置远程
  `https://github.com/Chenwill1899/Fov-gvf.git`，提交当前源码、配置、场景、文档和
  性能记录，源码快照提交为`d02b140`。构建、安装、日志和缓存未纳入版本控制。
- 验证：远程检查只有`dev`且无同名分支；241个文件进入版本控制，最大有效文件约
  17 MB；秘密模式扫描未发现常见私钥、令牌或API密钥。首次HTTPS推送返回
  `could not read Username for 'https://github.com'`；随后确认没有`gh`、SSH私钥、
  Token环境变量或凭据助手，故未绕过认证，远程仓库未改变。
- 影响与边界：只建立Git版本元数据并清理两处文档行尾空格，没有修改算法、参数、
  场景行为或运行方式。
- 回滚/备份：本地提交`d02b140`是当前源码快照；删除EGO1P0内新建的`.git/`可撤销
  本地Git初始化，但不影响工作文件。远程无须回滚。
- 后续事项：用户在本机完成GitHub HTTPS或SSH认证后，重试
  `git push -u origin ego1p0`；成功后再补记远程分支与最终提交。

### 2026-09-17 14:44 — [EGO1P0] 修复右摇杆水平移动并恢复RViz点云密度

- 状态：完成根因修复、重新构建、9项测试和真实手柄动态联调；正式窗口保持运行供
  用户继续测试。
- 目的：修复右摇杆方向能在RViz显示、但无人机XY不移动的问题，并让RViz点云密度与
  `user/Fov-gvf/MISSANDKEYBOARD`基线一致。
- 项目路径：`/home/starry/isaac-data/EGO1P0`。
- 涉及文件：`scripts/isaac/prepare_uav_navigation_scene.py`、
  `scripts/isaac/run_fov_gvf_navigation.py`、两份重新生成的导航USD、
  `src/pc_gvf/include/pc_gvf/depth_angular_core.hpp`、
  `src/pc_gvf/src/depth_angular_core.cpp`、
  `src/pc_gvf/src/depth_angular_controller_node.cpp`、
  `src/pc_gvf/test/cpp/horizontal_360_check.cpp`、`EGO1P0_VERSION.md`、`DONG.md`、
  `USER_MANUAL_CONTROL_GUIDE.md`、自动追加的`performance/PERFORMANCE_METRICS.md`、
  `WORK_LOG.md`、`HISTORY/FOV_GVF_FAMILY.md`和本文件。
- 修改内容：诊断确认原四路120°广角会看到机体电机/桨叶，所选方向自由距离约为
  `-0.33~-0.35 m`，制动和rollout速度均为0；把四相机恢复为与原USER前向相机一致的
  90°水平FOV，四路中心仍为`0/+90/180/-90°`并拼接覆盖360°。每路分辨率由
  `160×120`恢复为`320×240`，使RViz使用的前向深度输入不再少75%像素；控制器角域
  相机模型同步为90°/68°。新增自由距离、制动限速、rollout限速及输入连接状态诊断，
  360°测试对精确45°拼接边界采用与运行时相同的内侧像素钳位。
- 验证：源RViz配置逐字节相同；两边launch的`depth_stride=4`、地图分辨率`0.08 m`、
  发布分辨率`0.25 m`、上限`160000`点一致。ROS三包重建成功。第一次测试命令因
  `--log-base`位置错误未运行；纠正后一次未隔离用户site-packages，出现NumPy/SciPy
  环境冲突且旧边界断言失败；完成边界测试修正并设置`PYTHONNOUSERSITE=1`后，
  `pc_gvf` 9/9 CTest通过，汇总16测试、0错误、0失败。正式运行
  `20260917_143846`识别北通8轴16按钮和四路`320×240`相机；右摇杆请求`2.000 m/s`时
  自由距离为正，发布速度达到`1.998 m/s`，无人机由`(-64.00,-11.20,2.80)`移动到
  `(-29.85,-28.66,4.84)`附近。历史地图已发布点数由约1922增长到52280。
  运行结束后重新启动最终窗口`20260917_144635`供用户测试，启动确认四路`320×240`；
  `ros2 topic info --verbose`确认`/pc_gvf/radar_points`当前唯一发布端与RViz订阅端均为
  `BEST_EFFORT/VOLATILE`兼容QoS。
- 影响与边界：修复的是水平感知几何与输入像素密度；未改变手柄轴映射、速度上限、
  RViz点大小、地图采样/体素参数或XY/Z控制语义。运行中靠近真实障碍时rollout仍会
  合理减速或停下；这不是手柄失效。尚未执行USB拔出停车的破坏式现场动作。
- 回滚/备份：恢复场景准备器120°和`160×120`并重新生成USD可回滚，但会复现机体
  自观察和稀疏点云；原USER/MISSANDKEYBOARD目录未修改，可作为基线。
- 后续事项：用户在当前正式窗口继续确认各方向手感、近障碍制动与回中停车。

### 2026-09-17 14:16 — [EGO1P0] 完整主入口默认改用北通手柄

- 状态：完成实现、静态检查、单元回归和5秒真实设备零输入联调；动态推杆避障待用户
  现场验收。
- 目的：使EGO1P0主启动命令像`user/Fov-gvf/MISSANDKEYBOARD`一样直接使用北通
  A2P3A Mode 2手柄，而不是仍默认键盘输入。
- 项目路径：`/home/starry/isaac-data/EGO1P0`。
- 涉及文件：`scripts/run_isaac_fov_gvf_navigation.sh`、
  `scripts/isaac/run_fov_gvf_navigation.py`、`USER_MANUAL_CONTROL_GUIDE.md`、
  `EGO1P0_VERSION.md`、`DONG.md`、`WORK_LOG.md`、自动追加的
  `performance/PERFORMANCE_METRICS.md`、`HISTORY/FOV_GVF_FAMILY.md`和本文件。
- 修改内容：主Shell入口和Python运行器的默认输入由`keyboard`改为`joystick`；默认
  启动前检查北通稳定by-id设备可读性，缺失时在ROS/Isaac启动前安全失败并给出键盘
  回退提示。显式设置`ISAAC_MANUAL_INPUT_MODE=keyboard`仍可使用原键位。手柄继续复用
  已有Yaw/Throttle/Roll/Pitch轴映射、0.08死区、0.5秒回中解锁、断连停车、水平归一化、
  机体到world转换与完整360°XY避障链。
- 验证：`bash -n`和`py_compile`通过；不存在设备路径的默认预检按预期返回1，显式
  keyboard模式绕过该检查；`test_manual_control_math.py` 4/4通过。主机真实北通设备
  5秒可见联调打印`mode=joystick scene_mode=cloud`，识别8轴16按钮、4路水平视角与
  Cloud ESDF，四轴零值并在0.5秒后解锁；303帧位置保持`(-64,-11.2,2.8)`、yaw=0、
  碰撞阻断0，超时后ROS节点干净退出；截图确认Cloud场景正常。
- 影响与边界：未修改FOV-GVF算法、话题、消息、场景或轴映射。联调未人工推杆，不能
  宣称真实运动方向、动态绕障、回中停车或USB断连停车已经验收。
- 回滚/备份：把两个默认输入值恢复为`keyboard`并移除Shell预检即可；当前可直接用
  显式环境变量回到键盘模式。
- 后续事项：用户现场推动四轴，逐项验收Pitch/Roll/Throttle/Yaw方向、360°动态避障、
  回中停车和USB断连停车。

### 2026-09-17 14:02 — [USER/MISSANDKEYBOARD] 修复启动后只有平地、看不到Cloud场景

- 状态：完成设置修正、5秒可见Isaac+ROS复测和截图验收；随后按用户要求正式启动。
- 目的：修复从`user/Fov-gvf/MISSANDKEYBOARD`执行组合入口后，没有显示预期4倍Cloud
  障碍场景的问题。
- 项目路径：`/home/starry/isaac-data/user/Fov-gvf`。
- 涉及文件：`MISSANDKEYBOARD/run_joystick_avoidance.sh`、
  `MISSANDKEYBOARD/README.md`、`USER_MANUAL_CONTROL_GUIDE.md`、`WORK_LOG.md`、
  自动追加的`performance/PERFORMANCE_METRICS.md`、`HISTORY/FOV_GVF_FAMILY.md`和本文件。
- 修改内容：组合入口不再被终端遗留的通用`FOV_GVF_SCENE_MODE/FOV_GVF_SCENE`、
  headless或实验显示参数覆盖；直接运行固定恢复4倍Cloud、可见窗口、
  MinimalRendering、TAA、Texture Diffuse、Sun 800、Dome 0、环境光0.05。需要平地或
  自定义USD时改用专用`MISSANDKEYBOARD_SCENE_MODE`或`MISSANDKEYBOARD_SCENE`，显示
  参数亦提供同前缀覆盖变量。
- 验证：Cloud USD与occupancy文件完整。修正前运行`20260917_135826`明确加载平地，
  截图只有白地和无人机。修正后故意传入残留flat USD、headless=1和另一渲染器，入口
  仍打印`cloud/MinimalRendering/headless=0`，识别北通8轴16按钮并加载4倍Cloud与
  0.40 m ESDF；`/tmp/user_miss_cloud_after_fix.png`清楚显示蓝色Cloud障碍、通道、地面
  和无人机。5秒零输入303帧位置不变、碰撞阻断0、ROS节点干净退出。未推动摇杆，未
  把该短测写成动态避障通过。
- 影响与边界：只改USER组合入口环境隔离和文档；通用USER平地入口、EGO1P0、算法、
  launch、USD/occupancy和手柄映射均未修改。
- 回滚/备份：未建副本；恢复旧环境继承行可回滚，但会重新出现场景串用风险。
- 后续事项：用户在正式窗口中现场操作手柄，验收动态绕障、回中停车和断连停车。

### 2026-09-17 10:25 — [EGO1P0] 四视角水平360°避障与XY/Z独立控制

- 状态：实现、构建、单元/算法回归和零输入Isaac联动通过；真实键盘/手柄动态绕障待
  用户现场操作验收。
- 目的：把原单前向约90°感知改为按期望XY方向工作的水平360°局部避障，同时将Z从
  水平FOV-GVF中彻底拆出，支持水平移动与升降同时输入且互不降速、互不清零。
- 项目路径：`/home/starry/isaac-data/EGO1P0`。
- 涉及文件：修改 `src/pc_gvf` 的角域核心、ROS控制器、launch、CMake和测试；修改
  `scripts/isaac/prepare_uav_navigation_scene.py`、`run_fov_gvf_navigation.py`，新增
  `manual_control_math.py`；重新生成平地和4倍Cloud导航USD；更新
  `USER_MANUAL_CONTROL_GUIDE.md`、`EGO1P0_VERSION.md`、`DONG.md`、
  `ISAAC_EGO_SWARM_CLOUD_NAVIGATION.md`、`MISSANDKEYBOARD/README.md`、项目工作日志及
  本文件。
- 修改内容：保留原前向相机路径及 `/sim/depth/*` 话题，新增左/后/右三路话题；四台
  120°相机中心位于机体系 `0/+90/180/-90°`，相邻视场重叠，按
  `atan2(desired_y,desired_x)`选择最近视角。角域核心新增水平专用模式，只允许图像
  中线上的水平导引，继续复用原碰撞锥、调和场、制动和rollout主体。键盘XY单独归一化
  到2 m/s，Z独立限幅到1 m/s；控制器只把XY送入避障，末端与原Z重新合成，纯升降不
  调用水平规划。仿真ESDF/AABB末端保护在组合位移碰撞时分别检查纯Z/纯XY，优先保留
  安全Z；它是紧急保护，不是三维规划。四路各160×120，总渲染像素量等于原单路
  320×240。
- 验证：Python语法检查通过；ROS 2 Humble下四包构建成功；`pc_gvf` 9/9测试通过，
  包括原有5项C++基准、2项既有Python测试、新增 `horizontal_360_check` 和
  `test_manual_control_math`。后者以表驱动覆盖需求列出的15种按键组合、XY/Z独立限幅
  与分量安全保护；C++新测试覆盖八个水平目标方向、四视角选择、各方向目标障碍偏转
  及全程零Z泄漏。OpenUSD变换检查确认四相机实际朝向为 `+X/+Y/-X/-Y`。首次受限
  沙箱联动因禁止创建ROS网络套接字失败，未算通过；获准在主机环境复跑后，Isaac可见
  窗口成功创建四路160×120深度RenderProduct，ROS控制器报告4 views，123帧零输入时
  位置保持 `(0,0,1.5)`、碰撞阻断0，并按2秒仿真超时干净退出。
- 影响与边界：未更改消息类型、前向话题、键位、命令桥或FOV-GVF主体；RViz现有深度
  图和历史地图仍显示前向兼容话题。水平360°不等于球面3D感知，上下盲区仍存在；本次
  自动联动没有注入物理按键，不能声称真实键盘/手柄15项动态飞行已经完成。
- 回滚/备份：未另建完整备份；EGO1P0是独立于主基线的实验目录，主基线未修改。
- 后续事项：在Cloud场景现场依次操作15组按键/摇杆，观察后/侧/对角障碍绕行、水平
  加升降并行、松键停车及上下方向末端保护。
- 后续修正：用户运行后反馈场景未正常出现。日志证明USD成功打开，但通用启动脚本沿用
  历史无障碍键盘测试默认值 `flat`，两次实际载入的都是平地且障碍数为0。现已把
  EGO1P0完整入口默认场景切换为4倍 `cloud`；`flat`仍可通过环境变量显式选择。

### 2026-09-17 09:35 — [EGO1P0] 从当前手柄避障基线建立独立目录分支

- 状态：完成目录分支、版本说明、独立构建和C++定向测试；未运行Isaac动态仿真。
- 目的：把`user/Fov-gvf`当前北通手柄+FOV-GVF避障实现作为主基线，建立名为
  `EGO1P0`的独立目录分支，并说明当前实现、使用平台及全部关键参数。
- 项目路径：主基线`/home/starry/isaac-data/user/Fov-gvf`；新分支
  `/home/starry/isaac-data/EGO1P0`。
- 涉及文件：复制主基线源码、配置、场景、脚本、文档和性能记录到新一级目录；新增
  `EGO1P0/EGO1P0_VERSION.md`；路径适配涉及EGO1P0中的构建/运行/场景生成脚本；更新
  `EGO1P0/WORK_LOG.md`、`HISTORY/PROJECT_INDEX.md`、`HISTORY/README.md`、
  `HISTORY/FOV_GVF_FAMILY.md`和本文件。
- 修改内容：算法源码、launch参数、北通映射、USD/occupancy、RViz、ROS话题和默认
  控制行为均保持不变。仅将运行脚本绝对项目根目录从`user/Fov-gvf`改为`EGO1P0`，
  colcon前缀改为`/tmp/fov_gvf_ego1p0_isaac_*`以隔离构建产物；旧的工程内
  `build/install/log`和Python缓存未复制。版本说明系统记录现有手柄输入、深度角域
  避障、安全链、话题、软硬件平台、Isaac/手柄/控制器/桥接/地图/RViz参数及运行方法。
- 验证：校验和dry-run确认除新增说明和预期路径适配文件外，其余复制文件一致；
  关键Python语法和全部Shell语法检查通过，执行脚本无旧项目根目录和旧colcon前缀
  残留。EGO1P0独立构建`pc_gvf_msgs`、`pc_gvf_platforms`、`pc_gvf`三包成功；C++
  `camera_geometry_check`、`depth_geometry_check`、`angular_field_check`、
  `motion_safety_check`、`guidance_composition_check`共5/5通过。未运行Isaac，不把静态
  复制和构建写成动态手柄绕障通过。
- 影响与边界：主基线算法/脚本未改；两个目录不会自动同步。EGO1P0保留域42和主锁，
  有意禁止与主基线并行运行。新分支仍是前向视场局部避障，不具备全局寻路。
- 回滚/备份：EGO1P0本身是2026-09-17快照；删除新目录及其独立`/tmp`构建产物即可
  回滚，主基线不受影响。
- 后续事项：用户现场验收四杆方向、动态绕障、回中停车和USB断连停车。

### 2026-09-12 12:10 — [USER/MISSANDKEYBOARD] 新增北通手柄 + 深度避障组合入口

- 状态：完成实现、静态验证和零输入组合联调；实际推杆与动态绕障待用户现场验收。
- 目的：保留 `KEYBOARD/` 作为无ROS手柄参考，同时在新目录中把北通 A2P3A Mode 2
  输入接入 USER 继承自 USER-EGO 的 FOV-GVF 运动避障链。
- 项目路径：`/home/starry/isaac-data/user/Fov-gvf`。
- 涉及文件：新增 `MISSANDKEYBOARD/beitong_joystick.py`、
  `MISSANDKEYBOARD/run_joystick_avoidance.sh`、`MISSANDKEYBOARD/README.md`；修改
  `scripts/isaac/run_fov_gvf_navigation.py`、`scripts/run_isaac_fov_gvf_navigation.sh`、
  `USER_MANUAL_CONTROL_GUIDE.md`、`DONG.md`、`WORK_LOG.md`、`HISTORY/README.md`、
  `HISTORY/FOV_GVF_FAMILY.md`、本文件；联调追加`performance/PERFORMANCE_METRICS.md`。
- 修改内容：新增默认关闭的 `ISAAC_MANUAL_INPUT_MODE=joystick`。北通映射为
  `Yaw=0, Throttle=1, Roll=2, Pitch=3`；Pitch/Roll按当前机头由机体系转换到world，
  与Throttle一起发布`/human_intent`，平移必须经C++ FOV-GVF和命令桥后执行；Yaw独立
  控制机头及前向相机。保留回中解锁、死区、USB断连全停，并把最终平移dead-man与
  Yaw活动拆开，防止只转向时复用旧平移命令。新组合脚本默认选择4倍Cloud场景，每次
  性能记录增加输入模式字段；原键盘默认入口不变。
- 验证：Python/Shell语法通过；Mode 2符号、平面归一化、机体到world转换、升降和偏航
  的纯Python检查通过。首次检查的测试期望遗漏既有的对角合速度归一化而断言失败，修正
  测试期望后通过。受限环境看不到USB，脚本按预期安全拒绝；主机权限下5秒可见
  Isaac+ROS组合联调成功识别北通8轴16按钮，加载4倍Cloud及0.40 m ESDF，确认
  `/position_cmd`单发布者，四杆回中0.5秒后解锁。303帧零输入期间无人机保持
  `(-64,-11.2,2.8)`且yaw为0、碰撞阻断0，随后`MANUAL_TIMEOUT`并干净退出，性能三段
  均写盘。未人工推杆，控制器为`ZERO_INTENT`、guidance为0，不能据此声称动态绕障通过。
- 影响与边界：`KEYBOARD/`未修改，仍为无ROS/避障直控参考；C++避障算法、launch、
  RViz、USER-EGO均未改。该入口只提供前向深度视场下的人工局部避障，不是全局规划。
- 回滚/备份：未建立完整备份；删除新目录并移除完整运行器中的joystick可选分支即可；
  原默认键盘分支在本次修改中始终保留。
- 后续事项：现场依次推动四杆确认方向，并在障碍前验收避障、回中停机和USB断连停机。

### 2026-09-12 11:50 — [USER/KEYBOARD] 切换为 BEITONG A2P3A 手柄映射

- 状态：完成设备识别、轴映射和空闲联调；实际推动四杆的方向待用户现场确认。
- 目的：适配用户新更换的北通 A2P3A BFM USB接收器，替换KEYBOARD独立入口原有的
  LiteRadio默认设备和轴编号。
- 项目路径：`/home/starry/isaac-data/user/Fov-gvf/KEYBOARD`。
- 涉及文件：`KEYBOARD/keyboard_only.py`、`KEYBOARD/run_joystick_only.sh`、
  `KEYBOARD/README.md`、`USER_MANUAL_CONTROL_GUIDE.md`、`DONG.md`、`WORK_LOG.md`、
  `HISTORY/README.md`、`HISTORY/FOV_GVF_FAMILY.md` 和本文件。
- 修改内容：默认设备改为
  `/dev/input/by-id/usb-BEITONG_BEITONG_A2P3A_BFM_DONGLE-joystick`。依据内核
  `JSIOCGAXMAP` 实测轴码，将Mode 2默认值设为 `Yaw=0, Throttle=1, Roll=2,
  Pitch=3`；轴4/5为Gas/Brake扳机、轴6/7为方向键，均不参与飞行。环境变量覆盖、
  回中解锁、断连停车、死区、速度、光照和参照物保持不变。
- 验证：只读确认USB `20bc:511c` 对应北通设备，名称
  `BEITONG BEITONG A2P3A BFM DONGLE`，8轴16按钮。初次按Xbox通用假设使用轴3/4
  作为右摇杆时，5 s联调读到静止Pitch `+1.00`，安全门按设计拒绝解锁、无人机未动；
  查轴码表确认轴4实际为Gas后改用轴2/3。最终5 s可见Isaac联调四通道均为0，0.5 s
  后正常解锁，301帧内位置保持 `(0,0,1.5)`。Python、Shell语法及KEYBOARD改动文件
  尾随空白检查通过；未人工推动摇杆，未把实际运动方向写成通过。
- 影响与边界：仅切换KEYBOARD无ROS/避障独立入口的默认硬件和轴编号；完整USER键盘
  避障入口与USER-EGO不变。
- 回滚/备份：未建完整备份；旧LiteRadio设备路径和映射保留在上一条历史中，亦可通过
  `JOYSTICK_DEVICE`、`JOYSTICK_AXIS_*`、`JOYSTICK_SIGN_*` 临时恢复或覆盖。
- 后续事项：用户现场依次推动左右摇杆确认四个方向；若只有方向相反，调整对应
  `JOYSTICK_SIGN_*`，无需再改轴编号。

### 2026-09-12 11:02 — [USER/KEYBOARD] 改为 LiteRadio Mode 2 手柄控制

- 状态：完成实现和设备空闲安全联调；四杆实际运动方向待用户现场验收。
- 目的：将 KEYBOARD 独立无避障入口从物理键盘改为 LiteRadio 3 USB 遥控器，并按
  多旋翼 Mode 2 方式控制升降、偏航、前后和横移。
- 项目路径：`/home/starry/isaac-data/user/Fov-gvf/KEYBOARD`。
- 涉及文件：`KEYBOARD/keyboard_only.py`、新增 `KEYBOARD/run_joystick_only.sh`、
  `KEYBOARD/run_keyboard_only.sh`、`KEYBOARD/README.md`、`USER_MANUAL_CONTROL_GUIDE.md`、
  `DONG.md`、`WORK_LOG.md`、`HISTORY/README.md`、`HISTORY/FOV_GVF_FAMILY.md` 和本文件。
- 修改内容：使用 Linux `/dev/input/js` 非阻塞API直接读取7轴/16按钮BETAFPV设备，绕开
  Isaac/GLFW缺少该设备映射的问题。默认轴0/1/2/3分别对应Roll/Pitch/Throttle/Yaw；
  Pitch/Roll 按机体系产生平移，Throttle 控制升降，Yaw 以最高 `75 deg/s` 单独旋转
  机头。水平/垂直最大速度为 `2.0/1.5 m/s`、死区 `0.08`；新增四杆回中0.5 s解锁、
  USB断连停车、通道实时终端输出及设备/轴/符号/速度环境变量。新主入口为
  `run_joystick_only.sh`，旧脚本仅作兼容包装。
- 验证：只读确认 USB `0483:572b` 已绑定 `/dev/input/js0`，名称
  `STMicroelectronics BETAFPV Joystick`，7轴、16按钮；Python、两个Shell脚本语法通过。
  5 s可见窗口联调运行301帧并正常退出；当时油门通道为 `+0.64`、其余三轴为0，安全
  回中门保持未解锁，无人机位置全程为 `(0,0,1.5)`，未发生非中位启动误动。未人工
  推动四杆，故不宣称实际正负方向已经验收。
- 影响与边界：仅改变 KEYBOARD 独立无ROS/避障链；完整 USER 仍使用键盘向FOV-GVF
  提供意图，USER-EGO自动导航不变；光照、地面参照和 `z>=0.25 m` 保护保留。
- 回滚/备份：未建完整备份；旧实现行为已保留于项目工作日志，兼容启动脚本未删除。
- 后续事项：将左摇杆油门置于中位，看到 `enabled=yes` 后逐项核对四杆；如固件输出
  顺序或方向不同，使用文档所列 `JOYSTICK_AXIS_*` 和 `JOYSTICK_SIGN_*` 调整。

### 2026-09-12 10:27 — [USER/KEYBOARD] 修正过曝并增加地面方向参照

- 状态：完成；显示已截图验收，真实物理按键仍待用户现场操作。
- 目的：解决 KEYBOARD 平地场景中无人机及地面大面积发白、无法清楚判断姿态、方向
  和位移的问题。
- 项目路径：`/home/starry/isaac-data/user/Fov-gvf/KEYBOARD`。
- 涉及文件：`KEYBOARD/keyboard_only.py`、`KEYBOARD/README.md`、`WORK_LOG.md` 和本文件。
- 修改内容：视口由 `MinimalRendering` 常量着色切换为 `RayTracedLighting`，关闭自动
  曝光；太阳光强度由 `800` 降至 `2.5`，环境光为 `0.01`。在出生点地面运行时创建
  无碰撞深色中心台、红绿坐标十字和四个固定方向块（`+X` 橙、`-X` 蓝、`+Y` 绿、
  `-Y` 品红），并增加可选 `KEYBOARD_SCREENSHOT` 截图参数。
- 验证：`python3 -m py_compile KEYBOARD/keyboard_only.py`、Bash 语法与尾随空白检查
  通过；四次可见窗口各运行约 4 s。第一轮 `MinimalRendering + 250` 以及随后
  `RayTracedLighting + 250/25` 的三次截图仍有明显裁白，因此继续调整；最终 `2.5`
  光强运行 241 帧并正常退出，截图
  `/tmp/keyboard_observation_final.png` 经人工查看确认机身、桨叶、阴影、坐标线及方向块
  层次清楚，饱和像素比例约 `0.066%`，SHA-256 为
  `3ee319f732436feb0b9c883f0c42ec583d350cd9e11b296656b6677a0219adef`。未注入物理按键。
- 影响与边界：仅影响 KEYBOARD 的观察画面和非物理参考 Prim；未改变键盘控制数学、
  速度、最低高度限制、ROS/避障链、完整 USER 入口和 USER-EGO。
- 回滚/备份：未复制完整备份；旧值和恢复方式已记录在项目 `WORK_LOG.md`，修改仅涉及
  两个文本文件，可按记录恢复。
- 后续事项：用户在主视口获得焦点后实际测试各方向键、组合键和升降。

### 2026-09-12 10:03 — [USER] 摘出不含避障的 KEYBOARD 独立控制测试

- 状态：完成；物理按键动作待用户现场验收。
- 目的：把键盘控制实现从完整 USER ROS/避障链中单独摘出，使测试结果只反映 Isaac
  物理按键读取、组合键归一化、停止和无人机直接运动。
- 项目路径：`/home/starry/isaac-data/user/Fov-gvf/KEYBOARD`。
- 涉及文件：新增 `KEYBOARD/run_keyboard_only.sh`、`KEYBOARD/keyboard_only.py`、
  `KEYBOARD/README.md`；更新 `USER_MANUAL_CONTROL_GUIDE.md`、`DONG.md`、
  `WORK_LOG.md`、`HISTORY/README.md`、`HISTORY/FOV_GVF_FAMILY.md` 和本文件。
- 修改内容：独立脚本直接用 Isaac `get_keyboard_value()` 每帧轮询
  `W/S/A/D/R/F`、方向键、Page Up/Down和Space；组合方向归一化后以默认2 m/s直接
  积分 `/World/Robot` 世界坐标位置，水平移动时平滑调整机头方向，并保留 `1/3/V`
  视角切换。明确不导入/启动ROS 2、不发布话题、不创建深度RenderProduct、不调用
  FOV-GVF、不加载ESDF、不启动RViz或在线地图。仅将最低高度钳制为机体半径0.25 m，
  防止测试时穿过 `z=0` 平地。
- 验证：Shell和Python语法检查通过；当前Isaac 6.0确认所有使用的键枚举存在；用
  `KEYBOARD_TEST_TIMEOUT=3 bash run_keyboard_only.sh` 完成可见窗口短测，终端明确打印
  `ROS=off avoidance=off ESDF=off depth-control=off`，第三人称视图成功绑定，运行181帧
  后按预设结束，无按键时位置严格保持 `(0,0,1.5)`。未启动ROS节点或避障进程。
- 影响与边界：新增独立测试入口，不替换、不调用也不修改原完整USER启动入口、C++
  避障、ROS/RViz配置或USER-EGO。自动测试不能可靠注入Isaac物理按键，因此尚不能
  声称按下、松开、组合键和Space已经人工验收。
- 回滚/备份：删除新增 `KEYBOARD/` 并移除对应文档新增段落即可；完整USER控制链没有
  被覆盖，无需恢复源码。
- 后续事项：用户点击Isaac主视口，观察终端 `[KEY STATE]`，依次验证单键、组合键、
  松键、Space和窗口失焦。

### 2026-09-12 09:54 — [USER] 临时切换为无障碍平地控制测试场景

- 状态：完成；真实键盘运动待用户现场测试。
- 目的：暂时排除障碍环境和避障行为干扰，在 USER 手动版中单独测试无人机键盘控制、
  停止、升降和组合键。
- 项目路径：`/home/starry/isaac-data/user/Fov-gvf`。
- 涉及文件：新增 `scripts/isaac/create_flat_ground_scene.py`、
  `scripts/prepare_flat_ground_navigation.sh`、`scenes/flat_ground/flat_ground.usd`、
  `scenes/flat_ground/flat_ground_navigation.usd`；修改
  `scripts/run_isaac_fov_gvf_navigation.sh`、`scripts/isaac/run_fov_gvf_navigation.py`、
  `USER_MANUAL_CONTROL_GUIDE.md`、`DONG.md`、`WORK_LOG.md`、`HISTORY/README.md`、
  `HISTORY/FOV_GVF_FAMILY.md` 和本文件；两次短测自动追加
  `performance/PERFORMANCE_METRICS.md`。
- 修改内容：生成 `200×200 m`、地面高度 `z=0` 的平地，加入手动 Robot 和相机，
  出生点设为 `(0,0,1.5)`；USER 启动脚本新增 `FOV_GVF_SCENE_MODE=flat|cloud`，默认
  为 `flat`，并改为只加载当前场景同目录的 `occupancy.bin`。无占据栅格场景不再因
  “零障碍”退出，同时记录地面顶面并按 `0.25 m` 机体半径阻止穿地。原4倍 Cloud
  USD 和占据文件均未覆盖或删除，可用 `FOV_GVF_SCENE_MODE=cloud` 立即切回。
- 验证：Bash 语法及三个 Python 文件语法检查通过；平地场景生成成功，OpenUSD
  确认环境 Mesh 仅 `/World/Ground`，`manualControl=true`、spawn 正确、Robot 有效，
  且无 `/World/UAV_Start`、`/World/UAV_Goal`。首次使用 `ISAAC_HEADLESS=1` 的3秒
  探针按设计报错“manual keyboard control requires ISAAC_HEADLESS=0”，0控制帧，
  未伪装为通过；改用可见窗口复测，控制器进入 `ZERO_INTENT`，发布151帧，仿真
  3.017 s 后按预设 `MANUAL_TIMEOUT` 结束，无按键时位置严格保持 `(0,0,1.5)`，
  `collision_blocks=0`。
- 影响与边界：只改变 USER 手动版的默认场景选择和无障碍/地面保护兼容；没有修改
  C++ 避障数学、键位、速度、ROS话题、RViz配置或 `user_ego` 自动版。无按键悬停已
  验证，真实按键运动、组合键和下降到地面保护仍需用户在主视口取得焦点后现场验证。
- 回滚/备份：Cloud 文件原位保留；运行
  `FOV_GVF_SCENE_MODE=cloud bash scripts/run_isaac_fov_gvf_navigation.sh` 即可恢复原场景。
  如需把 Cloud 永久恢复为默认，将启动脚本中 `FOV_GVF_SCENE_MODE` 默认值由 `flat`
  改回 `cloud`。
- 后续事项：用户在可见 Isaac 主视口测试 `W/S/A/D/R/F`、组合键、松键和 `Space`。

### 2026-09-11 19:28 — [USER-EGO] 2 倍 Cloud 导航卡滞实跑诊断

- 状态：诊断完成，未修改算法。
- 目的：运行当前 USER-EGO 2 倍 Cloud 自动导航，采集实际轨迹和性能数据，判断多次
  卡住及难以到达终点的原因，并形成后续优化方案。
- 项目路径：`/home/starry/isaac-data/user_ego/Fov-gvf`。
- 涉及文件：自动追加 `performance/PERFORMANCE_METRICS.md`；新增
  `performance/NAVIGATION_DIAGNOSIS_20260911.md`；更新 `WORK_LOG.md` 和本文件。
- 运行结果：使用运行 ID `diagnose_2x_20260911`、关闭 RViz 排除显示负载后完成
  240.017 s 仿真，结果 `TIMEOUT`，最终位置 `(24.131,1.455,4.306)`，距终点约
  9.10 m。共出现三段明显低进度区间：10–60 s 位移约 0.49 m、75–100 s 位移约
  0.27 m、135–240 s 位移约 0.60 m；控制器 `NAVIGATING/DEGRADED` 双向切换各
  137 次。
- 性能结论：Isaac 14403 帧、仿真 60.008 Hz；控制器发布 12001 帧、ROS 频率
  50.000 Hz；避障计算 mean/P95/max 为 `1.277/1.590/3.435 ms`；深度到命令
  mean/P95/max 为 `26.638/33.333/50.000 ms`；命令桥 12001 帧全部接收发布。
  关闭 RViz 后仍复现，因此排除 RViz、算力不足和控制链丢帧为主因。
- 原因与方案：三个卡点 ESDF 净空约 `0.533/0.678/0.546 m`，接近当前
  `0.45 m` 静态和最高 `0.55 m` rollout 安全包络；朝终点仅移动 0.2–0.3 m
  就会进入安全包络。按 0.55 m 膨胀后起终点仍连通，说明不是物理无路，而是场景
  缩为 2 倍但机体/安全/速度不变后，纯前视局部导引反复陷入近障局部解；现有恢复
  扫描又会被轻微非零命令打断。建议优先增加进度监测、不可被单帧打断的恢复状态、
  后退/侧移/升降候选和失败方向记忆，再稳定源点自由连通域的谐波求解；临时参数
  A/B 可将速度降至 1.0–1.2 m/s、规划时域降至 1.5–2.0 s，但不建议未经机体实测
  直接缩小安全距离。
- 影响与边界：只新增诊断文档和自动性能记录，没有改动避障源码、Launch 参数、USD
  场景或默认运行方式。原始详细指标保存在性能文档中。
- 后续事项：用户确认优化方向后再实施；每个候选方案至少运行 10 次，以到达率、最长
  零速时间、退化占比、安全限速占比和最小净空验收。

### 2026-09-11 19:16 — [USER] 以当前 USER-EGO 重建 4 倍场景键盘自由控制版

- 状态：完成（真实键盘操作待用户现场复验）。
- 目的：用当前 `user_ego` 的避障、显示、地图和性能统计成果替换旧 `user`，在独立
  USER 副本中恢复 4 倍 Cloud，并移除固定起终点，改为安全的键盘自由控制。
- 项目路径：`/home/starry/isaac-data/user/Fov-gvf`；来源保持为
  `/home/starry/isaac-data/user_ego/Fov-gvf`。
- 涉及文件：整体替换 `user/`；重点修改
  `scripts/isaac/prepare_uav_navigation_scene.py`、
  `scripts/isaac/run_fov_gvf_navigation.py`、
  `scripts/prepare_ego_swarm_cloud_navigation.sh`、
  `scripts/build_isaac_ros_workspace.sh`、`scripts/run_isaac_fov_gvf_navigation.sh`、
  其他含绝对工程路径的场景脚本、`src/pc_gvf/launch/isaac_cloud_navigation.launch.py`、
  `scenes/ego_swarm_cloud/ego_swarm_cloud_navigation.usd`、新增
  `USER_MANUAL_CONTROL_GUIDE.md`、删除继承的 `USER_EGO_GUIDE.md`、更新
  `DONG.md`、`ISAAC_EGO_SWARM_CLOUD_NAVIGATION.md`、`WORK_LOG.md`、
  `HISTORY/README.md`、`HISTORY/PROJECT_INDEX.md`、`HISTORY/FOV_GVF_FAMILY.md`、
  `HISTORY/ENVIRONMENT_AND_ASSETS.md` 和本文件。
- 修改内容：旧 USER 整体移入备份后复制当前 USER-EGO；将绝对路径、独立 `/tmp`
  构建/安装前缀和锁文件改为 USER 专用。场景比例设为 `4.0`，障碍范围恢复约
  `160×120×20 m`、ESDF `0.4 m`、相机最大量程 `40 m`；删除 USD 中
  `/World/UAV_Start`、`/World/UAV_Goal` 及起终点元数据，只保留
  `spawn=(-64,-11.2,2.8)` 初始化位姿。Launch 设置
  `fixed_forward_intent/use_fixed_goal/stop_at_goal=false`，使用 0.25 s 超时的
  `/human_intent`。Isaac 每帧用 `get_keyboard_value()` 轮询
  `W/S/A/D/R/F`、方向键和 `Space`，发布 `TwistStamped`；最终执行器再按同帧物理
  按键做 dead-man。ESDF 碰撞改为只阻止危险帧、不终止手动会话。
- 验证：OpenUSD 确认 `environmentScale=4.0`、`manualControl=true`、spawn 正确且
  起终点 Prim 均不存在，障碍 Mesh 边界约 `(-80.2,-60.2,-0.2)` 至
  `(79.8,59.8,19.8)`；ROS 2 三包构建成功，C++ 核心测试 5/5、平台/可视化/地图
  Python 测试 13/13 通过，Python/launch/Shell 静态检查通过。3.017 s 无按键完整
  Isaac+ROS 短测中控制器进入 `ZERO_INTENT`，无人机严格保持
  `(-64.000,-11.200,2.800)`，运行正常返回；按键轮询接口可读取初始 `0.0`，但尝试
  用文档所列 `buffer_keyboard_key_event` 自动注入 W 时，运行时接口不存在该方法，
  因此该探针失败，未伪造真实按键通过结论。
- 影响与边界：USER 现为无目标手动版；`user_ego` 2 倍自动版未修改。C++ 避障数学、
  在线地图仅显示原则、性能指标和 RViz 优化均从当前 USER-EGO 继承；真实组合键、
  窗口失焦、Space 和碰撞后改向需人工操作复验。
- 回滚/备份：被替换的旧 USER 完整备份为
  `/home/starry/isaac-data/备份/user_before_user_ego_replace_20260911_190000`。
- 后续事项：用户运行一键脚本，在 Isaac 主视口依次验证 W、组合键、松键、Space、
  切出窗口再返回，以及靠近障碍后改向继续驾驶。

### 2026-09-11 18:50 — [USER-EGO] Cloud 场景由 4 倍缩小为 2 倍并调整起终点

- 状态：完成。
- 目的：将当前 EGO-Swarm Cloud 物理场景从原始地图的 4 倍缩小为 2 倍，并使无人机
  起点和控制目标与新场景范围一致。
- 项目路径：`/home/starry/isaac-data/user_ego/Fov-gvf`。
- 涉及文件：`scripts/prepare_ego_swarm_cloud_navigation.sh`、
  `src/pc_gvf/launch/isaac_cloud_navigation.launch.py`、
  `scenes/ego_swarm_cloud/ego_swarm_cloud_navigation.usd`、`DONG.md`、
  `USER_EGO_GUIDE.md`、`ISAAC_EGO_SWARM_CLOUD_NAVIGATION.md`、`WORK_LOG.md`、
  `HISTORY/README.md`、`HISTORY/FOV_GVF_FAMILY.md`、
  `HISTORY/ENVIRONMENT_AND_ASSETS.md` 和本文件。
- 修改内容：保留用户已设置的 `--environment-scale=2.0`；将起点从
  `(-64,-11.2,2.8)` 等比例调整为 `(-32,-5.6,1.4)`，并将终点及控制器固定目标从
  `(64,11.2,4.8)` 调整为 `(32,5.6,2.4)`。重新生成导航 USD；场景约为
  `80×60×10 m`，ESDF 分辨率随元数据由 `0.4 m` 变为 `0.2 m`，相机最大深度由
  `40 m` 变为 `20 m`。无人机模型尺寸不变。
- 验证：Isaac Python 读取新 USD，确认 `environmentScale=2.0`、起终点元数据正确，
  障碍 Mesh 边界约为 `(-40.1,-30.1,-0.1)` 至 `(39.9,29.9,9.9)`；ROS 2 三包构建
  成功，源码与安装后的 launch 固定目标一致；Shell/launch 语法检查通过，C++ 核心
  测试 5/5、可视化/地图 Python 测试 8/8 通过。未执行完整 Isaac 闭环飞行，当前
  2 倍场景尚无终点到达结论。
- 影响与边界：改变物理场景比例、起点、终点、ESDF 物理分辨率和相机最大量程；
  避障数学、无人机尺寸、速度限制、RViz 默认配置和在线观测地图参数未改变。
- 回滚/备份：完整修改前快照为
  `/home/starry/isaac-data/备份/user_ego_before_2x_map_20260911_184713`。
- 后续事项：运行一次完整 2 倍场景导航，验证新起点净空、路径和终点到达情况。

### 2026-09-11 14:30 — [桌面 QQ 音乐] 清理播放核心与前台 UI 状态分裂

- 状态：部分完成。
- 目的：处理媒体键补丁生效后出现的“音频继续播放，但底部播放器显示占位信息、
  00:00 且鼠标操作不可用”问题。
- 项目路径：`/opt/qqmusic`；记录位于 `/home/starry/isaac-data`。
- 涉及文件：未修改 QQ 音乐文件；更新本文件。运行时日志写入
  `/tmp/qqmusic-clean-launch.log`。
- 修改内容：暂停当前 MPRIS 播放，结束从 12:50、13:33、13:36、13:44、13:46
  多次启动后残留的全部 QQ 音乐主进程、zygote 和僵尸进程，再以系统应用入口及独立
  会话重新启动客户端。
- 验证：处理前 MPRIS `chromium.instance22746` 报告正在播放《春よ、来い。》且
  元数据完整，而截图中的新前台底栏显示“QQ音乐，让生活充满音乐”和 `00:00/00:00`，
  证明播放核心与 UI 状态不一致；补丁 ASAR 和原备份哈希均正确。前台 8 秒诊断启动
  显示 Electron 主界面、远程音乐页和播放器模块均加载，未见 ASAR 偏移/解析错误，
  但记录到旧客户端自身的 FQM、网络握手、CORS 和音频资源告警。清理后仅剩 14:29
  启动的一组主进程与子进程，尚未由用户点歌确认底栏恢复，也未复测媒体键。
- 影响与边界：只重启 QQ 音乐运行时进程，不删除账号、歌单、缓存或配置；媒体键
  `playPrev()` 补丁保持安装状态。
- 回滚/备份：ASAR 原始备份仍为
  `/opt/qqmusic/resources/app.asar.before-media-key-fix-20260911`；本次进程清理无需回滚。
- 后续事项：在新窗口点播任意歌曲，确认底栏元数据及鼠标操作恢复，再复测 M1/M3。

### 2026-09-11 13:43 — [桌面 QQ 音乐] 修复安装器的 sudo PATH 依赖

- 状态：完成。
- 目的：解决补丁安装器在 `sudo` 安全 PATH 中找不到用户环境 `node`、因而未能安装
  QQ 音乐媒体键补丁的问题。
- 项目路径：`/home/starry/isaac-data`；目标程序位于 `/opt/qqmusic`。
- 涉及文件：`install_qqmusic_media_key_fix.sh` 和本文件。
- 修改内容：将安装器的二进制等长替换实现从 PATH 中的 `node` 改为 Ubuntu 系统绝对
  路径 `/usr/bin/python3`；仍严格要求错误模式只出现一次，并保留安装前后 SHA-256
  校验、备份和失败回滚。
- 验证：失败后复核 `/opt/qqmusic/resources/app.asar` 及已生成备份的 SHA-256 均为
  原始值 `dd14cf14b0cecf7d97cf928bee1bb24c7be74b511356fca2237d6a918e89a059`，确认未产生
  半补丁；确认 `/usr/bin/python3` 存在；安装器 `bash -n` 通过；用同一 Python
  逻辑处理原 ASAR 副本后得到预期 SHA-256
  `4354c59d11684f7b2c74250bc7a381b147c2e10fcd322ac7a44be750afc045a1`，`cmp -l`
  仍只显示 `Next` 到 `Prev` 的 4 个字符变化。尚未再次以 sudo 安装，也未实测媒体键。
- 影响与边界：只修正安装器运行依赖，不改变补丁目标、系统媒体键或其他播放器。
- 回滚/备份：脚本修改可恢复上一版本；系统原 ASAR 备份已存在于
  `/opt/qqmusic/resources/app.asar.before-media-key-fix-20260911`。
- 后续事项：再次运行安装命令，重启 QQ 音乐并验收上一曲/下一曲。

### 2026-09-11 13:41 — [桌面 QQ 音乐] 更正运行环境并制作原厂错误定点补丁

- 状态：部分完成。
- 目的：在 Tampermonkey 方案对实际桌面客户端无效后，确认真实运行环境并直接修复
  上一曲媒体动作。
- 项目路径：`/home/starry/isaac-data`；目标程序位于 `/opt/qqmusic`。
- 涉及文件：新增 `install_qqmusic_media_key_fix.sh`；待修改
  `/opt/qqmusic/resources/app.asar`；保留先前的 `QQMUSIC_MEDIA_KEY_FIX.user.js` 作为
  未应用于桌面客户端的旧方案；以及本文件。
- 修改内容：更正先前把当前桌面 QQ 音乐判断为 Chromium 网页/PWA 的错误。进程
  证据确认实际程序是 Electron 客户端 `/opt/qqmusic/qqmusic` 1.1.8。解读其 ASAR
  后确认 `src/client/modules/players/index.ts` 编译代码将 `nexttrack` 和
  `previoustrack` 都绑定到了 `this.playNext()`。新增一键脚本，仅把后者等长替换为
  `this.playPrev()`，并提供原文件校验、备份、补丁后校验、失败自动回滚及
  `--rollback`。
- 验证：原 ASAR SHA-256 为
  `dd14cf14b0cecf7d97cf928bee1bb24c7be74b511356fca2237d6a918e89a059`；在 `/tmp`
  生成的补丁副本 SHA-256 为
  `4354c59d11684f7b2c74250bc7a381b147c2e10fcd322ac7a44be750afc045a1`；`cmp -l`
  显示只修改 `Next` 到 `Prev` 的 4 个字符，错误模式从 1 处变为 0 处，正确模式从
  0 处变为 1 处。尝试安装时 `sudo -n` 因需要用户密码失败，原 ASAR 哈希未变化、
  系统文件尚未修改；尚未实测 M1/M3。
- 影响与边界：补丁仅改变 QQ 音乐 Electron 1.1.8 的 `previoustrack` 回调；不修改
  键盘、Ubuntu 全局媒体键、MPRIS 服务或其他播放器。QQ 音乐升级后哈希变化时安装
  脚本会拒绝修改，升级也可能覆盖已装补丁。
- 回滚/备份：成功安装时自动创建
  `/opt/qqmusic/resources/app.asar.before-media-key-fix-20260911`；执行
  `sudo bash /home/starry/isaac-data/install_qqmusic_media_key_fix.sh --rollback` 可恢复。
- 后续事项：用户以 `sudo` 运行安装脚本、彻底重启 QQ 音乐，然后实测
  `playerctl previous/next` 与 M1/M3、Fn+F7/Fn+F9。

### 2026-09-11 13:30 — [桌面 QQ 音乐] 修复上一曲媒体动作

- 状态：部分完成。
- 目的：修复 Ubuntu 22.04 的 Chromium/PWA 版 QQ 音乐把 MPRIS
  `Previous`/Media Session `previoustrack` 错误执行为下一曲的问题，同时不改键盘
  固件、evdev 映射或 Ubuntu 全局媒体键。
- 项目路径：`/home/starry/isaac-data`。
- 涉及文件：新增 `QQMUSIC_MEDIA_KEY_FIX.user.js`，以及本文件。
- 修改内容：新增仅匹配 `https://y.qq.com/*` 的 Tampermonkey 用户脚本；分别将
  `previoustrack`、`nexttrack` 定向到页面的上一首、下一首控件；优先使用
  `aria-label`、`title`、`data-action` 和按钮文本，当前版稳定 class
  `.player__ft .btn_big_prev/.btn_big_next` 作为兼容定位；拦截页面后续错误注册，并
  每秒重新覆盖一次以应对单页应用重新挂载。
- 验证：本机 Chrome Default 配置确认已安装 Tampermonkey 5.5.0，且
  `userScripts` 位于 active/granted permissions；2026-09-11 从 `y.qq.com` 当前
  `player.chunk.b14b319972b31bec62da.js` 核对到播放器实际生成
  `.player__ft .btn_big_prev`（“上一首”）、`.btn_big_play`（“播放/暂停”）和
  `.btn_big_next`（“下一首”）。`node --check` 语法检查通过；使用模拟
  MediaSession 和当前按钮选择器的 Node 沙箱测试，确认脚本分别注册
  `previoustrack`/`nexttrack`，调用后只点击对应按钮各一次。尚未将脚本导入
  Tampermonkey，也未用 `playerctl previous/next` 做安装后的实机验收。
- 影响与边界：只影响 QQ 音乐 `y.qq.com` 页面内的 Media Session 上一曲/下一曲
  处理；不修改系统媒体键、其他播放器、键盘映射或浏览器配置。
- 回滚/备份：在 Tampermonkey 中停用/删除该脚本，并删除新增文件即可回滚；原系统
  配置和 QQ 音乐代码均未改动。
- 后续事项：导入脚本、刷新正在播放的 QQ 音乐页面，然后分别实测
  `playerctl previous`、`playerctl next` 及 M1/M3、Fn+F7/Fn+F9。

### 2026-09-11 12:28 — [ISAAC-DATA] 准备 ROS 2 Humble Desktop 离线镜像

- 状态：完成。
- 目的：为 Docker Hub 拉取超时的 Ubuntu 24.04 x86_64 目标机准备可离线导入的
  ROS 2 Humble Desktop 镜像。
- 项目路径：`/home/starry/isaac-data`。
- 涉及文件：新增 `ros-humble-desktop-linux-amd64.tar.zst`、
  `ROS_HUMBLE_DESKTOP_IMAGE_README.md`，以及本文件。
- 修改内容：拉取 `osrf/ros:humble-desktop` 的 `linux/amd64` 镜像；因 Docker
  Official Image 的 `ros` 仓库不提供该 desktop 标签，额外创建
  `ros:humble-desktop` 兼容标签后共同导出为 zstd 压缩的 Docker 镜像归档；新增
  目标机校验、导入和离线构建说明。
- 验证：`docker pull --platform linux/amd64 osrf/ros:humble-desktop` 成功，镜像
  ID / digest 为 `sha256:fb07245b32187d74350be25323d8ad2f8ca5c25c325759911a1eff2267a49c1e`；
  `zstd -t` 完整流校验通过；从归档读取 `manifest.json`，确认同时包含
  `osrf/ros:humble-desktop` 和 `ros:humble-desktop` 两个标签；归档 SHA-256 为
  `d158ebf0d2517bf731b8a208f7ee92774fee3e17beb891ed3edda9527b743087`；执行
  `docker load -i ros-humble-desktop-linux-amd64.tar.zst` 回灌成功，Docker 报告已
  加载上述两个标签。未在独立、空白 Docker daemon 上测试，未构建或运行
  SCAN-Planner。
- 影响与边界：新增离线分发资产和说明，并在本机 Docker daemon 中缓存镜像；未修改
  任何现有项目源码、配置、依赖或运行参数。归档仅适用于 amd64，不适用于 arm64。
- 回滚/备份：删除上述新增归档及说明即可撤销工作区文件；本机 Docker 镜像可按需
  使用 `docker image rm` 单独移除。本任务未执行删除。
- 后续事项：传输后在目标机比对 SHA-256，再执行 `docker load`。

### 2026-09-10 21:08 — [USER-EGO] 固化用户调整后的 RViz 默认配置

- 状态：完成。
- 目的：保存用户在 RViz 界面中调整后的显示、视角和窗口布局，并将其设为项目及
  RViz2 用户级默认配置。
- 项目路径：`/home/starry/isaac-data/user_ego/Fov-gvf`。
- 涉及文件：`src/pc_gvf_platforms/config/isaac_cloud_navigation.rviz`、
  `/home/starry/.rviz2/default.rviz`、`WORK_LOG.md` 和本文件。
- 修改内容：以 RViz 退出时写入临时安装目录的最新配置为准，同步保存白色背景、
  关闭地面网格、第三人称距离约 14.65、历史点云 20 px、1920×2032 窗口布局等
  用户设置；保留 60 FPS、点云队列 1 和禁用点选择等性能设置。项目 launch 原本已
  通过 `-d` 默认加载该项目配置；另创建 `/home/starry/.rviz2/default.rviz`，使直接
  启动 `rviz2` 时也加载相同配置。
- 验证：源码、临时安装目录与用户级默认配置 SHA-256 均为
  `a01b082c747da498046e578bcb1085334f3ecc469b00f4dbe8fd4e1fafc037a2`；重新执行
  `scripts/build_isaac_ros_workspace.sh`，3 个 ROS 2 包构建成功。未运行 Isaac 仿真。
- 影响与边界：仅固化 RViz 显示配置；避障、控制、传感器和性能统计代码未改变。
- 回滚/备份：原项目配置备份为
  `/home/starry/isaac-data/备份/isaac_cloud_navigation_before_user_default_20260910_2105.rviz`；
  更早的完整项目快照仍为
  `/home/starry/isaac-data/备份/user_ego_before_rviz_fps_20260910_204300`。
- 后续事项：无。

### 2026-09-10 20:50 — [USER-EGO] 提高 RViz 帧率并降低可视化负载

- 状态：完成。
- 目的：改善 RViz 第三人称跟随和无人机运动显示不连贯的问题。
- 项目路径：`/home/starry/isaac-data/user_ego/Fov-gvf`。
- 涉及文件：`src/pc_gvf_platforms/config/isaac_cloud_navigation.rviz`、
  `src/pc_gvf_platforms/pc_gvf_platforms/navigation_visualizer.py`、
  `src/pc_gvf_platforms/test/test_robot_visualization.py`、
  `src/pc_gvf/src/depth_angular_controller_node.cpp`、
  `src/pc_gvf/launch/isaac_cloud_navigation.launch.py`、`DONG.md`、
  `USER_EGO_GUIDE.md`、`WORK_LOG.md`、`HISTORY/FOV_GVF_FAMILY.md` 和本文件。
- 修改内容：RViz 目标帧率设为 60 FPS；完整 Path 改为 10 Hz、0.10 m 位移采样和
  1000 点上限；角域 GVF 改为 15 Hz；显示深度步长改为 4；历史地图显示改为
  `1 Hz/0.25 m/60000 点`；PointCloud2 队列设为 1、禁用逐点选择，默认关闭重复的
  Odometry 坐标轴。无人机/命令 Marker 仍允许 60 Hz。
- 验证：三包构建成功；C++ 核心测试 5/5、可视化/地图 Python 测试 8/8 通过；
  安装后的 RViz 配置以 OpenGL 4.6 短时加载 8 秒，无插件错误，随后由 timeout
  预期中止并返回 124；安装目录已复核为 60 FPS 及上述降载参数。完整 `ctest`
  另有 2 项 Python 基线测试因系统 NumPy 2.2.6 与 Ubuntu SciPy（要求 NumPy
  <1.25）二进制不兼容而在收集阶段失败，并非断言失败；随后定向复测上述 5+8 项
  均通过。未执行完整 Isaac+RViz 到达测试，未测得可声明的实际 FPS。
- 影响与边界：避障数学、规划深度输入、50 Hz 控制、安全参数和 ESDF 未改变；
  `0.25 m` 只影响历史地图显示，内部仍以 `0.08 m` 累计。
- 回滚/备份：完整快照为
  `/home/starry/isaac-data/备份/user_ego_before_rviz_fps_20260910_204300`。
- 后续事项：用户复跑后观察实际连贯性；若仍不足，优先关闭深度 Image 或角域场显示。

### 2026-09-10 17:30 — [USER-EGO] 增加控制链性能指标与逐次运行记录

- 状态：完成。
- 目的：为后续避障优化建立每次运行都可比较的计算耗时、控制频率、帧数和延迟基线。
- 项目路径：`/home/starry/isaac-data/user_ego/Fov-gvf`。
- 涉及文件：`src/pc_gvf/src/depth_angular_controller_node.cpp`、
  `src/pc_gvf_platforms/pc_gvf_platforms/command_bridge.py`、
  `src/pc_gvf/launch/isaac_cloud_navigation.launch.py`、
  `scripts/isaac/run_fov_gvf_navigation.py`、
  `scripts/run_isaac_fov_gvf_navigation.sh`、新增
  `performance/PERFORMANCE_METRICS.md`，以及 `DONG.md`、`USER_EGO_GUIDE.md`、
  `WORK_LOG.md`、`HISTORY/FOV_GVF_FAMILY.md`、`HISTORY/CHANGELOG.md`。
- 修改内容：以同一运行 ID 串联控制器、命令桥和 Isaac 三段性能采样；终端每 5 秒
  输出控制器/桥接摘要并在退出时输出最终摘要；Markdown 追加 mean/P50/P95/max
  避障计算耗时、命令与导引帧数、ROS/墙钟 FPS、控制间隔、深度到命令、回调到
  发布、控制器到桥接、Twist 发布以及 Isaac 实际采样指标。
- 验证：ROS 2 三包构建成功；C++ 核心测试 5/5、桥接数学测试 5/5 通过；Python、
  launch、Shell 静态检查通过。沙箱内 DDS 权限失败样本如实保留；授权环境中的最终
  5.017 s 短测记录 251 个命令帧、ROS 控制频率 50.000 Hz，避障计算
  mean/P95/max 为 `1.025/1.406/3.181 ms`，并成功写入三段 Markdown。该短测按
  5 s 配置进入 `TIMEOUT`，未执行完整终点到达验收。
- 影响与边界：没有修改避障数学与运行参数；统计引入少量内存采样、终端输出和退出
  写盘开销。无时间戳的 Isaac Twist 订阅端只记录实际采样周期，不声称得到不可测的
  精确逐消息传输延迟。
- 回滚/备份：完整修改前备份为
  `/home/starry/isaac-data/备份/user_ego_before_avoidance_20260910_165519`。
- 后续事项：下一次完整 Cloud 运行会自动追加完整任务性能记录。

### 2026-09-10 — [ISAAC-DATA] 建立统一 HISTORY 项目档案与持续记录制度

- 状态：完成。
- 目的：整理 `/home/starry/isaac-data` 全部一级目录的项目介绍、当前进展、版本和
  相互关系，并确保后续修改持续留痕。
- 项目路径：`/home/starry/isaac-data`。
- 涉及文件：新增 `HISTORY/README.md`、`PROJECT_INDEX.md`、
  `FOV_GVF_FAMILY.md`、`UAV_PROJECT.md`、`ENVIRONMENT_AND_ASSETS.md`、
  `RECORDING_RULES.md`、`CHANGELOG.md`；新增根级 `AGENTS.md`；为旧小写
  `history/` 增加迁移提示。
- 修改内容：盘点 FOV-GVF 四组工程、UAV EGO 项目、两类 EGO 场景资产、Isaac
  Sim、Isaac Lab、Blender、Isaac ROS 工作区、示例脚本、容器/系统目录和独立安装包；
  建立 R-001 记录规则和跨项目总账。
- 验证：读取各项目 README、WORK_LOG、DONG、checkpoint、版本文件和 Git 状态；
  使用 `du`、`find`、`file`、`git status/log` 核对目录、规模和版本。受权限保护的
  `containerd/`、`docker/`、`lost+found/` 只登记存在，没有读取或修改。
- 影响与边界：只新增整理文档和记录规则，没有修改任何导航、规划、仿真或控制代码。
- 回滚/备份：全部为新增文本文件；旧项目日志和小写 `history/` 未删除。
- 后续事项：以后每次项目修改按 `RECORDING_RULES.md` 同步记录。

### 2026-09-10 — [USER-EGO] 整理 DONG.md 并完成 RViz 第三人称与视口显示调整

- 状态：完成。
- 目的：形成用户可读的 USER-EGO 工程说明，并改善 Isaac/RViz 观察体验。
- 项目路径：`/home/starry/isaac-data/user_ego/Fov-gvf`。
- 涉及文件：`DONG.md`、`USER_EGO_GUIDE.md`、`WORK_LOG.md`、
  `scripts/isaac/run_fov_gvf_navigation.py`、
  `src/pc_gvf_platforms/config/isaac_cloud_navigation.rviz`。
- 修改内容：整理 USER-EGO 目录与文件职责；Isaac 默认采用 Texture Diffuse、Sun
  800、环境光 0.05；RViz 默认采用跟随 `radar` 的 ThirdPersonFollower，距离 8 m。
- 验证：Python/Bash 语法通过，ROS 三包构建成功，Isaac 可见视口抓帧验证平均亮度
  约 72.30/255，RViz 插件短时加载无错误。
- 影响与边界：只改变显示、文档和观察相机；C++ 导航算法未改变。
- 回滚/备份：参数旧值保留在 USER-EGO `WORK_LOG.md`。
- 后续事项：无。
### 2026-09-19 10:16 — [ausim2] 新增二足机器人并列模块骨架

- 状态：完成。
- 目的：在 `ausim_uav/` 和 `ausim_ugv/` 之外预留独立的二足机器人仿真模块，供后续
  接入 G1 等机器人模型、控制器和 MuJoCo 运行时。
- 项目路径：`/home/starry/isaac-data/ausim2-main`。
- 涉及文件：新增 `ausim_biped/CMakeLists.txt`、`ausim_biped/README.md`、
  `ausim_biped/cfg/README.md`、`ausim_biped/src/README.md`、
  `ausim_biped/tests/README.md`；修改根 `CMakeLists.txt`、`README.md` 和本文件。
- 修改内容：根 CMake 纳入 `ausim_biped`；建立 `cfg/src/tests` 骨架并记录未来
  `app/config/controller/control/runtime/sim` 分层、与 `ausim_common` 的复用边界及
  预期 `build/bin/biped` 产物。当前没有添加虚假机器人配置或占位可执行程序。
- 验证：待执行 CMake 配置级验证；未构建、未运行二足机器人仿真。
- 影响与边界：不改变现有 UAV、UGV、ROS2 话题、MuJoCo 资产或运行参数；新增模块
  当前不产生可执行文件。
- 回滚/备份：删除 `ausim_biped/`、移除根 CMake 的对应 `add_subdirectory`，并还原
  根 README 的模块说明即可；本任务未创建额外备份。
- 后续事项：确定首个二足机器人（建议 G1）的 MJCF、关节语义、控制模式和 ROS 接口，
  再实现配置及运行链路。
### 2026-09-19 10:16 — [ausim2] 更正二足机器人目录创建范围

- 状态：完成。
- 目的：按用户补充说明，将二足机器人模块调整为仅创建空目录，暂不添加任何内容。
- 项目路径：`/home/starry/isaac-data/ausim2-main`。
- 涉及文件：保留空目录 `ausim_biped/`；撤销刚新增的模块文件以及根
  `CMakeLists.txt`、`README.md` 改动；更新本文件。
- 修改内容：删除 `ausim_biped` 内的 CMake、README、`cfg/src/tests` 内容，撤销根
  CMake 接入和项目说明，只保留空的 `/home/starry/isaac-data/ausim2-main/ausim_biped`。
- 验证：使用目录枚举确认 `ausim_biped/` 存在且为空；未构建、未运行仿真。
- 影响与边界：UAV、UGV、公共层、构建系统、配置和运行方式均未改变。
- 回滚/备份：该空目录可直接删除；未创建备份。
- 后续事项：等待用户指定该目录后续内容。
