# EGO1P5：全向避障与六方向可选机制

2026-10-07 17:33 — **六方向实现与逐项消融已完成，整体运行全面优胜未通过。** 最终主入口构建、核心31/31、平台15/15、64种组合重放通过；18次目标安全到达、12次手柄等效轨迹通过独立机体扫掠，30次均重叠0/外部保护0。第二版③⑤平均到达70.039s，基线69.256s；操控方向误差略减但jerk略增，因此六项当前默认均关闭，独立实验开关保留。P3/P4源码未改，失败与冻结版本保留。六项方案、实现、收益与退化、适用边界及手柄指令见[六方向优化报告](SIX_AXIS_OPTIMIZATION.md)，全量数据见[机器汇总](performance/six_axis_20261007/completion_summary.json)。

## 复制检查点历史（保留来源说明）

**历史状态边界（2026-10-07 16:27）：本页主体记录从EGO1P3 v22建立的复制检查点。复制期间另一项“六方向优化”已在EGO1P5接续修改源码并运行基线；该工作保留在当前目录，本任务没有覆盖或回滚。22/22与15/15是复制检查点的验证结果，不代表随后修改已验收。最新后续状态以[WORK_LOG](WORK_LOG.md)为准。**

2026-10-07按用户要求完整复制EGO1P3。**EGO1P3原目录保留；EGO1P5继承相同算法和参数，本次只适配独立路径与版本标识。**
源码、隐藏文件、Git、地图、全部成功/失败实验和最新手柄运行记录均已复制。

先阅读[项目算法、进展与当前状态](EGO1P5_VERSION.md)。复制证据和本次验证在[复制验证目录](performance/copy_from_ego1p3_20261007)，实际变更见[WORK_LOG.md](WORK_LOG.md)。
来源说明原文保留于[EGO1P3_VERSION.md](EGO1P3_VERSION.md)、[来源README](EGO1P3_README.md)和[来源360°验收报告](OMNI_ACCEPTANCE.md)；这些历史成绩仍属于EGO1P3，不是P5新导航成绩。

## 构建与手柄运行

```bash
cd /home/starry/isaac-data/EGO1P5
bash scripts/build_isaac_ros_workspace.sh

ISAAC_MANUAL_INPUT_MODE=joystick \
ISAAC_HEADLESS=0 \
ISAAC_MANUAL_TIMEOUT=0 \
FOV_GVF_SCENE_MODE=cloud \
FOV_GVF_RVIZ=true \
FOV_GVF_OMNI_DEPTH=1 \
FOV_GVF_INSTALL=/tmp/fov_gvf_ego1p5_isaac_install \
bash scripts/run_isaac_fov_gvf_navigation.sh
```

已有本目录构建产物时可直接运行后半段。主脚本自动加载ROS环境和识别北通A2P3A BFM/XInput设备。
默认启动原4倍Cloud场景、Isaac Sim与RViz，四轴回中保持0.5秒后解锁；看到`controls enabled after neutral hold`后操作。

| 操作 | 功能 |
|---|---|
| 右摇杆上下 | 相对机头前进/后退 |
| 右摇杆左右或斜推 | 左右平移或任意水平方向 |
| 左摇杆上下 | 升降 |
| 左摇杆左右 | 独立旋转机头 |
| 两摇杆回中 | 制动停止 |
| 终端Ctrl+C或关闭窗口 | 退出仿真 |

需要本机ROS Humble、Isaac Sim、NVIDIA图形环境及手柄。无手柄时可用：

```bash
ISAAC_MANUAL_INPUT_MODE=keyboard ISAAC_HEADLESS=0 \
FOV_GVF_INSTALL=/tmp/fov_gvf_ego1p5_isaac_install \
bash scripts/run_isaac_fov_gvf_navigation.sh
```

键盘W/S、A/D、R/F对应世界坐标前后、左右、升降；Space停止，1/3/V切换视角。
手柄平移以机头为参照，再转换为世界方向；键盘映射仍是世界坐标，两者不要混淆。

## 当前链路与已知边界

四路深度及采集位姿 → 世界坐标球面方向融合 → 连续360°候选 → 单三维矢量整形 → 完整运动/制动认证 → 命令桥 → Isaac。
实际机体球半径.48m、认证包络.58m；速度上限2m/s、垂向1m/s、响应.22s、实际加减速度1.2m/s²。
未知、过期或撤销证据不得用于放行。水平360°方向域不等于上下/接缝无盲区。

继承的v22正式对照：扫向明显改善，但独立旋转部分指标退化，固定目标平均70.143s慢于P2的69.717s；全面优胜未通过。
新发现并保留的来源手柄日志`20261007_160119`记录147.5s仿真、用户退出、外部保护0，避障计算峰值633.340ms；不是新P5动态验收。

新目录使用独立`/tmp/fov_gvf_ego1p5_isaac_{build,install,log}`、ROS日志和重放前缀；性能日志写入本目录。
ROS域42与`/tmp/fov_gvf_user_navigation.lock`继续共用，禁止多个副本同时控制。
设置`FOV_GVF_OMNI_DEPTH=0`只切换旧候选前端，联合覆盖证明仍为7层，不能当作完整EGO1P2。
继承的Git分支名仍为`ego1p1`，本次没有创建提交或推送。
