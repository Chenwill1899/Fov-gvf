#include "pc_gvf/goal_refinement.hpp"
#include <cstdlib>
#include <iostream>
#define CHECK(condition) do { if(!(condition)) { std::cerr << "line " << __LINE__ << ": " << #condition << "\n"; std::exit(1); } } while(false)
#include <limits>
#include <vector>
using namespace pc_gvf::depth_angular;
int main() {
    const double pi=std::acos(-1.);
    auto ray=[](double a){return Eigen::Vector3d(std::cos(a),std::sin(a),0.);};
    const auto initial=ray(pi/6.);const auto goal=Eigen::Vector3d::UnitX();
    int calls=0;
    auto off=refineGoalDirection(initial,goal,0,[&](const auto&){++calls;return true;});
    CHECK(calls==0 && (off.direction-initial).norm()<1e-12);
    auto blocked=refineGoalDirection(initial,goal,3,[&](const auto&){++calls;return false;});
    CHECK(blocked.checks==3 && blocked.improvements==0 && (blocked.direction-initial).norm()<1e-12);
    std::vector<Eigen::Vector3d> accepted;
    auto clipped=refineGoalDirection(initial,goal,6,[&](const auto& d){
        // A real obstacle boundary: no ray below twenty degrees is permitted.
        const bool valid=d.y()/d.x()>=std::tan(20.*pi/180.);
        if(valid)accepted.push_back(d);
        return valid;
    });
    CHECK(clipped.checks<=6 && clipped.improvements>0);
    CHECK(clipped.direction.dot(goal)>initial.dot(goal));
    CHECK(clipped.direction.y()/clipped.direction.x()>=std::tan(20.*pi/180.));
    CHECK((accepted.back()-clipped.direction).norm()<1e-12);
    auto open=refineGoalDirection(initial,goal,3,[](const auto&){return true;});
    CHECK(open.improvements==3 && open.direction.dot(goal)>std::cos(4.*pi/180.));
    CHECK(std::abs(open.direction.norm()-1.)<1e-12);
    auto seam=refineGoalDirection(ray(179.*pi/180.),ray(-179.*pi/180.),3,[](const auto&){return true;});
    CHECK(seam.direction.x()<-.99); // Interpolate across the seam, not through the opposite hemisphere.
    auto nan=refineGoalDirection(Eigen::Vector3d(std::numeric_limits<double>::quiet_NaN(),0,0),goal,3,[](const auto&){return true;});
    CHECK(nan.checks==0 && nan.direction.norm()==0.);
    auto zero=refineGoalDirection(initial,Eigen::Vector3d::Zero(),3,[](const auto&){return true;});
    CHECK(zero.checks==0 && zero.direction.norm()==0.);
    auto opposite=refineGoalDirection(initial,-initial,3,[&](const auto&){CHECK(false);return true;});
    CHECK(opposite.checks==0);
    // Non-monotone visibility does not license unqueried directions.
    accepted.clear();
    auto discontinuous=refineGoalDirection(initial,goal,6,[&](const auto& d){
        const double angle=std::atan2(d.y(),d.x());
        bool valid=angle>=20.*pi/180. || angle<=5.*pi/180.;
        if(valid)accepted.push_back(d);
        return valid;
    });
    CHECK(!accepted.empty() && (discontinuous.direction-accepted.back()).norm()<1e-12);
    return 0;
}
