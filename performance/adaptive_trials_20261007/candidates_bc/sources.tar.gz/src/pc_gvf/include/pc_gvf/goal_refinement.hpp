#ifndef PC_GVF_GOAL_REFINEMENT_HPP
#define PC_GVF_GOAL_REFINEMENT_HPP
#include <Eigen/Core>
#include <algorithm>
#include <cmath>
#include <functional>
namespace pc_gvf { namespace depth_angular {
struct GoalRefinementResult {
    Eigen::Vector3d direction = Eigen::Vector3d::Zero();
    int checks = 0;
    int improvements = 0;
};
// Proposal-only geodesic search. A failed midpoint does not prove its neighbors
// blocked; bisection is merely a bounded heuristic, never a safety inference.
inline GoalRefinementResult refineGoalDirection(const Eigen::Vector3d& proposal,
    const Eigen::Vector3d& desired, int steps,
    const std::function<bool(const Eigen::Vector3d&)>& certify) {
    GoalRefinementResult out;
    if(!proposal.allFinite() || !desired.allFinite() || proposal.norm()<1e-8 || desired.norm()<1e-8)
        return out;
    out.direction=proposal.normalized();
    const Eigen::Vector3d goal=desired.normalized();
    if(out.direction.dot(goal)<=0. || !certify)return out;
    Eigen::Vector3d upper=goal;
    for(int i=0;i<std::max(0,std::min(6,steps));++i) {
        const Eigen::Vector3d sum=out.direction+upper;
        if(sum.norm()<1e-8 || out.direction.dot(goal)>1.-1e-12)break;
        const Eigen::Vector3d midpoint=sum.normalized();
        ++out.checks;
        if(certify(midpoint)) {
            out.direction=midpoint;
            ++out.improvements;
        } else upper=midpoint;
    }
    return out;
}
}}
#endif
